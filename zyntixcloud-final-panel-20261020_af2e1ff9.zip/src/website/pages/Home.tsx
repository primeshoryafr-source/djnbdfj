import { useEffect } from 'react';
import { ControlPanel, Features, Hardware, Hero, Locations, Services, SetupProcess } from '../components/home/HomeSections';
import { FinalCTA } from '../components/common/FinalCTA';
import { setSeo } from '../components/hosting/ProductPage';

export function Home() {
  useEffect(() => setSeo('ZyntixCloud — Game Servers, VPS, VDS & Bot Hosting', 'Game servers, VPS, VDS and bot hosting with locations across India, Germany and Singapore.'), []);
  return (
    <>
      <Hero />
      <Services />
      <Hardware />
      <Locations />
      <ControlPanel />
      <SetupProcess />
      <Features />
      <FinalCTA />
    </>
  );
}
