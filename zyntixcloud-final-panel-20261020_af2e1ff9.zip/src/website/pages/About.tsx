import { useEffect } from 'react';
import { setSeo } from '../components/hosting/ProductPage';
import { SectionHeader } from '../components/common/SectionHeader';
import { FinalCTA } from '../components/common/FinalCTA';

export function About() {
  useEffect(() => setSeo('About ZyntixCloud | ZyntixCloud', 'Learn about ZyntixCloud hosting services for game servers, VPS, VDS and bot hosting.'), []);
  return (
    <>
      <section className="product-hero"><div className="container"><p className="eyebrow">ABOUT</p><h1>Hosting for servers people actually use.</h1><p>ZyntixCloud provides game servers, VPS, VDS and bot hosting across India, Germany and Singapore depending on the product.</p></div></section>
      <section className="section"><div className="container"><SectionHeader title="Simple hosting, clear plans." description="The site is prepared for billing and server-management systems to be connected later. Current actions are frontend CTAs only." /></div></section>
      <FinalCTA />
    </>
  );
}
