import express from "express";
import { requireAuth } from "../middleware/auth.js";
import { listCatalog } from "../services/catalog.js";
import { attachRazorpayOrder, createOrder, getOrderForUser, listOrdersForUser, markOrderPaid } from "../services/billing.js";
import { createRazorpayOrder, hasRazorpayConfig, verifyPaymentSignature, verifyWebhookSignature } from "../services/razorpay.js";
import { processProvisioningJob } from "../services/provisioning.js";
import { readJSON } from "../services/db.js";

const router = express.Router();

router.get("/catalog", (_req, res) => {
  res.json({ products: listCatalog() });
});

router.use(requireAuth);

router.get("/orders", async (req, res) => {
  res.json({ orders: await listOrdersForUser((req as any).user) });
});

router.post("/orders", async (req, res) => {
  try {
    const { productId, planId, config } = req.body || {};
    const order = await createOrder((req as any).user, productId, planId, config);
    res.status(201).json({ order });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get("/orders/:id", async (req, res) => {
  const order = await getOrderForUser(req.params.id, (req as any).user);
  if (!order) return res.status(404).json({ error: "Order not found" });
  const jobs = (await readJSON("provisioning_jobs.json")) || [];
  res.json({ order, provisioning: jobs.find((job: any) => job.orderId === order.id) || null });
});

router.post("/orders/:id/razorpay", async (req, res) => {
  try {
    const order = await getOrderForUser(req.params.id, (req as any).user);
    if (!order) return res.status(404).json({ error: "Order not found" });
    if (!hasRazorpayConfig()) {
      return res.status(503).json({ error: "Razorpay is not configured on this deployment." });
    }
    const razorpayOrder = await createRazorpayOrder(order);
    await attachRazorpayOrder(order.id, razorpayOrder.id);
    res.json({
      keyId: process.env.RAZORPAY_KEY_ID,
      orderId: razorpayOrder.id,
      amount: order.totalPaise,
      currency: order.currency,
      name: "ZyntixCloud",
      description: `${order.snapshot.product.name} - ${order.snapshot.plan.name}`,
      internalOrderId: order.id,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/payments/verify", async (req, res) => {
  try {
    const { internalOrderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
    const order = await getOrderForUser(internalOrderId, (req as any).user);
    if (!order) return res.status(404).json({ error: "Order not found" });
    if (order.razorpayOrderId !== razorpay_order_id) return res.status(400).json({ error: "Payment order mismatch." });
    if (!verifyPaymentSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature)) {
      return res.status(400).json({ error: "Invalid Razorpay signature." });
    }
    const paidOrder = await markOrderPaid(order.id, { razorpayOrderId: razorpay_order_id, razorpayPaymentId: razorpay_payment_id });
    const jobs = (await readJSON("provisioning_jobs.json")) || [];
    const job = jobs.find((candidate: any) => candidate.orderId === paidOrder.id);
    if (job && job.status === "queued") {
      processProvisioningJob(job, paidOrder).catch((err) => console.error("[billing] provisioning failed", err));
    }
    res.json({ order: paidOrder });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/webhooks/razorpay", async (req, res) => {
  const signature = req.headers["x-razorpay-signature"];
  const rawBody = (req as any).rawBody || JSON.stringify(req.body || {});
  if (typeof signature !== "string" || !verifyWebhookSignature(rawBody, signature)) {
    return res.status(400).json({ error: "Invalid webhook signature." });
  }
  const event = req.body;
  if (event?.event === "payment.captured") {
    const razorpayOrderId = event.payload?.payment?.entity?.order_id;
    const razorpayPaymentId = event.payload?.payment?.entity?.id;
    const orders = (await readJSON("orders.json")) || [];
    const order = orders.find((candidate: any) => candidate.razorpayOrderId === razorpayOrderId);
    if (order) {
      await markOrderPaid(order.id, { razorpayOrderId, razorpayPaymentId });
      const jobs = (await readJSON("provisioning_jobs.json")) || [];
      const job = jobs.find((candidate: any) => candidate.orderId === order.id);
      if (job && job.status === "queued") {
        processProvisioningJob(job, order).catch((err) => console.error("[billing] provisioning failed", err));
      }
    }
  }
  res.json({ received: true });
});

router.post("/provisioning/:orderId/retry", async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin" && user.role !== "owner") return res.status(403).json({ error: "Forbidden" });
  const order = await getOrderForUser(req.params.orderId, user);
  const jobs = (await readJSON("provisioning_jobs.json")) || [];
  const job = jobs.find((candidate: any) => candidate.orderId === req.params.orderId);
  if (!order || !job) return res.status(404).json({ error: "Provisioning job not found" });
  processProvisioningJob(job, order).catch((err) => console.error("[billing] provisioning retry failed", err));
  res.json({ queued: true });
});

export default router;

