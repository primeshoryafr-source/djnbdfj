import { Button } from '../ui/Button';

export function FinalCTA() {
  return (
    <section className="final-cta">
      <div className="container">
        <h2>Ready to get your server?</h2>
        <p>Choose a hosting plan and get started with ZyntixCloud.</p>
        <Button to="/game-servers" icon>
          View Plans
        </Button>
      </div>
    </section>
  );
}
