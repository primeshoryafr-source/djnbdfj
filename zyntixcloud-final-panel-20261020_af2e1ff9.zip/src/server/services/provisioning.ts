import { readJSON, writeJSON } from "./db.js";
import { createServerRuntime } from "./runtime.js";
import { createSftpUser } from "./sftp.js";
import { downloadJar } from "./jarDownloader.js";
import { linkServiceToOrder, updateProvisioningJob, type BillingOrder } from "./billing.js";
import fs from "fs-extra";
import path from "path";
import crypto from "crypto";

function findFreePort(servers: any[]) {
  const start = Number(process.env.PROVISIONING_PORT_START || 25565);
  const end = Number(process.env.PROVISIONING_PORT_END || 29999);
  const used = new Set(servers.map((server) => Number(server.port)));
  for (let port = start; port <= end; port += 1) {
    if (!used.has(port)) return port;
  }
  throw new Error("No free ports are available for provisioning.");
}

export async function processProvisioningJob(job: any, order: BillingOrder) {
  await updateProvisioningJob(job.id, { status: "creating_service", attempts: (job.attempts || 0) + 1 });

  if (order.snapshot.product.kind !== "game" && order.snapshot.product.kind !== "bot") {
    throw new Error(`${order.snapshot.product.kind.toUpperCase()} provisioning provider is not configured.`);
  }

  const servers = (await readJSON("servers.json")) || [];
  const settings = (await readJSON("settings.json")) || {};
  const port = findFreePort(servers);
  const serverId = crypto.randomUUID();
  const plan = order.snapshot.plan;
  const software = String(order.config.software || (order.snapshot.product.kind === "bot" ? "NODEJS" : "PAPER")).toUpperCase();
  const serverData = {
    id: serverId,
    name: order.config.serverName || `${plan.name} Server`,
    owner: order.userId,
    ram: Math.max(1, Math.round((plan.memoryMb || 1024) / 1024)),
    cpu: plan.cpuPercent || 100,
    disk: Math.max(1, Math.round((plan.diskMb || 10240) / 1024)),
    port,
    ipAlias: String(settings.defaultIpAlias || "").trim(),
    runtimeType: process.env.DEFAULT_RUNTIME || "docker",
    nodeId: "local",
    type: software,
    version: order.config.version || "1.21.4",
    javaVersion: "",
    theme: "default",
    status: "installing",
    billingOrderId: order.id,
    productId: order.productId,
    planId: order.planId,
    productName: order.snapshot.product.name,
    planName: plan.name,
    location: order.snapshot.product.location,
    processor: order.snapshot.product.processor,
    createdAt: new Date().toISOString(),
    containerId: null as string | null,
  };

  servers.push(serverData);
  await writeJSON("servers.json", servers);
  await updateProvisioningJob(job.id, { status: "allocating_server", serviceId: serverId });

  const serverDir = path.join(process.cwd(), ".data", "servers", serverId);
  await fs.ensureDir(serverDir);

  if (["NODEJS", "NODE"].includes(software)) {
    await fs.writeJson(path.join(serverDir, "package.json"), {
      name: serverData.name.toLowerCase().replace(/[^a-z0-9_-]/g, "-") || "bot",
      version: "1.0.0",
      main: "index.js",
      scripts: { start: "node index.js" },
      dependencies: {},
    }, { spaces: 2 });
    await fs.writeFile(path.join(serverDir, "index.js"), `console.log("ZyntixCloud bot service ready on port ${port}");\n`);
  } else if (["PYTHON", "PYTHON3"].includes(software)) {
    await fs.writeFile(path.join(serverDir, "main.py"), `print("ZyntixCloud Python service ready on port ${port}")\n`);
    await fs.writeFile(path.join(serverDir, "requirements.txt"), "");
  } else {
    await fs.writeFile(path.join(serverDir, "eula.txt"), "eula=true\n");
    await fs.writeFile(path.join(serverDir, "server.properties"), `server-port=${port}\nquery.port=${port}\nmotd=ZyntixCloud ${plan.name}\n`);
    await updateProvisioningJob(job.id, { status: "installing_selected_version" });
    await downloadJar(software, order.config.version || "1.21.4", path.join(serverDir, "server.jar")).catch((err) => {
      throw new Error(`Unable to install selected version: ${err.message}`);
    });
  }

  const containerId = await createServerRuntime(serverData);
  serverData.containerId = containerId;
  serverData.status = "offline";
  const latestServers = (await readJSON("servers.json")) || [];
  const index = latestServers.findIndex((server: any) => server.id === serverId);
  if (index !== -1) {
    latestServers[index] = serverData;
    await writeJSON("servers.json", latestServers);
  }
  await createSftpUser(serverId).catch(() => null);
  await linkServiceToOrder(order.id, serverId);
  await updateProvisioningJob(job.id, { status: "ready", serviceId: serverId, lastError: null });
  return serverData;
}

