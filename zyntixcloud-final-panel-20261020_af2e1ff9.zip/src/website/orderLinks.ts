import type { HostingPlan, HostingProduct } from "./data/products";

const slugPart = (value: string) =>
  value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const productMap: Record<string, { productId: string; planPrefix?: string; planMap?: Record<string, string> }> = {
  "/game-servers/budget": { productId: "game-budget-india-xeon", planPrefix: "budget" },
  "/game-servers/premium": { productId: "game-premium-india-epyc", planPrefix: "premium" },
  "/bot-hosting": {
    productId: "bot-hosting-india",
    planMap: { "BOT 1": "bot-1", "BOT 2": "bot-2", "BOT 3": "bot-3" },
  },
};

export function getPanelOrderPath(product: HostingProduct, plan: HostingPlan) {
  const mapping = productMap[product.slug];
  if (!mapping) {
    const subject = encodeURIComponent(`Order request: ${product.title} - ${plan.name}`);
    return `/login?redirect=${encodeURIComponent(`/support-panel?subject=${subject}`)}`;
  }

  const planId = mapping.planMap?.[plan.name] || `${mapping.planPrefix}-${slugPart(plan.name)}`;
  return `/login?redirect=${encodeURIComponent(`/order/${mapping.productId}?plan=${planId}`)}`;
}
