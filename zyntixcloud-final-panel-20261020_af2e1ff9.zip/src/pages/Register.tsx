import { FormEvent, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { useSettings } from "../context/SettingsContext";
import "./Login.css";

export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { enableRegistration } = useSettings();
  const navigate = useNavigate();

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");

    if (enableRegistration === false) {
      setError("Registration is currently disabled.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setIsLoading(true);
    try {
      await axios.post("/api/auth/register", {
        username: username.trim(),
        password,
        confirmPassword,
      });
      navigate("/login");
    } catch (err: any) {
      setError(err.response?.data?.error || "Registration failed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="nx-auth-shell">
      <div className="nx-auth-bg" />
      <section className="nx-auth-left" aria-label="ZyntixCloud hosting">
        <div className="nx-brand">
          <span className="nx-mark">
            <img src="/zyntixcloud-logo.png" alt="ZyntixCloud" />
          </span>
          <span>ZyntixCloud</span>
        </div>

        <div className="nx-hero-copy">
          <p className="nx-kicker">INDIA GAME SERVER HOSTING</p>
          <h1>Fast Minecraft hosting without the noise.</h1>
          <p className="nx-subcopy">
            Manage paid servers, deploy after payment, and keep everything simple from one ZyntixCloud panel.
          </p>
        </div>

        <div className="nx-stats" aria-label="Plan highlights">
          <div>
            <span>FROM</span>
            <strong>₹40/mo</strong>
          </div>
          <div>
            <span>STORAGE</span>
            <strong>NVMe</strong>
          </div>
          <div>
            <span>SETUP</span>
            <strong>Instant</strong>
          </div>
        </div>
      </section>

      <section className="nx-auth-card nx-register-card" aria-label="Register form">
        <p className="nx-card-eyebrow">ZyntixCloud Panel</p>
        <h2>Register</h2>
        <p className="nx-card-copy">Create your account to deploy and manage servers.</p>

        <form onSubmit={handleSubmit} className="nx-form">
          {error && <div className="nx-error">{error}</div>}

          <label>
            <span>Username or email</span>
            <input
              autoComplete="username"
              disabled={isLoading}
              onChange={(event) => setUsername(event.target.value)}
              required
              type="text"
              value={username}
            />
          </label>

          <label>
            <span>Password</span>
            <input
              autoComplete="new-password"
              disabled={isLoading}
              onChange={(event) => setPassword(event.target.value)}
              required
              type="password"
              value={password}
            />
          </label>

          <label>
            <span>Confirm password</span>
            <input
              autoComplete="new-password"
              disabled={isLoading}
              onChange={(event) => setConfirmPassword(event.target.value)}
              required
              type="password"
              value={confirmPassword}
            />
          </label>

          <button className="nx-submit" disabled={isLoading || enableRegistration === false} type="submit">
            {isLoading ? "Creating..." : "Register"}
          </button>
        </form>

        <p className="nx-switch">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </section>
    </main>
  );
}
