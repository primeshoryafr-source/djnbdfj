import { Check, Cpu, HardDrive, MapPin, Network, ShieldCheck } from 'lucide-react';
import { HostingProduct } from '../../data/products';
import { Button } from '../ui/Button';
import { SectionHeader } from '../common/SectionHeader';
import { FAQ } from '../common/FAQ';
import { FinalCTA } from '../common/FinalCTA';
import { ScrollReveal } from '../common/ScrollReveal';
import { getPanelOrderPath } from '../../orderLinks';
import gameImage from '../../assets/dezerx/banners/minecraft-banners.webp';
import premiumGameImage from '../../assets/dezerx/banners/rust-banner-2.webp';
import botImage from '../../assets/dezerx/banners/node.webp';
import vpsImage from '../../assets/dezerx/vps.png';
import dedicatedImage from '../../assets/dezerx/dedicated.webp';

export function setSeo(title: string, description: string) {
  document.title = title;
  let meta = document.querySelector('meta[name="description"]');
  if (!meta) {
    meta = document.createElement('meta');
    meta.setAttribute('name', 'description');
    document.head.appendChild(meta);
  }
  meta.setAttribute('content', description);
}

function PlanCard({ product, plan }: { product: HostingProduct; plan: HostingProduct['plans'][number] }) {
  return (
    <div className="plan-card">
      <div className="plan-head">
        <h3>{plan.name}</h3>
        {plan.popular && <span>Popular</span>}
      </div>
      <div className="price"><strong>{plan.price}</strong><span>/month</span></div>
      <dl>
        <div><dt>RAM</dt><dd>{plan.ram}</dd></div>
        <div><dt>CPU</dt><dd>{plan.cpu}</dd></div>
        <div><dt>Storage</dt><dd>{plan.storage}</dd></div>
      </dl>
      <Button to={getPanelOrderPath(product, plan)} variant="secondary" className="full">Deploy Server</Button>
    </div>
  );
}

function productImage(product: HostingProduct) {
  if (product.slug.includes('premium')) return premiumGameImage;
  if (product.slug.includes('game-servers')) return gameImage;
  if (product.slug.includes('bot-hosting')) return botImage;
  if (product.slug.includes('/vds/')) return dedicatedImage;
  return vpsImage;
}

export function ProductPage({ product }: { product: HostingProduct }) {
  setSeo(product.titleTag, product.meta);
  return (
    <>
      <section className="product-hero">
        <div className="container product-hero-grid">
          <ScrollReveal>
            <p className="eyebrow">{product.eyebrow}</p>
            <h1>{product.title}</h1>
            <p>{product.description}</p>
            <div className="product-actions">
              <Button to="#plans" icon>View Plans</Button>
              <span>All prices are exclusive of applicable taxes.</span>
            </div>
          </ScrollReveal>
          <ScrollReveal className="product-summary" delay={0.1}>
            <div>
              <span>Starting at</span>
              <strong>{product.starting}</strong>
            </div>
            <p><MapPin size={16} /> {product.location}</p>
            <p><ShieldCheck size={16} /> DDoS protection on supported infrastructure</p>
            <p><HardDrive size={16} /> NVMe SSD storage</p>
            <p><Network size={16} /> {product.panel}</p>
          </ScrollReveal>
        </div>
      </section>
      {product.processors && (
        <section className="section small-section">
          <div className="container processor-box">
            <div>
              <p className="eyebrow">PROCESSORS</p>
              <h2>Processor information</h2>
            </div>
            <div className="processor-list">
              {product.processors.map((processor) => <span key={processor}><Cpu size={16} />{processor}</span>)}
            </div>
          </div>
        </section>
      )}
      <section className="section" id="plans">
        <div className="container">
          <SectionHeader title="Choose a plan." description="Select the server resources that fit your workload." />
          <div className="plan-grid">
            {product.plans.map((plan) => <PlanCard key={plan.name} product={product} plan={plan} />)}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container included-layout">
          <SectionHeader title="Included with this product." />
          <div className="included-grid">
            {product.features.map((feature) => (
              <div key={feature}>
                <Check size={17} />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <SectionHeader title="Product visual." description="A closer look at the hosting category and hardware style for this plan group." />
          <div className="product-visual">
            <img src={productImage(product)} alt={product.title} />
          </div>
        </div>
      </section>
      <FAQ />
      <FinalCTA />
    </>
  );
}

export function OptionsPage({ eyebrow, title, description, options }: { eyebrow?: string; title: string; description: string; options: { title: string; price: string; text?: string; meta?: string; chip?: string; to: string }[] }) {
  setSeo(`${title.replace('.', '')} | ZyntixCloud`, description);
  return (
    <>
      <section className="product-hero">
        <div className="container">
          {eyebrow && <p className="eyebrow">{eyebrow}</p>}
          <h1>{title}</h1>
          <p>{description}</p>
        </div>
      </section>
      <section className="section">
        <div className="container option-list">
          {options.map((option) => (
            <ScrollReveal className="option-row" key={option.to}>
              <div>
                <span>{option.chip || option.meta}</span>
                <h2>{option.title}</h2>
                <p>{option.text || option.meta}</p>
              </div>
              <strong>{option.price}</strong>
              <Button to={option.to} icon>View Plans</Button>
            </ScrollReveal>
          ))}
        </div>
      </section>
      <FinalCTA />
    </>
  );
}
