import { Link } from "react-router-dom";

export default function Cart() {
  const saved = sessionStorage.getItem("lixcloud_cart");
  const orderId = saved ? JSON.parse(saved).orderId : null;
  return (
    <div className="mx-auto max-w-2xl rounded-lg border border-border-subtle bg-muted-subtle p-8">
      <h1 className="text-2xl font-semibold text-foreground">Cart</h1>
      {orderId ? (
        <div className="mt-4 text-sm text-muted-foreground">
          You have an order in progress.
          <div className="mt-5">
            <Link className="inline-flex h-10 items-center justify-center rounded-lg bg-white px-4 font-semibold text-black" to={`/billing/payment/${orderId}`}>Continue order</Link>
          </div>
        </div>
      ) : (
        <div className="mt-4 text-sm text-muted-foreground">
          Your cart is empty.
          <div className="mt-5">
            <Link className="inline-flex h-10 items-center justify-center rounded-lg bg-white px-4 font-semibold text-black" to="/store">View Plans</Link>
          </div>
        </div>
      )}
    </div>
  );
}

