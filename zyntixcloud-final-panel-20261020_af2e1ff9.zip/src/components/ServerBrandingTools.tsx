import React, { useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";
import {
  AlertTriangle,
  Check,
  ImageIcon,
  Loader2,
  MessageSquare,
  RefreshCw,
  Save,
  Sparkles,
  Upload,
  Wand2,
} from "lucide-react";

interface ServerBrandingToolsProps {
  serverId: string;
  server?: {
    name?: string;
    port?: number | string;
    type?: string;
  };
}

type PropsMap = Record<string, string>;

const PRESETS = [
  { label: "Clean", value: "ZyntixCloud Hosting | Fast NVMe Servers" },
  { label: "Survival", value: "ZyntixCloud Survival | SMP, Economy, Events" },
  { label: "Network", value: "ZyntixCloud Network | Minigames, Survival, PvP" },
  { label: "Premium", value: "Premium Minecraft Hosting by ZyntixCloud" },
];

function parseProperties(content: string): PropsMap {
  const parsed: PropsMap = {};
  for (const line of content.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith("#")) continue;
    const idx = line.indexOf("=");
    if (idx === -1) continue;
    parsed[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
  }
  return parsed;
}

function serializeProperties(original: string, updates: PropsMap): string {
  const lines = original.trim() ? original.split(/\r?\n/) : [];
  const seen = new Set<string>();
  const next = lines.map((line) => {
    if (!line.trim() || line.trim().startsWith("#")) return line;
    const idx = line.indexOf("=");
    if (idx === -1) return line;
    const key = line.slice(0, idx).trim();
    if (updates[key] === undefined) return line;
    seen.add(key);
    return `${key}=${updates[key]}`;
  });

  for (const [key, value] of Object.entries(updates)) {
    if (!seen.has(key)) next.push(`${key}=${value}`);
  }

  return `${next.join("\n").trim()}\n`;
}

async function makeServerIcon(file: File): Promise<File> {
  const imageUrl = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Could not load image"));
      img.src = imageUrl;
    });

    const canvas = document.createElement("canvas");
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas is unavailable");

    ctx.clearRect(0, 0, 64, 64);
    const side = Math.min(image.width, image.height);
    const sx = (image.width - side) / 2;
    const sy = (image.height - side) / 2;
    ctx.drawImage(image, sx, sy, side, side, 0, 0, 64, 64);

    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("Could not export image");
    return new File([blob], "server-icon.png", { type: "image/png" });
  } finally {
    URL.revokeObjectURL(imageUrl);
  }
}

export default function ServerBrandingTools({ serverId, server }: ServerBrandingToolsProps) {
  const [content, setContent] = useState("");
  const [properties, setProperties] = useState<PropsMap>({});
  const [motd, setMotd] = useState("");
  const [previewIcon, setPreviewIcon] = useState<string | null>(null);
  const [selectedIcon, setSelectedIcon] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isMinecraft = useMemo(() => {
    const type = String(server?.type || "").toLowerCase();
    return !["nodejs", "python"].includes(type);
  }, [server?.type]);

  const loadBranding = async () => {
    try {
      setLoading(true);
      setMessage(null);
      const res = await axios.get(`/api/servers/${serverId}/files?path=server.properties`);
      const fileContent = res.data?.isFile ? String(res.data.content || "") : "";
      const parsed = parseProperties(fileContent);
      setContent(fileContent);
      setProperties(parsed);
      setMotd(parsed.motd || `ZyntixCloud ${server?.name || "Server"}`);
    } catch {
      const fallback = `server-port=${server?.port || 25565}\nquery.port=${server?.port || 25565}\nmotd=ZyntixCloud ${server?.name || "Server"}\n`;
      const parsed = parseProperties(fallback);
      setContent(fallback);
      setProperties(parsed);
      setMotd(parsed.motd);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBranding();
  }, [serverId]);

  const pickIcon = async (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setMessage({ type: "error", text: "Please select a PNG, JPG, or WebP image." });
      return;
    }
    try {
      const icon = await makeServerIcon(file);
      setSelectedIcon(icon);
      setPreviewIcon(URL.createObjectURL(icon));
      setMessage(null);
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || "Could not prepare the icon." });
    }
  };

  const saveMotd = async () => {
    try {
      setSaving(true);
      setMessage(null);
      const next = serializeProperties(content, {
        ...properties,
        motd: motd.trim() || "A Minecraft Server",
        "server-port": properties["server-port"] || String(server?.port || 25565),
        "query.port": properties["query.port"] || String(server?.port || 25565),
      });
      await axios.post(`/api/servers/${serverId}/files/save`, {
        filePath: "server.properties",
        content: next,
      });
      setContent(next);
      setProperties(parseProperties(next));
      setMessage({ type: "success", text: "MOTD saved. Restart the server to apply it." });
    } catch (error: any) {
      setMessage({ type: "error", text: error?.response?.data?.error || "Failed to save MOTD." });
    } finally {
      setSaving(false);
    }
  };

  const uploadIcon = async () => {
    if (!selectedIcon) {
      setMessage({ type: "error", text: "Select a logo first." });
      return;
    }

    try {
      setSaving(true);
      setMessage(null);
      const data = new FormData();
      data.append("path", "/");
      data.append("file", selectedIcon);
      await axios.post(`/api/servers/${serverId}/files/upload`, data, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessage({ type: "success", text: "Logo imported as server-icon.png. Restart the server to apply it." });
    } catch (error: any) {
      setMessage({ type: "error", text: error?.response?.data?.error || "Failed to upload logo." });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 grid place-items-center p-8">
        <div className="flex items-center gap-3 text-sm text-white/70">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading branding tools...
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5">
        <div className="rounded-2xl border border-white/12 bg-white/[0.035] p-5">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl border border-white/15 bg-white/10">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold tracking-tight text-white">Server Branding</h2>
                  <p className="text-xs text-white/45">MOTD maker and logo importer for the Minecraft server list.</p>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={loadBranding}
              className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-white/12 bg-black/30 px-4 text-sm font-semibold text-white/80 transition hover:border-white/30 hover:bg-white/10"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </button>
          </div>

          {!isMinecraft && (
            <div className="mt-4 flex gap-3 rounded-xl border border-white/15 bg-white/[0.05] p-3 text-sm text-white/75">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              These tools are made for Minecraft servers. They can still edit files, but non-Minecraft runtimes may ignore them.
            </div>
          )}
        </div>

        {message && (
          <div
            className={`flex items-center gap-2 rounded-xl border p-3 text-sm ${
              message.type === "success"
                ? "border-white/25 bg-white/[0.06] text-white"
                : "border-red-400/30 bg-red-400/10 text-red-100"
            }`}
          >
            {message.type === "success" ? <Check className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
            {message.text}
          </div>
        )}

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
          <section className="rounded-2xl border border-white/12 bg-white/[0.035] p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-xl border border-white/12 bg-white/10">
                <MessageSquare className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">MOTD Maker</h3>
                <p className="text-xs text-white/45">Keep it short, readable, and restart after saving.</p>
              </div>
            </div>

            <textarea
              value={motd}
              onChange={(event) => setMotd(event.target.value)}
              rows={4}
              maxLength={160}
              className="min-h-[112px] w-full resize-none rounded-xl border border-white/12 bg-black/45 px-4 py-3 text-sm text-white outline-none transition placeholder:text-white/25 focus:border-white/45 focus:ring-2 focus:ring-white/10"
              placeholder="ZyntixCloud Survival | Fast NVMe Hosting"
            />
            <div className="mt-2 flex items-center justify-between text-[11px] text-white/40">
              <span>Supports normal Minecraft formatting codes if your server allows them.</span>
              <span>{motd.length}/160</span>
            </div>

            <div className="mt-4 grid gap-2 sm:grid-cols-4">
              {PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setMotd(preset.value)}
                  className="rounded-xl border border-white/12 bg-white/[0.045] px-3 py-2 text-xs font-semibold text-white/75 transition hover:border-white/30 hover:bg-white/10"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="mt-5 rounded-xl border border-white/10 bg-white/[0.035] p-4">
              <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">Preview</div>
              <div className="rounded-lg border border-white/10 bg-black/60 p-3">
                <div className="font-semibold text-white">{server?.name || "Minecraft Server"}</div>
                <div className="mt-1 text-sm text-white/60">{motd || "A Minecraft Server"}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={saveMotd}
              disabled={saving}
              className="mt-5 inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-white px-5 text-sm font-semibold text-black transition hover:bg-white/90 disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save MOTD
            </button>
          </section>

          <section className="rounded-2xl border border-white/12 bg-white/[0.035] p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-xl border border-white/12 bg-white/10">
                <ImageIcon className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Logo Importer</h3>
                <p className="text-xs text-white/45">Converts any image to 64x64 `server-icon.png`.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => {
                event.preventDefault();
                pickIcon(event.dataTransfer.files?.[0]);
              }}
              className="flex min-h-[220px] w-full flex-col items-center justify-center rounded-2xl border border-dashed border-white/20 bg-white/[0.035] p-5 text-center transition hover:border-white/40 hover:bg-white/[0.06]"
            >
              {previewIcon ? (
                <img src={previewIcon} alt="Server icon preview" className="h-24 w-24 rounded-2xl border border-white/20 bg-black object-cover" />
              ) : (
                <div className="grid h-20 w-20 place-items-center rounded-2xl border border-white/15 bg-black/45">
                  <Upload className="h-7 w-7 text-white/70" />
                </div>
              )}
              <span className="mt-4 text-sm font-semibold text-white">Choose or drop logo</span>
              <span className="mt-1 text-xs text-white/40">PNG, JPG, WebP. Auto-cropped to square.</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(event) => pickIcon(event.target.files?.[0])}
            />

            <button
              type="button"
              onClick={uploadIcon}
              disabled={saving || !selectedIcon}
              className="mt-5 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-white px-5 text-sm font-semibold text-black transition hover:bg-white/90 disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
              Import Logo
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
