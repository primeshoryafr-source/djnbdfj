import { FormEvent, useState } from "react";
import axios from "axios";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./Login.css";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const getRedirectPath = () => {
    const redirect = searchParams.get("redirect") || "/dashboard";
    if (!redirect.startsWith("/") || redirect.startsWith("//")) return "/dashboard";
    if (redirect === "/" || redirect.startsWith("/login") || redirect.startsWith("/register")) return "/dashboard";
    return redirect;
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const res = await axios.post("/api/auth/login", { username, password });
      const { token, user } = res.data || {};
      if (!token || !user?.id) {
        setError("Invalid server response. Please try again.");
        return;
      }
      login(token, user);
      navigate(getRedirectPath());
    } catch (err: any) {
      setError(err.response?.data?.error || "Invalid username or password");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="nx-auth-shell">
      <div className="nx-auth-bg" />
      <section className="nx-auth-left" aria-label="ZyntixCloud hosting">
        <div className="nx-brand">
          <span className="nx-mark">
            <img src="/zyntixcloud-logo.png" alt="ZyntixCloud" />
          </span>
          <span>ZyntixCloud</span>
        </div>

        <div className="nx-hero-copy">
          <p className="nx-kicker">INDIA GAME SERVER HOSTING</p>
          <h1>Fast Minecraft hosting without the noise.</h1>
          <p className="nx-subcopy">
            Manage paid servers, deploy after payment, and keep everything simple from one ZyntixCloud panel.
          </p>
        </div>

        <div className="nx-stats" aria-label="Plan highlights">
          <div>
            <span>FROM</span>
            <strong>₹40/mo</strong>
          </div>
          <div>
            <span>STORAGE</span>
            <strong>NVMe</strong>
          </div>
          <div>
            <span>SETUP</span>
            <strong>Instant</strong>
          </div>
        </div>
      </section>

      <section className="nx-auth-card" aria-label="Sign in form">
        <p className="nx-card-eyebrow">ZyntixCloud Panel</p>
        <h2>Sign in</h2>
        <p className="nx-card-copy">Access your servers, invoices, and hosting plans.</p>

        <form onSubmit={handleSubmit} className="nx-form">
          {error && <div className="nx-error">{error}</div>}

          <label>
            <span>Username or email</span>
            <input
              autoComplete="username"
              disabled={isLoading}
              onChange={(event) => setUsername(event.target.value)}
              required
              type="text"
              value={username}
            />
          </label>

          <label>
            <span>Password</span>
            <input
              autoComplete="current-password"
              disabled={isLoading}
              onChange={(event) => setPassword(event.target.value)}
              required
              type="password"
              value={password}
            />
          </label>

          <div className="nx-row">
            <label className="nx-check">
              <input checked={remember} onChange={(event) => setRemember(event.target.checked)} type="checkbox" />
              <span>Remember me</span>
            </label>
            <a href="#" onClick={(event) => event.preventDefault()}>
              Forgot password?
            </a>
          </div>

          <button className="nx-submit" disabled={isLoading} type="submit">
            {isLoading ? "Signing in..." : "Sign in"}
          </button>
        </form>

        <p className="nx-switch">
          Need an account? <Link to="/register">Register</Link>
        </p>
      </section>
    </main>
  );
}
