import { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Bot, ChevronDown, Cpu, Gamepad2, Menu, Server, X } from 'lucide-react';
import logo from '../../assets/zyntixcloud-logo.png';

const menus = {
  game: [
    { label: 'Budget Game Servers', desc: 'Intel Xeon plans in India', to: '/game-servers/budget', icon: Gamepad2 },
    { label: 'Premium Game Servers', desc: 'AMD EPYC with ECC memory', to: '/game-servers/premium', icon: Server },
  ],
  vps: [
    { label: 'India Intel VPS', desc: 'From ₹399/mo', to: '/vps/india-intel', icon: Cpu },
    { label: 'India AMD VPS', desc: 'From ₹449/mo', to: '/vps/india-amd', icon: Cpu },
    { label: 'India Ryzen VPS', desc: 'From ₹699/mo', to: '/vps/india-ryzen', icon: Cpu },
    { label: 'Germany Intel VPS', desc: 'From ₹449/mo', to: '/vps/germany-intel', icon: Cpu },
    { label: 'Singapore AMD VPS', desc: 'From ₹1,099/mo', to: '/vps/singapore-amd', icon: Cpu },
  ],
  vds: [
    { label: 'Intel VDS', desc: 'Dedicated Intel cores', to: '/vds/intel', icon: Server },
    { label: 'AMD VDS', desc: 'Dedicated AMD EPYC cores', to: '/vds/amd', icon: Server },
  ],
};

function Dropdown({ name, label, open, setOpen }: { name: keyof typeof menus; label: string; open: string | null; setOpen: (v: string | null) => void }) {
  return (
    <div className="nav-drop" onMouseEnter={() => setOpen(name)} onMouseLeave={() => setOpen(null)}>
      <button aria-expanded={open === name}>
        {label}
        <ChevronDown size={14} />
      </button>
      <AnimatePresence>
        {open === name && (
          <motion.div className="dropdown" initial={{ opacity: 0, y: -5, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -5, scale: 0.98 }} transition={{ duration: 0.16 }}>
            {menus[name].map((item) => {
              const Icon = item.icon;
              return (
                <Link to={item.to} key={item.to}>
                  <Icon size={17} />
                  <span>
                    <strong>{item.label}</strong>
                    <small>{item.desc}</small>
                  </span>
                </Link>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`} aria-label="Main navigation">
        <div className="nav-inner">
          <Link to="/" className="brand" aria-label="ZyntixCloud home">
            <img src={logo} alt="ZyntixCloud" />
            <span>ZyntixCloud</span>
          </Link>
          <div className="nav-links">
            <Dropdown name="game" label="Game Servers" open={open} setOpen={setOpen} />
            <Dropdown name="vps" label="VPS" open={open} setOpen={setOpen} />
            <Dropdown name="vds" label="VDS" open={open} setOpen={setOpen} />
            <NavLink to="/bot-hosting">Bot Hosting</NavLink>
            <NavLink to="/#locations">Locations</NavLink>
            <NavLink to="/support">Support</NavLink>
          </div>
          <div className="nav-actions">
            <Link to="/login">Login</Link>
            <Link to="/game-servers" className="start">Get Started</Link>
          </div>
          <button className="menu-btn" onClick={() => setMobile(true)} aria-label="Open menu">
            <Menu size={20} />
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {mobile && (
          <motion.div className="mobile-menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <button className="mobile-close" onClick={() => setMobile(false)} aria-label="Close menu">
              <X />
            </button>
            <Link to="/" onClick={() => setMobile(false)} className="mobile-logo">
              <img src={logo} alt="ZyntixCloud" /> ZyntixCloud
            </Link>
            {[...menus.game, ...menus.vps, ...menus.vds, { label: 'Bot Hosting', to: '/bot-hosting', desc: 'Discord bots', icon: Bot }].map((item) => (
              <Link key={item.to} to={item.to} onClick={() => setMobile(false)}>
                <strong>{item.label}</strong>
                <span>{item.desc}</span>
              </Link>
            ))}
            <Link to="/support" onClick={() => setMobile(false)}>Support</Link>
            <Link to="/login" onClick={() => setMobile(false)}>Login</Link>
            <Link to="/game-servers" className="mobile-primary" onClick={() => setMobile(false)}>Get Started</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
