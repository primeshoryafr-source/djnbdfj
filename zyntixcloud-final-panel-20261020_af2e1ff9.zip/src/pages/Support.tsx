import { BookOpen, LifeBuoy, MessageCircle, Server } from "lucide-react";

const supportOptions = [
  {
    title: "Billing Help",
    description: "Check invoices, payments, and active orders from the billing area.",
    action: "Open Billing",
    href: "/billing",
    icon: BookOpen,
  },
  {
    title: "Server Help",
    description: "Open your server page to manage console, files, players, MOTD, logo, plugins, and mods.",
    action: "View Servers",
    href: "/servers",
    icon: Server,
  },
  {
    title: "Discord Tickets",
    description: "Join the ZyntixCloud Discord and create a ticket for support.",
    action: "Join Discord",
    href: "https://discord.gg/zyntixcloud",
    icon: MessageCircle,
  },
];

export default function Support() {
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <section className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">
        <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/[0.06]">
              <LifeBuoy className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-white/40">Support</p>
              <h1 className="text-2xl font-semibold text-white">Help Center</h1>
            </div>
          </div>
          <div className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-medium uppercase tracking-[0.16em] text-white/45">
            Direct support
          </div>
        </div>
        <p className="mt-5 max-w-2xl text-sm leading-6 text-white/55">
          Use billing, server tools, or Discord tickets for support.
        </p>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {supportOptions.map((option) => {
          const Icon = option.icon;
          return (
            <a
              key={option.title}
              href={option.href}
              className="rounded-2xl border border-white/10 bg-[#080B10] p-5 transition hover:border-white/20 hover:bg-white/[0.045]"
            >
              <div className="mb-4 grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.05]">
                <Icon className="h-5 w-5 text-white/75" />
              </div>
              <h2 className="text-lg font-semibold text-white">{option.title}</h2>
              <p className="mt-2 min-h-[72px] text-sm leading-6 text-white/50">{option.description}</p>
              <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-white">
                {option.action}
              </span>
            </a>
          );
        })}
      </section>

      <section className="rounded-2xl border border-white/10 bg-white/[0.025] p-6">
        <div className="flex items-start gap-3">
          <MessageCircle className="mt-1 h-5 w-5 text-white/60" />
          <div>
            <h2 className="text-lg font-semibold text-white">Need faster help?</h2>
            <p className="mt-2 text-sm leading-6 text-white/50">
              Join discord.gg/zyntixcloud and create a ticket for faster help from the ZyntixCloud team.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
