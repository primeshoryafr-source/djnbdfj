import { useLocation } from "react-router-dom";
import "./styles.css";
import { Layout } from "./components/layout/Layout";
import { ProductPage } from "./components/hosting/ProductPage";
import { products } from "./data/products";
import { Home } from "./pages/Home";
import { GameServers } from "./pages/game-servers/GameServers";
import { VPS } from "./pages/vps/VPS";
import { VDS } from "./pages/vds/VDS";
import { About } from "./pages/About";
import { Support } from "./pages/Support";

export default function WebsiteApp() {
  const { pathname } = useLocation();

  const page = (() => {
    switch (pathname) {
      case "/":
        return <Home />;
      case "/game-servers":
        return <GameServers />;
      case "/game-servers/budget":
        return <ProductPage product={products.budgetGame} />;
      case "/game-servers/premium":
        return <ProductPage product={products.premiumGame} />;
      case "/bot-hosting":
        return <ProductPage product={products.bot} />;
      case "/vps":
        return <VPS />;
      case "/vps/india-intel":
        return <ProductPage product={products.indiaIntel} />;
      case "/vps/india-amd":
        return <ProductPage product={products.indiaAmd} />;
      case "/vps/india-ryzen":
        return <ProductPage product={products.indiaRyzen} />;
      case "/vps/germany-intel":
        return <ProductPage product={products.germanyIntel} />;
      case "/vps/singapore-amd":
        return <ProductPage product={products.singaporeAmd} />;
      case "/vds":
        return <VDS />;
      case "/vds/intel":
        return <ProductPage product={products.intelVds} />;
      case "/vds/amd":
        return <ProductPage product={products.amdVds} />;
      case "/about":
        return <About />;
      case "/support":
        return <Support />;
      default:
        return <Home />;
    }
  })();

  return (
    <Layout>
      {page}
    </Layout>
  );
}
