import crypto from "crypto";
import { readJSON, writeJSON } from "./db.js";
import { findPlan, type CatalogPlan, type CatalogProduct } from "./catalog.js";

const ORDERS_FILE = "orders.json";
const INVOICES_FILE = "invoices.json";
const PAYMENTS_FILE = "payments.json";
const JOBS_FILE = "provisioning_jobs.json";

export interface OrderConfig {
  serverName?: string;
  software?: string;
  version?: string;
  runtime?: string;
  hostname?: string;
  operatingSystem?: string;
}

export interface BillingOrder {
  id: string;
  userId: string;
  productId: string;
  planId: string;
  status: "pending_payment" | "paid" | "payment_failed" | "provisioning" | "ready" | "failed";
  subtotalPaise: number;
  taxPaise: number;
  totalPaise: number;
  currency: "INR";
  config: OrderConfig;
  snapshot: {
    product: Pick<CatalogProduct, "id" | "name" | "kind" | "category" | "location" | "processor">;
    plan: CatalogPlan;
  };
  razorpayOrderId?: string;
  invoiceId: string;
  serviceId?: string;
  createdAt: string;
  updatedAt: string;
}

function now() {
  return new Date().toISOString();
}

function taxFor(subtotalPaise: number) {
  const rawRate = process.env.BILLING_TAX_RATE || "0";
  const rate = Number(rawRate);
  if (!Number.isFinite(rate) || rate < 0) return 0;
  return Math.round(subtotalPaise * rate);
}

export async function listOrdersForUser(user: any) {
  const orders = (await readJSON(ORDERS_FILE)) || [];
  if (user.role === "admin" || user.role === "owner") return orders;
  return orders.filter((order: BillingOrder) => order.userId === user.id);
}

export async function getOrderForUser(orderId: string, user: any) {
  const orders = (await readJSON(ORDERS_FILE)) || [];
  const order = orders.find((candidate: BillingOrder) => candidate.id === orderId);
  if (!order) return null;
  if (user.role !== "admin" && user.role !== "owner" && order.userId !== user.id) return null;
  return order;
}

export async function createOrder(user: any, productId: string, planId: string, config: OrderConfig = {}) {
  const match = findPlan(productId, planId);
  if (!match) throw new Error("Selected product or plan was not found.");
  const { product, plan } = match;
  if (!product.available) throw new Error(product.unavailableReason || "This product is not available.");

  const software = String(config.software || product.defaultSoftware || "").toUpperCase();
  if (product.allowedSoftware.length && software && !product.allowedSoftware.includes(software)) {
    throw new Error("Selected software is not available for this product.");
  }

  const subtotalPaise = plan.pricePaise;
  const taxPaise = taxFor(subtotalPaise);
  const totalPaise = subtotalPaise + taxPaise;
  const id = crypto.randomUUID();
  const invoiceId = crypto.randomUUID();
  const timestamp = now();

  const order: BillingOrder = {
    id,
    userId: user.id,
    productId: product.id,
    planId: plan.id,
    status: "pending_payment",
    subtotalPaise,
    taxPaise,
    totalPaise,
    currency: "INR",
    config: {
      serverName: String(config.serverName || `${plan.name} Server`).slice(0, 48),
      software: software || product.defaultSoftware,
      version: String(config.version || product.defaultVersion || ""),
      runtime: product.kind === "bot" ? software || product.defaultSoftware : undefined,
      hostname: config.hostname,
      operatingSystem: config.operatingSystem,
    },
    snapshot: {
      product: {
        id: product.id,
        name: product.name,
        kind: product.kind,
        category: product.category,
        location: product.location,
        processor: product.processor,
      },
      plan,
    },
    invoiceId,
    createdAt: timestamp,
    updatedAt: timestamp,
  };

  const orders = (await readJSON(ORDERS_FILE)) || [];
  orders.push(order);
  await writeJSON(ORDERS_FILE, orders);

  const invoices = (await readJSON(INVOICES_FILE)) || [];
  invoices.push({
    id: invoiceId,
    orderId: id,
    userId: user.id,
    status: "pending",
    subtotalPaise,
    taxPaise,
    totalPaise,
    currency: "INR",
    createdAt: timestamp,
    paidAt: null,
  });
  await writeJSON(INVOICES_FILE, invoices);

  return order;
}

export async function attachRazorpayOrder(orderId: string, razorpayOrderId: string) {
  const orders = (await readJSON(ORDERS_FILE)) || [];
  const index = orders.findIndex((order: BillingOrder) => order.id === orderId);
  if (index === -1) throw new Error("Order not found.");
  orders[index].razorpayOrderId = razorpayOrderId;
  orders[index].updatedAt = now();
  await writeJSON(ORDERS_FILE, orders);
  return orders[index] as BillingOrder;
}

export async function markOrderPaid(orderId: string, payment: any) {
  const orders = (await readJSON(ORDERS_FILE)) || [];
  const orderIndex = orders.findIndex((order: BillingOrder) => order.id === orderId);
  if (orderIndex === -1) throw new Error("Order not found.");
  const order: BillingOrder = orders[orderIndex];

  const payments = (await readJSON(PAYMENTS_FILE)) || [];
  if (payment?.razorpayPaymentId && payments.some((p: any) => p.razorpayPaymentId === payment.razorpayPaymentId)) {
    return order;
  }

  payments.push({
    id: crypto.randomUUID(),
    orderId,
    invoiceId: order.invoiceId,
    userId: order.userId,
    provider: "razorpay",
    razorpayOrderId: payment?.razorpayOrderId,
    razorpayPaymentId: payment?.razorpayPaymentId,
    amountPaise: order.totalPaise,
    currency: order.currency,
    status: "captured",
    createdAt: now(),
  });
  await writeJSON(PAYMENTS_FILE, payments);

  order.status = order.serviceId ? "ready" : "provisioning";
  order.updatedAt = now();
  orders[orderIndex] = order;
  await writeJSON(ORDERS_FILE, orders);

  const invoices = (await readJSON(INVOICES_FILE)) || [];
  const invoice = invoices.find((candidate: any) => candidate.id === order.invoiceId);
  if (invoice && invoice.status !== "paid") {
    invoice.status = "paid";
    invoice.paidAt = now();
    await writeJSON(INVOICES_FILE, invoices);
  }

  await ensureProvisioningJob(order);
  return order;
}

export async function ensureProvisioningJob(order: BillingOrder) {
  const jobs = (await readJSON(JOBS_FILE)) || [];
  const existing = jobs.find((job: any) => job.orderId === order.id);
  if (existing) return existing;
  const job = {
    id: crypto.randomUUID(),
    orderId: order.id,
    userId: order.userId,
    status: "queued",
    attempts: 0,
    lastError: null,
    serviceId: null,
    createdAt: now(),
    updatedAt: now(),
  };
  jobs.push(job);
  await writeJSON(JOBS_FILE, jobs);
  return job;
}

export async function updateProvisioningJob(jobId: string, patch: any) {
  const jobs = (await readJSON(JOBS_FILE)) || [];
  const index = jobs.findIndex((job: any) => job.id === jobId);
  if (index === -1) return null;
  jobs[index] = { ...jobs[index], ...patch, updatedAt: now() };
  await writeJSON(JOBS_FILE, jobs);
  return jobs[index];
}

export async function linkServiceToOrder(orderId: string, serviceId: string) {
  const orders = (await readJSON(ORDERS_FILE)) || [];
  const index = orders.findIndex((order: BillingOrder) => order.id === orderId);
  if (index === -1) return null;
  orders[index].serviceId = serviceId;
  orders[index].status = "ready";
  orders[index].updatedAt = now();
  await writeJSON(ORDERS_FILE, orders);
  return orders[index];
}

