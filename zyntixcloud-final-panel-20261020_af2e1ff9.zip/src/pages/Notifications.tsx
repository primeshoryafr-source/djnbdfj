export default function Notifications() {
  return (
    <div className="rounded-lg border border-border-subtle bg-muted-subtle p-8">
      <h1 className="text-2xl font-semibold text-foreground">Notifications</h1>
      <p className="mt-2 text-sm text-muted-foreground">Meaningful billing and provisioning events are stored server-side; a dedicated notification feed can be connected here.</p>
    </div>
  );
}

