import { vdsOptions } from '../../data/products';
import { OptionsPage } from '../../components/hosting/ProductPage';

export function VDS() {
  return <OptionsPage title="Choose your VDS." description="VDS plans include dedicated CPU resources, ECC memory and NVMe storage." options={vdsOptions} />;
}
