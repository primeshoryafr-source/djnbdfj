import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  ['How long does server setup take?', 'Setup depends on the selected product and configuration. The included resources are prepared after the order is placed.'],
  ['Is DDoS protection included?', 'DDoS protection is included on supported ZyntixCloud infrastructure and listed hosting products.'],
  ['Can I upgrade my plan later?', 'Plan changes can be handled through support when upgrades are available for the selected product.'],
  ['Do VPS plans include root access?', 'Yes. VPS and VDS services include root access.'],
  ['Which locations are available?', 'ZyntixCloud services are available across India, Germany and Singapore depending on the product.'],
  ['Can I reinstall my VPS operating system?', 'Supported VPS and VDS plans include instant OS reinstall from the management panel.'],
  ['How do I contact support?', 'Join discord.gg/zyntixcloud and create a ticket in the official ZyntixCloud Discord server.'],
];

export function FAQ() {
  const [open, setOpen] = useState(0);
  return (
    <section className="section">
      <div className="container narrow">
        <div className="section-header compact">
          <p className="eyebrow">FAQ</p>
          <h2>Common questions.</h2>
        </div>
        <div className="faq">
          {faqs.map(([q, a], index) => (
            <div className="faq-item" key={q}>
              <button aria-expanded={open === index} onClick={() => setOpen(open === index ? -1 : index)}>
                <span>{q}</span>
                <ChevronDown className={open === index ? 'rotate' : ''} size={18} />
              </button>
              {open === index && <p>{a}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
