import { gameOptions } from '../../data/products';
import { OptionsPage } from '../../components/hosting/ProductPage';

export function GameServers() {
  return <OptionsPage eyebrow="GAME SERVER HOSTING" title="Choose your game server." description="Budget Intel Xeon plans and premium AMD EPYC plans are available in India." options={gameOptions} />;
}
