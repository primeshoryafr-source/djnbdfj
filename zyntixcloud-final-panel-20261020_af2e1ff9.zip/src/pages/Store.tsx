import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Bot, Cpu, HardDrive, MapPin, Server, ShieldAlert } from "lucide-react";
import { getCatalog, formatMoney, type CatalogProduct } from "../lib/billingApi";

const categoryLabels = {
  "game-servers": "Game Servers",
  "bot-hosting": "Bot Hosting",
  vps: "VPS",
  vds: "VDS",
};

export default function Store() {
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [category, setCategory] = useState<keyof typeof categoryLabels>("game-servers");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getCatalog().then(setProducts).finally(() => setLoading(false));
  }, []);

  const visible = useMemo(() => products.filter((product) => product.category === category), [products, category]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Store</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-foreground">Deploy a ZyntixCloud service</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">Choose a plan. Resources and pricing are calculated server-side before checkout.</p>
        </div>
        <Link to="/cart" className="btn-outline inline-flex h-10 items-center justify-center px-4 text-sm">Cart</Link>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {Object.entries(categoryLabels).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setCategory(key as keyof typeof categoryLabels)}
            className={`min-h-10 rounded-lg border px-4 text-sm font-medium ${category === key ? "border-border-strong bg-muted text-foreground" : "border-border-subtle text-muted-foreground hover:text-foreground"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="rounded-lg border border-border-subtle bg-muted-subtle p-8 text-sm text-muted-foreground">Loading catalog...</div>
      ) : (
        <div className="space-y-8">
          {visible.map((product) => (
            <section key={product.id} className="space-y-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{product.name}</h2>
                  <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    {product.location} - {product.processor}
                  </p>
                </div>
                {product.plans[0] && <span className="text-sm text-muted-foreground">Starting at {formatMoney(product.plans[0].pricePaise)}/month</span>}
              </div>

              {!product.available && (
                <div className="flex items-start gap-3 rounded-lg border border-amber-500/20 bg-amber-500/10 p-4 text-sm text-amber-100">
                  <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                  {product.unavailableReason}
                </div>
              )}

              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {product.plans.map((plan) => (
                  <article key={plan.id} className="rounded-lg border border-border-subtle bg-muted-subtle p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                          {plan.popular && <span className="rounded-md border border-border bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase text-foreground">Popular</span>}
                        </div>
                        <p className="mt-2 text-2xl font-semibold text-foreground">{formatMoney(plan.pricePaise)} <span className="text-sm font-normal text-muted-foreground">/ month</span></p>
                      </div>
                      {product.kind === "bot" ? <Bot className="h-5 w-5 text-muted-foreground" /> : <Server className="h-5 w-5 text-muted-foreground" />}
                    </div>
                    <dl className="mt-5 grid grid-cols-3 gap-3 text-sm">
                      <div><dt className="text-muted-foreground">Memory</dt><dd className="mt-1 text-foreground">{plan.memoryLabel}</dd></div>
                      <div><dt className="text-muted-foreground">CPU</dt><dd className="mt-1 text-foreground">{plan.cpuLabel}</dd></div>
                      <div><dt className="text-muted-foreground">Storage</dt><dd className="mt-1 text-foreground">{plan.diskLabel}</dd></div>
                    </dl>
                    <Link to={`/order/${product.id}?plan=${plan.id}`} className="mt-5 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-black transition hover:bg-zinc-200">
                      <Cpu className="h-4 w-4" />
                      Select Plan
                    </Link>
                  </article>
                ))}
                {!product.plans.length && (
                  <div className="rounded-lg border border-dashed border-border p-8 text-sm text-muted-foreground">
                    <HardDrive className="mb-3 h-5 w-5" />
                    Plans will appear here after authoritative product data is added.
                  </div>
                )}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

