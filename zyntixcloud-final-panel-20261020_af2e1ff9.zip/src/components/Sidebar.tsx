import { Link, useLocation } from "react-router-dom";
import {
  Server, LayoutDashboard, Plus, LogOut, X, Settings, Key,
  User, Activity, Box, ChevronLeft, Globe, ShoppingBag, CreditCard, Bell
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../context/SettingsContext";
import { useDashboardData } from "../hooks/useDashboardData";
import { motion } from "framer-motion";
import { useMemo, type ReactNode } from "react";

// ============================================
// ZyntixCloud Panel — Glass Sidebar
// Role-based visibility
// ============================================

export function Sidebar({
  onClose,
  isCollapsed,
  toggleCollapse,
}: {
  onClose?: () => void;
  isCollapsed?: boolean;
  toggleCollapse?: () => void;
}) {
  const location = useLocation();
  const { user, logout } = useAuth();
  const { panelName, panelLogo } = useSettings();
  const { servers: rawServers } = useDashboardData();

  const realServers = Array.isArray(rawServers) ? rawServers : [];
  const stats = useMemo(() => ({
    total: realServers.length,
    online: realServers.filter((s) => s.status === "online").length,
    offline: realServers.filter((s) => s.status !== "online").length,
  }), [realServers]);

  // ✅ Admin/Owner check
  const isAdmin = user?.role === "admin" || user?.role === "owner";

  // ═══════════════════════════════════════════════════════════
  // BASE LINKS — visible to ALL users
  // ═══════════════════════════════════════════════════════════
  const links: Array<{
    name: string;
    path: string;
    icon: ReactNode;
    badge?: number;
  }> = [
    {
      name: "Overview",
      path: "/dashboard",
      icon: <LayoutDashboard size={18} />,
    },
    {
      name: "Servers",
      path: "/servers",
      icon: <Server size={18} />,
      badge: stats.total,
    },
    {
      name: "Store",
      path: "/store",
      icon: <ShoppingBag size={18} />,
    },
    {
      name: "Billing",
      path: "/billing",
      icon: <CreditCard size={18} />,
    },
  ];

  // ═══════════════════════════════════════════════════════════
  // ADMIN / OWNER ONLY
  // ═══════════════════════════════════════════════════════════
  if (isAdmin) {
    links.push({ name: "Infrastructure", path: "/nodes", icon: <Globe size={18} /> });
    links.push({ name: "Create Server", path: "/servers/create", icon: <Plus size={18} /> });
    links.push({ name: "Admin Servers", path: "/admin/servers", icon: <Box size={18} /> });
    links.push({ name: "API Keys", path: "/api-keys", icon: <Key size={18} /> });
  }

  // ═══════════════════════════════════════════════════════════
  // ACCOUNT — visible to ALL users
  // ═══════════════════════════════════════════════════════════
  links.push({ name: "Notifications", path: "/notifications", icon: <Bell size={18} /> });
  links.push({ name: "Account", path: "/account", icon: <User size={18} /> });
  links.push({ name: "Settings", path: isAdmin ? "/admin/settings" : "/account", icon: <Settings size={18} /> });

  return (
    <div
      className={`h-full flex flex-col relative transition-all duration-300 z-20 overflow-hidden ${
        isCollapsed ? "w-[72px]" : "w-64"
      }`}
      style={{
        background: "#080B10",
        borderRight: "1px solid rgba(255,255,255,0.10)",
      }}
    >
      {/* HEADER — ZyntixCloud Panel brand */}
      <div className="relative h-16 flex items-center justify-between px-4 border-b border-white/10 shrink-0">
        {!isCollapsed && (
          <Link to="/dashboard" className="flex items-center gap-3 group min-w-0">
            <div className="relative shrink-0">
              {panelLogo ? (
                <img
                  src={panelLogo}
                  alt="Logo"
                  className="w-9 h-9 rounded-lg object-contain border border-white/10 bg-black"
                />
              ) : (
                <img src="/zyntixcloud-logo.png" alt="ZyntixCloud" className="w-9 h-9 rounded-lg object-contain border border-white/10 bg-black" />
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-sans font-semibold text-white text-sm leading-tight truncate">
                {panelName || "ZyntixCloud"}
              </span>
            </div>
          </Link>
        )}

        {isCollapsed && (
          <Link to="/dashboard" className="mx-auto relative">
            {panelLogo ? (
              <img
                src={panelLogo}
                alt="Logo"
                className="w-9 h-9 rounded-lg object-contain border border-white/10 bg-black"
              />
            ) : (
              <img src="/zyntixcloud-logo.png" alt="ZyntixCloud" className="w-9 h-9 rounded-lg object-contain border border-white/10 bg-black" />
            )}
          </Link>
        )}

        {onClose && (
          <button
            onClick={onClose}
            className="md:hidden p-1.5 text-zinc-400 hover:text-white bg-theme-600/10 hover:bg-theme-600/20 rounded-lg transition-colors shrink-0 backdrop-blur-sm"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* NAVIGATION */}
      <nav className="relative flex-1 px-3 py-5 space-y-1 overflow-y-auto custom-scrollbar">
        {!isCollapsed && (
          <p className="px-3 mb-2 font-mono text-[10px] text-white/35 tracking-widest uppercase">
            Navigation
          </p>
        )}

        {links.map((link) => {
          const isActive =
            location.pathname === link.path ||
            location.pathname.startsWith(link.path);

          return (
            <Link
              key={link.path}
              to={link.path}
              onClick={onClose}
              title={isCollapsed ? link.name : undefined}
              className={`relative flex items-center ${isCollapsed ? "justify-center" : "px-3"} py-2.5 rounded-lg transition-all group overflow-hidden ${
                isActive
                  ? "bg-white/[0.07] text-white border border-white/10"
                  : "text-zinc-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="aw-sidebar-active"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 bg-white rounded-r"
                  initial={false}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}

              <div
                className={`transition-colors ${
                  isActive
                    ? "text-white"
                    : "text-zinc-500 group-hover:text-white"
                }`}
              >
                {link.icon}
              </div>

              {!isCollapsed && (
                <span
                  className={`ml-3 font-medium text-sm tracking-tight transition-colors flex-1 ${
                    isActive ? "text-white" : "text-zinc-400 group-hover:text-white"
                  }`}
                >
                  {link.name}
                </span>
              )}

              {!isCollapsed && link.badge !== undefined && link.badge > 0 && (
                <span
                  className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-md transition-colors ${
                    isActive
                      ? "bg-white/10 text-white border border-white/15"
                      : "bg-white/5 text-white/60 border border-white/10"
                  }`}
                >
                  {link.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* STATS */}
      {!isCollapsed && stats.total > 0 && (
        <div
          className="relative mx-3 mb-3 p-3 rounded-xl overflow-hidden"
          style={{
            background: "rgba(255,255,255,0.035)",
            border: "1px solid rgba(255,255,255,0.10)",
          }}
        >
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

          <div className="flex items-center justify-between mb-2">
            <span className="font-mono text-[9px] tracking-[0.2em] text-theme-400 uppercase flex items-center gap-1.5">
              <Activity size={10} />
              Servers
            </span>
            <span className="font-mono text-[10px] font-bold text-white">
              <span className="text-emerald-400">{stats.online}</span>
              <span className="text-zinc-500">/</span>
              <span className="text-red-400">{stats.offline}</span>
            </span>
          </div>

          <div className="h-1 rounded-full bg-black/40 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${stats.total ? (stats.online / stats.total) * 100 : 0}%` }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]"
            />
          </div>
        </div>
      )}

      {/* COLLAPSE TOGGLE */}
      <button
        onClick={toggleCollapse}
        className="hidden md:flex items-center justify-center w-full py-3 border-t border-theme-600/10 text-zinc-500 hover:text-theme-300 hover:bg-theme-600/5 transition-colors backdrop-blur-sm"
        title={isCollapsed ? "Expand" : "Collapse"}
      >
        <ChevronLeft
          size={16}
          className={`transition-transform ${isCollapsed ? "rotate-180" : ""}`}
        />
        {!isCollapsed && (
          <span className="ml-2 font-mono text-[10px] tracking-widest uppercase">Collapse</span>
        )}
      </button>

      {/* USER PROFILE */}
      <div
        className="relative p-3 border-t border-white/10 shrink-0"
        style={{
          background: "linear-gradient(180deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.4) 100%)",
        }}
      >
        {isCollapsed ? (
          <button
            onClick={logout}
            title="Logout"
            className="flex items-center justify-center w-full p-2.5 rounded-lg text-zinc-400 hover:text-red-300 hover:bg-red-500/10 transition-all"
          >
            <LogOut size={18} />
          </button>
        ) : (
          <div className="space-y-2">
            <div
              className="flex items-center gap-3 p-2.5 rounded-lg group cursor-pointer transition-all overflow-hidden relative"
              style={{
                background: "rgba(255,255,255,0.035)",
                border: "1px solid rgba(255,255,255,0.10)",
              }}
            >
              <div className="relative shrink-0">
                <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white font-bold text-sm border border-white/10">
                  {user?.username?.[0]?.toUpperCase() || "U"}
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#0a0612] rounded-full" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">
                  {user?.username || "User"}
                </p>
                <p className="text-[10px] text-white/45 uppercase tracking-wider font-mono">
                  {user?.role || "User"}
                </p>
              </div>
            </div>

            <button
              onClick={logout}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-zinc-400 hover:text-red-300 hover:bg-red-500/10 border border-transparent hover:border-red-500/20 transition-all text-xs font-medium"
            >
              <LogOut size={14} />
              Logout
            </button>
          </div>
        )}
      </div>

    </div>
  );
}

