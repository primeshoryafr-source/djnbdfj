export type HostingPlan = {
  name: string;
  price: string;
  cpu: string;
  ram: string;
  storage: string;
  popular?: boolean;
};

export type HostingProduct = {
  slug: string;
  eyebrow: string;
  title: string;
  description: string;
  starting: string;
  location: string;
  processors?: string[];
  network?: string;
  panel: string;
  plans: HostingPlan[];
  features: string[];
  titleTag: string;
  meta: string;
};

const vpsIncluded = ['2Gbps Premium Port', 'Full VPS Management Panel', 'Root Access', 'VNC Console', 'Instant OS Reinstall'];

export const products: Record<string, HostingProduct> = {
  budgetGame: {
    slug: '/game-servers/budget',
    eyebrow: 'INDIA • INTEL XEON',
    title: 'Budget Game Server Hosting',
    description: 'Affordable game server hosting with Intel Xeon processors, NVMe storage and Pterodactyl access.',
    starting: '₹40/month',
    location: 'India',
    processors: ['Intel Xeon Processor'],
    panel: 'Pterodactyl Panel',
    titleTag: 'Budget Game Server Hosting India | ZyntixCloud',
    meta: 'Affordable Intel Xeon game server hosting in India with NVMe storage and Pterodactyl access.',
    plans: [
      { name: 'Nano', price: '₹40', ram: '2GB DDR4 RAM', cpu: '75% CPU', storage: '15GB NVMe SSD' },
      { name: 'Starter', price: '₹70', ram: '4GB DDR4 RAM', cpu: '125% CPU', storage: '25GB NVMe SSD' },
      { name: 'Performance', price: '₹120', ram: '6GB DDR4 RAM', cpu: '175% CPU', storage: '35GB NVMe SSD' },
      { name: 'Ultra', price: '₹170', ram: '8GB DDR4 RAM', cpu: '225% CPU', storage: '50GB NVMe SSD' },
      { name: 'Pro', price: '₹250', ram: '12GB DDR4 RAM', cpu: '275% CPU', storage: '75GB NVMe SSD' },
      { name: 'Enterprise', price: '₹350', ram: '16GB DDR4 RAM', cpu: '350% CPU', storage: '100GB NVMe SSD' },
      { name: 'Titan', price: '₹650', ram: '32GB DDR4 RAM', cpu: '400% CPU', storage: '200GB NVMe SSD' },
      { name: 'GOD', price: '₹950', ram: '48GB DDR4 RAM', cpu: '450% CPU', storage: '250GB NVMe SSD' },
    ],
    features: ['Intel Xeon Processor', 'DDR4 RAM', 'NVMe SSD Storage', 'Instant Setup', 'DDoS Protection', 'Full FTP Access', 'Free Subdomain', 'Pterodactyl Panel', '24/7 Ticket Support'],
  },
  premiumGame: {
    slug: '/game-servers/premium',
    eyebrow: 'INDIA • AMD EPYC',
    title: 'Premium Game Server Hosting',
    description: 'Higher CPU priority, ECC memory and NVMe storage for servers that need more resources.',
    starting: '₹100/month',
    location: 'India',
    processors: ['AMD EPYC Gameserver Processor'],
    panel: 'Pterodactyl Panel',
    titleTag: 'AMD EPYC Game Server Hosting India | ZyntixCloud',
    meta: 'Premium AMD EPYC game server hosting in India with ECC memory, NVMe storage and Pterodactyl access.',
    plans: [
      { name: 'Starter', price: '₹100', ram: '2GB DDR4 ECC RAM', cpu: '75% CPU Priority', storage: '10GB NVMe SSD' },
      { name: 'Basic', price: '₹150', ram: '3GB DDR4 ECC RAM', cpu: '100% CPU Priority', storage: '18GB NVMe SSD' },
      { name: 'Performance', price: '₹200', ram: '4GB DDR4 ECC RAM', cpu: '125% CPU Priority', storage: '25GB NVMe SSD' },
      { name: 'Standard', price: '₹250', ram: '5GB DDR4 ECC RAM', cpu: '150% CPU Priority', storage: '30GB NVMe SSD' },
      { name: 'Ultra Boost', price: '₹300', ram: '6GB DDR4 ECC RAM', cpu: '175% CPU Priority', storage: '36GB NVMe SSD', popular: true },
      { name: 'Pro', price: '₹350', ram: '7GB DDR4 ECC RAM', cpu: '200% CPU Priority', storage: '42GB NVMe SSD' },
      { name: 'Pro Max', price: '₹400', ram: '8GB DDR4 ECC RAM', cpu: '225% CPU Priority', storage: '48GB NVMe SSD' },
      { name: 'Elite', price: '₹500', ram: '10GB DDR4 ECC RAM', cpu: '275% CPU Priority', storage: '60GB NVMe SSD' },
      { name: 'Enterprise', price: '₹600', ram: '12GB DDR4 ECC RAM', cpu: '325% CPU Priority', storage: '72GB NVMe SSD' },
      { name: 'Ultimate', price: '₹700', ram: '14GB DDR4 ECC RAM', cpu: '350% CPU Priority', storage: '84GB NVMe SSD' },
      { name: 'Titan', price: '₹800', ram: '16GB DDR4 ECC RAM', cpu: '375% CPU Priority', storage: '96GB NVMe SSD' },
      { name: 'Obsidian', price: '₹900', ram: '18GB DDR4 ECC RAM', cpu: '425% CPU Priority', storage: '108GB NVMe SSD' },
      { name: 'VIP', price: '₹1,000', ram: '20GB DDR4 ECC RAM', cpu: '475% CPU Priority', storage: '120GB NVMe SSD' },
      { name: 'GOD', price: '₹1,500', ram: '32GB DDR4 ECC RAM', cpu: '500% CPU Priority', storage: '160GB NVMe SSD' },
    ],
    features: ['AMD EPYC Gameserver Processor', 'DDR4 ECC Memory', 'NVMe SSD Storage', 'Advanced DDoS Mitigation', 'Instant Setup', 'Pterodactyl Panel', 'DDoS Protected'],
  },
  bot: {
    slug: '/bot-hosting',
    eyebrow: 'BOT HOSTING',
    title: 'Keep your bot online.',
    description: 'Simple hosting for Discord bots and other lightweight applications.',
    starting: '₹80/month',
    location: 'India',
    panel: 'Pterodactyl Panel',
    titleTag: 'Discord Bot Hosting | ZyntixCloud',
    meta: 'Discord bot hosting with Pterodactyl access, NVMe storage and 24/7 ticket support.',
    plans: [
      { name: 'BOT 1', price: '₹80', cpu: '0.5 Core', ram: '1GB DDR4 RAM', storage: '5GB NVMe SSD' },
      { name: 'BOT 2', price: '₹120', cpu: '1 Core', ram: '3GB DDR4 RAM', storage: '10GB NVMe SSD' },
      { name: 'BOT 3', price: '₹250', cpu: '1.5 Core', ram: '4GB DDR4 RAM', storage: '20GB NVMe SSD' },
    ],
    features: ['High Frequency Cores', 'Pterodactyl Panel', '24/7 Support'],
  },
  indiaIntel: {
    slug: '/vps/india-intel',
    eyebrow: 'INDIA • INTEL XEON',
    title: 'India Intel VPS',
    description: 'KVM VPS hosting in India with root access, NVMe storage and a full VPS management panel.',
    starting: '₹399/month',
    location: 'India',
    processors: ['Intel Xeon E5-2673 v4', 'Intel Xeon E5-2682 v4', 'Intel Xeon Platinum 8168', 'Intel Xeon Platinum 8269CY'],
    panel: 'Full VPS Management Panel',
    titleTag: 'India Intel VPS Hosting | ZyntixCloud',
    meta: 'India Intel VPS hosting with root access, NVMe storage and full VPS management panel.',
    plans: [
      { name: 'XS', price: '₹399', cpu: '2 vCore', ram: '6GB DDR4 ECC RAM', storage: '50GB NVMe SSD' },
      { name: 'S', price: '₹529', cpu: '2 vCore', ram: '8GB DDR4 ECC RAM', storage: '80GB NVMe SSD' },
      { name: 'M', price: '₹749', cpu: '4 vCore', ram: '12GB DDR4 ECC RAM', storage: '100GB NVMe SSD' },
      { name: 'L', price: '₹999', cpu: '6 vCore', ram: '16GB DDR4 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹1,349', cpu: '6 vCore', ram: '24GB DDR4 ECC RAM', storage: '200GB NVMe SSD' },
      { name: 'XXL', price: '₹1,499', cpu: '8 vCore', ram: '32GB DDR4 ECC RAM', storage: '300GB NVMe SSD' },
      { name: '2XL', price: '₹2,199', cpu: '10 vCore', ram: '48GB DDR4 ECC RAM', storage: '350GB NVMe SSD' },
      { name: '3XL', price: '₹2,499', cpu: '12 vCore', ram: '64GB DDR4 ECC RAM', storage: '400GB NVMe SSD' },
    ],
    features: vpsIncluded,
  },
  indiaAmd: {
    slug: '/vps/india-amd',
    eyebrow: 'INDIA • AMD EPYC',
    title: 'India AMD EPYC VPS',
    description: 'AMD EPYC VPS hosting with root access, ECC memory, NVMe storage and a 2 Gbps port.',
    starting: '₹449/month',
    location: 'India',
    processors: ['AMD EPYC 7F72', 'AMD EPYC 7K62'],
    panel: 'Full VPS Management Panel',
    titleTag: 'India AMD EPYC VPS Hosting | ZyntixCloud',
    meta: 'India AMD EPYC VPS hosting with root access, ECC memory, NVMe storage and a 2 Gbps port.',
    plans: [
      { name: 'XS', price: '₹449', cpu: '2 vCore', ram: '6GB DDR4 ECC RAM', storage: '50GB NVMe SSD' },
      { name: 'S', price: '₹649', cpu: '2 vCore', ram: '8GB DDR4 ECC RAM', storage: '80GB NVMe SSD' },
      { name: 'M', price: '₹1,049', cpu: '4 vCore', ram: '12GB DDR4 ECC RAM', storage: '100GB NVMe SSD' },
      { name: 'L', price: '₹1,249', cpu: '6 vCore', ram: '16GB DDR4 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹1,649', cpu: '6 vCore', ram: '24GB DDR4 ECC RAM', storage: '200GB NVMe SSD' },
      { name: 'XXL', price: '₹1,999', cpu: '8 vCore', ram: '32GB DDR4 ECC RAM', storage: '300GB NVMe SSD' },
      { name: '2XL', price: '₹2,649', cpu: '10 vCore', ram: '48GB DDR4 ECC RAM', storage: '350GB NVMe SSD' },
      { name: '3XL', price: '₹2,999', cpu: '12 vCore', ram: '64GB DDR4 ECC RAM', storage: '400GB NVMe SSD' },
    ],
    features: vpsIncluded,
  },
  indiaRyzen: {
    slug: '/vps/india-ryzen',
    eyebrow: 'INDIA • AMD RYZEN',
    title: 'India Ryzen VPS',
    description: 'High-frequency Ryzen VPS hosting for workloads that need strong CPU performance.',
    starting: '₹699/month',
    location: 'India',
    processors: ['AMD Ryzen 9 9900X — Performance', 'AMD Ryzen 9 5900X — DDoS Protection'],
    panel: 'Full VPS Management Panel',
    titleTag: 'India Ryzen VPS Hosting | ZyntixCloud',
    meta: 'India Ryzen VPS hosting with high-frequency processors, root access and NVMe storage.',
    plans: [
      { name: 'XS', price: '₹699', cpu: '1 vCore', ram: '4GB DDR5 ECC RAM', storage: '50GB NVMe SSD' },
      { name: 'S', price: '₹1,199', cpu: '2 vCore', ram: '8GB DDR5 ECC RAM', storage: '80GB NVMe SSD' },
      { name: 'L', price: '₹1,999', cpu: '4 vCore', ram: '16GB DDR5 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹2,749', cpu: '5 vCore', ram: '24GB DDR5 ECC RAM', storage: '180GB NVMe SSD' },
      { name: 'XXL', price: '₹3,599', cpu: '6 vCore', ram: '32GB DDR5 ECC RAM', storage: '200GB NVMe SSD' },
      { name: '2XL', price: '₹4,499', cpu: '8 vCore', ram: '48GB DDR5 ECC RAM', storage: '250GB NVMe SSD' },
    ],
    features: ['1Gbps Premium Port', 'Full VPS Management Panel', 'Root Access', 'VNC Console', 'Instant OS Reinstall'],
  },
  germanyIntel: {
    slug: '/vps/germany-intel',
    eyebrow: 'GERMANY • INTEL XEON',
    title: 'Germany Intel VPS',
    description: 'Intel Xeon VPS hosting located in Germany with root access and NVMe storage.',
    starting: '₹449/month',
    location: 'Germany',
    processors: ['Intel Xeon Gold 6150'],
    panel: 'Full VPS Management Panel',
    titleTag: 'Germany Intel VPS Hosting | ZyntixCloud',
    meta: 'Germany Intel VPS hosting with root access, ECC memory and NVMe storage.',
    plans: [
      { name: 'XS', price: '₹449', cpu: '1 vCore', ram: '6GB DDR4 ECC RAM', storage: '40GB NVMe SSD' },
      { name: 'S', price: '₹649', cpu: '2 vCore', ram: '8GB DDR4 ECC RAM', storage: '50GB NVMe SSD' },
      { name: 'M', price: '₹849', cpu: '4 vCore', ram: '12GB DDR4 ECC RAM', storage: '100GB NVMe SSD' },
      { name: 'L', price: '₹1,049', cpu: '4 vCore', ram: '16GB DDR4 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹1,549', cpu: '6 vCore', ram: '24GB DDR4 ECC RAM', storage: '200GB NVMe SSD' },
      { name: 'XXL', price: '₹2,049', cpu: '6 vCore', ram: '36GB DDR4 ECC RAM', storage: '250GB NVMe SSD' },
      { name: '2XL', price: '₹2,849', cpu: '8 vCore', ram: '48GB DDR4 ECC RAM', storage: '300GB NVMe SSD' },
      { name: '3XL', price: '₹3,849', cpu: '8 vCore', ram: '64GB DDR4 ECC RAM', storage: '350GB NVMe SSD' },
    ],
    features: vpsIncluded,
  },
  singaporeAmd: {
    slug: '/vps/singapore-amd',
    eyebrow: 'SINGAPORE • AMD EPYC',
    title: 'Singapore AMD EPYC VPS',
    description: 'AMD EPYC VPS hosting in Singapore with ECC memory, NVMe storage and root access.',
    starting: '₹1,099/month',
    location: 'Singapore',
    processors: ['AMD EPYC Milan Series'],
    panel: 'Full VPS Management Panel',
    titleTag: 'Singapore AMD EPYC VPS Hosting | ZyntixCloud',
    meta: 'Singapore AMD EPYC VPS hosting with ECC memory, NVMe storage and root access.',
    plans: [
      { name: 'XS', price: '₹1,099', cpu: '4 vCore', ram: '8GB DDR4 ECC RAM', storage: '64GB NVMe SSD' },
      { name: 'S', price: '₹2,099', cpu: '8 vCore', ram: '16GB DDR4 ECC RAM', storage: '128GB NVMe SSD' },
      { name: 'M', price: '₹4,199', cpu: '12 vCore', ram: '32GB DDR4 ECC RAM', storage: '256GB NVMe SSD' },
      { name: 'L', price: '₹5,799', cpu: '16 vCore', ram: '64GB DDR4 ECC RAM', storage: '512GB NVMe SSD' },
      { name: 'XL', price: '₹10,999', cpu: '24 vCore', ram: '128GB DDR4 ECC RAM', storage: '1TB NVMe SSD' },
    ],
    features: vpsIncluded,
  },
  intelVds: {
    slug: '/vds/intel',
    eyebrow: 'INTEL XEON • VDS',
    title: 'Intel Xeon VDS',
    description: 'Dedicated Intel Xeon CPU resources with ECC memory, NVMe storage and server management tools.',
    starting: '₹1,200/month',
    location: 'India',
    processors: ['Intel Xeon E5-2673 v4 @ 2.30 GHz', 'Intel Xeon E5-2682 v4 @ 2.50 GHz', 'Intel Xeon Platinum 8168 @ 2.70 GHz', 'Intel Xeon Platinum 8269CY @ 2.50 GHz'],
    panel: 'Full Management Panel',
    titleTag: 'Intel Xeon VDS Hosting | ZyntixCloud',
    meta: 'Intel Xeon VDS hosting with dedicated CPU resources, ECC memory and NVMe storage.',
    plans: [
      { name: 'L', price: '₹1,200', cpu: '6 Dedicated Cores', ram: '16GB DDR4 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹2,000', cpu: '6 Dedicated Cores', ram: '24GB DDR4 ECC RAM', storage: '200GB NVMe SSD' },
      { name: 'XXL', price: '₹2,500', cpu: '8 Dedicated Cores', ram: '32GB DDR4 ECC RAM', storage: '300GB NVMe SSD' },
      { name: '2XL', price: '₹3,800', cpu: '10 Dedicated Cores', ram: '48GB DDR4 ECC RAM', storage: '350GB NVMe SSD' },
      { name: '3XL', price: '₹4,500', cpu: '12 Dedicated Cores', ram: '64GB DDR4 ECC RAM', storage: '400GB NVMe SSD' },
    ],
    features: ['Full Management Panel', 'Dedicated Resource Control', 'VNC Access', 'Backup Management'],
  },
  amdVds: {
    slug: '/vds/amd',
    eyebrow: 'AMD EPYC • VDS',
    title: 'AMD EPYC VDS',
    description: 'Dedicated AMD EPYC CPU resources with ECC memory, NVMe storage and management access.',
    starting: '₹1,500/month',
    location: 'India',
    processors: ['EPYC 7F72 3.20 GHz', 'EPYC 7K62 2.60 GHz'],
    panel: 'Full Management Panel',
    titleTag: 'AMD EPYC VDS Hosting | ZyntixCloud',
    meta: 'AMD EPYC VDS hosting with dedicated CPU resources, ECC memory and NVMe storage.',
    plans: [
      { name: 'L', price: '₹1,500', cpu: '6 Dedicated Cores', ram: '16GB DDR4 ECC RAM', storage: '150GB NVMe SSD' },
      { name: 'XL', price: '₹2,399', cpu: '6 Dedicated Cores', ram: '24GB DDR4 ECC RAM', storage: '200GB NVMe SSD' },
      { name: 'XXL', price: '₹2,999', cpu: '8 Dedicated Cores', ram: '32GB DDR4 ECC RAM', storage: '300GB NVMe SSD' },
      { name: '2XL', price: '₹3,999', cpu: '10 Dedicated Cores', ram: '48GB DDR4 ECC RAM', storage: '350GB NVMe SSD' },
      { name: '3XL', price: '₹4,999', cpu: '12 Dedicated Cores', ram: '64GB DDR4 ECC RAM', storage: '400GB NVMe SSD' },
    ],
    features: ['Full Management Panel', 'Dedicated Resource Control', 'VNC Access', 'Backup Management'],
  },
};

export const gameOptions = [
  { title: 'Budget Game Servers', chip: 'Intel Xeon', price: '₹40/month', text: 'Affordable plans for smaller servers and communities.', to: '/game-servers/budget' },
  { title: 'Premium Game Servers', chip: 'AMD EPYC', price: '₹100/month', text: 'Higher CPU priority and ECC memory for more demanding servers.', to: '/game-servers/premium' },
];

export const vpsOptions = [
  { title: 'India Intel VPS', price: 'From ₹399/mo', to: '/vps/india-intel', meta: 'Intel Xeon • India' },
  { title: 'India AMD VPS', price: 'From ₹449/mo', to: '/vps/india-amd', meta: 'AMD EPYC • India' },
  { title: 'India Ryzen VPS', price: 'From ₹699/mo', to: '/vps/india-ryzen', meta: 'AMD Ryzen • India' },
  { title: 'Germany Intel VPS', price: 'From ₹449/mo', to: '/vps/germany-intel', meta: 'Intel Xeon • Germany' },
  { title: 'Singapore AMD VPS', price: 'From ₹1,099/mo', to: '/vps/singapore-amd', meta: 'AMD EPYC • Singapore' },
];

export const vdsOptions = [
  { title: 'Intel Xeon VDS', price: '₹1,200/month', to: '/vds/intel', meta: 'Dedicated Intel CPU resources' },
  { title: 'AMD EPYC VDS', price: '₹1,500/month', to: '/vds/amd', meta: 'Dedicated AMD EPYC CPU resources' },
];
