export type ProductCategory = "game-servers" | "bot-hosting" | "vps" | "vds";
export type ProvisioningKind = "game" | "bot" | "vps" | "vds";

export interface CatalogPlan {
  id: string;
  name: string;
  pricePaise: number;
  currency: "INR";
  period: "month";
  memoryMb?: number;
  cpuPercent?: number;
  cpuLabel: string;
  diskMb?: number;
  diskLabel: string;
  memoryLabel: string;
  processor: string;
  location: string;
  port?: string;
  popular?: boolean;
}

export interface CatalogProduct {
  id: string;
  slug: string;
  category: ProductCategory;
  kind: ProvisioningKind;
  name: string;
  subtitle: string;
  location: string;
  processor: string;
  available: boolean;
  unavailableReason?: string;
  allowedSoftware: string[];
  defaultSoftware?: string;
  defaultVersion?: string;
  plans: CatalogPlan[];
}

const gb = (value: number) => value * 1024;
const price = (rupees: number) => rupees * 100;

const budgetPlans: CatalogPlan[] = [
  ["nano", "Nano", 40, 2, "75% CPU", 15],
  ["starter", "Starter", 70, 4, "125% CPU", 25],
  ["performance", "Performance", 120, 6, "175% CPU", 35],
  ["ultra", "Ultra", 170, 8, "225% CPU", 50],
  ["pro", "Pro", 250, 12, "275% CPU", 75],
  ["enterprise", "Enterprise", 350, 16, "350% CPU", 100],
  ["titan", "Titan", 650, 32, "400% CPU", 200],
  ["god", "GOD", 950, 48, "450% CPU", 250],
].map(([id, name, rupees, ram, cpuLabel, disk]) => ({
  id: `budget-${id}`,
  name: String(name),
  pricePaise: price(Number(rupees)),
  currency: "INR",
  period: "month",
  memoryMb: gb(Number(ram)),
  memoryLabel: `${ram} GB DDR4`,
  cpuPercent: Number(String(cpuLabel).match(/\d+/)?.[0] || 100),
  cpuLabel: String(cpuLabel),
  diskMb: gb(Number(disk)),
  diskLabel: `${disk} GB NVMe`,
  processor: "Intel Xeon",
  location: "India",
}));

const premiumPlans: CatalogPlan[] = [
  ["starter", "Starter", 100, 2, "75% CPU Priority", 10],
  ["basic", "Basic", 150, 3, "100% CPU Priority", 18],
  ["performance", "Performance", 200, 4, "125% CPU Priority", 25],
  ["standard", "Standard", 250, 5, "150% CPU Priority", 30],
  ["ultra-boost", "Ultra Boost", 300, 6, "175% CPU Priority", 36],
  ["pro", "Pro", 350, 7, "200% CPU Priority", 42],
  ["pro-max", "Pro Max", 400, 8, "225% CPU Priority", 48],
  ["elite", "Elite", 500, 10, "275% CPU Priority", 60],
  ["enterprise", "Enterprise", 600, 12, "325% CPU Priority", 72],
  ["ultimate", "Ultimate", 700, 14, "350% CPU Priority", 84],
  ["titan", "Titan", 800, 16, "375% CPU Priority", 96],
  ["obsidian", "Obsidian", 900, 18, "425% CPU Priority", 108],
  ["vip", "VIP", 1000, 20, "475% CPU Priority", 120],
  ["god", "GOD", 1500, 32, "500% CPU Priority", 160],
].map(([id, name, rupees, ram, cpuLabel, disk]) => ({
  id: `premium-${id}`,
  name: String(name),
  pricePaise: price(Number(rupees)),
  currency: "INR",
  period: "month",
  memoryMb: gb(Number(ram)),
  memoryLabel: `${ram} GB DDR4 ECC`,
  cpuPercent: Number(String(cpuLabel).match(/\d+/)?.[0] || 100),
  cpuLabel: String(cpuLabel),
  diskMb: gb(Number(disk)),
  diskLabel: `${disk} GB NVMe`,
  processor: "AMD EPYC",
  location: "India",
  popular: id === "ultra-boost",
}));

const botPlans: CatalogPlan[] = [
  ["bot-1", "BOT 1", 80, "1 GB DDR4", "0.5 Core", "5 GB NVMe", 1, 50, 5],
  ["bot-2", "BOT 2", 120, "3 GB DDR4", "1 Core", "10 GB NVMe", 3, 100, 10],
  ["bot-3", "BOT 3", 250, "4 GB DDR4", "1.5 Core", "20 GB NVMe", 4, 150, 20],
].map(([id, name, rupees, memoryLabel, cpuLabel, diskLabel, ramGb, cpuPercent, diskGb]) => ({
  id: String(id),
  name: String(name),
  pricePaise: price(Number(rupees)),
  currency: "INR",
  period: "month",
  memoryMb: gb(Number(ramGb)),
  memoryLabel: String(memoryLabel),
  cpuPercent: Number(cpuPercent),
  cpuLabel: String(cpuLabel),
  diskMb: gb(Number(diskGb)),
  diskLabel: String(diskLabel),
  processor: "Container Runtime",
  location: "India",
}));

export const catalog: CatalogProduct[] = [
  {
    id: "game-budget-india-xeon",
    slug: "game-servers/budget",
    category: "game-servers",
    kind: "game",
    name: "Budget Game Servers",
    subtitle: "India - Intel Xeon",
    location: "India",
    processor: "Intel Xeon",
    available: true,
    allowedSoftware: ["PAPER", "PURPUR", "SPIGOT", "VANILLA", "FABRIC", "FORGE"],
    defaultSoftware: "PAPER",
    defaultVersion: "1.21.4",
    plans: budgetPlans,
  },
  {
    id: "game-premium-india-epyc",
    slug: "game-servers/premium",
    category: "game-servers",
    kind: "game",
    name: "Premium Game Servers",
    subtitle: "India - AMD EPYC",
    location: "India",
    processor: "AMD EPYC",
    available: true,
    allowedSoftware: ["PAPER", "PURPUR", "SPIGOT", "VANILLA", "FABRIC", "FORGE"],
    defaultSoftware: "PAPER",
    defaultVersion: "1.21.4",
    plans: premiumPlans,
  },
  {
    id: "bot-hosting-india",
    slug: "bot-hosting",
    category: "bot-hosting",
    kind: "bot",
    name: "Bot Hosting",
    subtitle: "Node.js and Python workloads",
    location: "India",
    processor: "Shared CPU",
    available: true,
    allowedSoftware: ["NODEJS", "PYTHON"],
    defaultSoftware: "NODEJS",
    defaultVersion: "20",
    plans: botPlans,
  },
  ...["India Intel VPS", "India AMD EPYC VPS", "India Ryzen VPS", "Germany Intel VPS", "Singapore AMD EPYC VPS"].map((name) => ({
    id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    slug: `vps/${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
    category: "vps" as const,
    kind: "vps" as const,
    name,
    subtitle: "Provider catalog required",
    location: name.split(" ")[0],
    processor: name.replace(/^(India|Germany|Singapore)\s+/, "").replace(/\s+VPS$/, ""),
    available: false,
    unavailableReason: "The supplied VPS plan prices/specifications were not present in the task attachment.",
    allowedSoftware: [],
    plans: [],
  })),
  ...["Intel Xeon VDS", "AMD EPYC VDS"].map((name) => ({
    id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    slug: `vds/${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
    category: "vds" as const,
    kind: "vds" as const,
    name,
    subtitle: "Provider catalog required",
    location: "Configurable",
    processor: name.replace(/\s+VDS$/, ""),
    available: false,
    unavailableReason: "The supplied VDS plan prices/specifications were not present in the task attachment.",
    allowedSoftware: [],
    plans: [],
  })),
];

export function listCatalog() {
  return catalog;
}

export function findProduct(productId: string) {
  return catalog.find((product) => product.id === productId || product.slug === productId);
}

export function findPlan(productId: string, planId: string) {
  const product = findProduct(productId);
  const plan = product?.plans.find((candidate) => candidate.id === planId);
  return product && plan ? { product, plan } : null;
}

export function formatPaise(amount: number) {
  return `₹${Math.round(amount / 100).toLocaleString("en-IN")}`;
}

