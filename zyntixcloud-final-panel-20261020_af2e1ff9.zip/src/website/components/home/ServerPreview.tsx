import { Activity, Database, Folder, Gauge, HardDrive, Network, PanelTop, Power, Settings, ShieldCheck, Terminal, Users } from 'lucide-react';
import logo from '../../assets/zyntixcloud-logo.png';

const sidebar = [
  ['Overview', Gauge],
  ['Console', Terminal],
  ['File Manager', Folder],
  ['Databases', Database],
  ['Schedules', Activity],
  ['Users', Users],
  ['Backups', HardDrive],
  ['Network', Network],
  ['Startup', Power],
  ['Settings', Settings],
];

const consoleLines = ['[ZyntixCloud] Starting server...', '[System] Allocating resources...', '[Network] Protection enabled.', '[Server] Loading configuration...', '[Server] Instance successfully started.', '[Status] Server is online.'];

export function ResourceChart({ compact = false }: { compact?: boolean }) {
  const bars = [34, 52, 40, 63, 48, 70, 55, 46, 61, 50, 72, 58, 64, 49, 68, 57];
  return (
    <div className={`chart ${compact ? 'compact' : ''}`} aria-label="Resource usage chart">
      {bars.map((height, index) => (
        <span key={index} style={{ height: `${height}%` }} />
      ))}
    </div>
  );
}

export function ServerPreview({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`server-preview ${compact ? 'server-preview-small' : ''}`}>
      <div className="server-top">
        <div className="server-identity">
          <img src={logo} alt="ZyntixCloud" />
          <div>
            <strong>Game Server #01</strong>
            <span><i /> Online</span>
          </div>
        </div>
        <div className="server-tabs">
          {['Overview', 'Console', 'Files', 'Network', 'Backups'].map((tab) => <span key={tab}>{tab}</span>)}
        </div>
        <div className="server-region">India <button>Manage Server</button></div>
      </div>
      <div className="server-body">
        <aside>
          {sidebar.map(([label, Icon], index) => (
            <button className={index === 0 ? 'active' : ''} key={label as string}>
              <Icon size={16} />
              {label as string}
            </button>
          ))}
        </aside>
        <div className="server-main">
          <div className="server-heading">
            <div>
              <h3>Server Overview</h3>
              <p><i /> Online</p>
            </div>
          </div>
          <div className="metrics">
            {[
              ['CPU Usage', '32%'],
              ['Memory', '8.4 / 16 GB'],
              ['Storage', '42 / 100 GB'],
              ['Network', '1.2 Gbps'],
            ].map(([label, value]) => (
              <div key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
              </div>
            ))}
          </div>
          <div className="server-content-grid">
            <div className="panel-block large">
              <div className="panel-title">
                <span>Resource usage</span>
                <small>Last 12 hours</small>
              </div>
              <ResourceChart compact={compact} />
            </div>
            <div className="panel-block info">
              <span>Server Information</span>
              {[
                ['Location', 'India'],
                ['Processor', 'AMD EPYC'],
                ['Storage', 'NVMe SSD'],
                ['Protection', 'DDoS Protected'],
                ['Panel', 'Pterodactyl'],
              ].map(([label, value]) => (
                <p key={label}><small>{label}</small><strong>{value}</strong></p>
              ))}
            </div>
          </div>
          <div className="console">
            {consoleLines.map((line) => <code key={line}>{line}</code>)}
          </div>
        </div>
      </div>
    </div>
  );
}

export function ControlPanelPreview() {
  const actions = [
    ['Start', Power],
    ['Restart', Activity],
    ['Shutdown', Power],
    ['Console', Terminal],
    ['Files', Folder],
    ['Backups', HardDrive],
    ['Network', Network],
    ['Reinstall', PanelTop],
    ['VNC', ShieldCheck],
  ];
  return (
    <div className="control-preview">
      <div className="action-grid">
        {actions.map(([label, Icon]) => (
          <button key={label as string}>
            <Icon size={18} />
            {label as string}
          </button>
        ))}
      </div>
      <div className="terminal-card">
        <Terminal size={18} />
        <code>root@zyntixcloud:~$ systemctl status server</code>
        <span>active (running)</span>
      </div>
    </div>
  );
}
