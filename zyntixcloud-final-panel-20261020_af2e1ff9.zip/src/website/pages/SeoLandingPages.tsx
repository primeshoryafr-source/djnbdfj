import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';
import { Database, Gamepad2, Globe2, HardDrive, Network, Server, ShieldCheck, Terminal } from 'lucide-react';
import { SectionHeader } from '../components/common/SectionHeader';
import { Button } from '../components/ui/Button';
import { FAQ } from '../components/common/FAQ';
import { FinalCTA } from '../components/common/FinalCTA';
import { applySeo, getSeoRoute } from '../seo';

function SeoPage({ path, children }: { path: string; children: ReactNode }) {
  applySeo(getSeoRoute(path));
  return <>{children}</>;
}

function Breadcrumbs({ items }: { items: [string, string][] }) {
  return (
    <nav className="breadcrumbs" aria-label="Breadcrumb">
      {items.map(([label, to], index) => (
        <span key={to}>
          {index > 0 && <span aria-hidden="true">/</span>}
          <Link to={to}>{label}</Link>
        </span>
      ))}
    </nav>
  );
}

function FeatureList({ items }: { items: [React.ElementType, string, string][] }) {
  return (
    <div className="feature-grid">
      {items.map(([Icon, title, text]) => (
        <article className="feature" key={title}>
          <Icon size={18} />
          <h3>{title}</h3>
          <p>{text}</p>
        </article>
      ))}
    </div>
  );
}

export function MinecraftHosting() {
  return (
    <SeoPage path="/minecraft-hosting">
      <section className="product-hero">
        <div className="container">
          <Breadcrumbs items={[['Home', '/'], ['Minecraft Hosting', '/minecraft-hosting']]} />
          <p className="eyebrow">MINECRAFT SERVER HOSTING</p>
          <h1>Minecraft server hosting by ZyntixCloud.</h1>
          <p>ZyntixCloud provides Minecraft Java server hosting with NVMe storage, India-based plans, Pterodactyl access and support for Paper, Purpur and plugin-based server setups.</p>
          <div className="product-actions">
            <Button to="/game-servers/budget" icon>Budget Minecraft Plans</Button>
            <Button to="/game-servers/premium" variant="secondary">Premium EPYC Plans</Button>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <SectionHeader eyebrow="WHAT YOU CAN RUN" title="Built for Minecraft communities." description="Choose a plan for survival SMPs, private friend servers, modded experiments or larger network projects. Specs and pricing stay visible in HTML on the plan pages." />
          <FeatureList items={[
            [Gamepad2, 'Minecraft Java hosting', 'Run Java Edition servers with common software choices such as Paper and Purpur where compatible.'],
            [HardDrive, 'NVMe storage', 'Listed Minecraft plans include NVMe SSD storage for faster world and plugin file access.'],
            [ShieldCheck, 'DDoS protection', 'Protection is available on supported ZyntixCloud infrastructure and listed hosting plans.'],
            [Terminal, 'Pterodactyl access', 'Use console, files, startup settings and server controls from a management panel.'],
          ]} />
        </div>
      </section>
      <FAQ />
      <FinalCTA />
    </SeoPage>
  );
}

export function BareMetal() {
  return (
    <SeoPage path="/bare-metal">
      <section className="product-hero">
        <div className="container">
          <Breadcrumbs items={[['Home', '/'], ['Bare Metal', '/bare-metal']]} />
          <p className="eyebrow">BARE METAL SERVERS</p>
          <h1>Bare metal infrastructure by ZyntixCloud.</h1>
          <p>For workloads that need physical server resources, ZyntixCloud positions bare metal and dedicated infrastructure as the upgrade path beyond VPS and VDS plans.</p>
          <div className="product-actions">
            <Button to="/support" icon>Discuss Requirements</Button>
            <Button to="/vds" variant="secondary">Compare VDS</Button>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <SectionHeader title="When to choose bare metal." description="Bare metal is useful when a project needs full physical resource control instead of shared virtualization. Keep final hardware, pricing and availability updated before taking production orders." />
          <FeatureList items={[
            [Server, 'Physical resources', 'Dedicated servers can provide direct control over CPU, memory and storage allocation.'],
            [Database, 'Custom workloads', 'Use bare metal for large game networks, databases, virtualization hosts and infrastructure-heavy projects.'],
            [Network, 'Network planning', 'Choose locations and network capacity based on users, latency and traffic needs.'],
            [ShieldCheck, 'Support conversation', 'Because requirements vary, route bare metal inquiries through support until public plans are finalized.'],
          ]} />
        </div>
      </section>
      <FAQ />
    </SeoPage>
  );
}

export function LocationsPage() {
  return (
    <SeoPage path="/locations">
      <section className="product-hero">
        <div className="container">
          <Breadcrumbs items={[['Home', '/'], ['Locations', '/locations']]} />
          <p className="eyebrow">SERVER LOCATIONS</p>
          <h1>ZyntixCloud server locations.</h1>
          <p>ZyntixCloud lists hosting services in India, Germany and Singapore. Available products vary by location, hardware and plan category.</p>
        </div>
      </section>
      <section className="section">
        <div className="container option-list">
          {[
            ['India', 'Minecraft and game servers, Intel VPS, AMD VPS, Ryzen VPS, Intel VDS and AMD VDS.', '/game-servers'],
            ['Germany', 'Intel VPS plans for users who need European server placement.', '/vps/germany-intel'],
            ['Singapore', 'AMD EPYC VPS plans for users closer to Southeast Asia.', '/vps/singapore-amd'],
          ].map(([name, text, to]) => (
            <article className="option-row" key={name}>
              <div>
                <span>LOCATION</span>
                <h2>{name}</h2>
                <p>{text}</p>
              </div>
              <strong>Available</strong>
              <Button to={to} icon>View Plans</Button>
            </article>
          ))}
        </div>
      </section>
    </SeoPage>
  );
}

export function Guides() {
  const guides = [
    'How Much RAM Does a Minecraft Server Need?',
    'Paper vs Spigot vs Purpur',
    'What Is a VPS?',
    'VPS vs VDS',
    'VPS vs Dedicated Server',
    'What Is Bare Metal Hosting?',
    'How to Choose a Minecraft Server Location',
    'How Server Latency Affects Minecraft',
    'What Is DDoS Protection?',
    'NVMe vs SSD for Game Servers',
  ];
  return (
    <SeoPage path="/guides">
      <section className="product-hero">
        <div className="container">
          <Breadcrumbs items={[['Home', '/'], ['Guides', '/guides']]} />
          <p className="eyebrow">KNOWLEDGE BASE</p>
          <h1>ZyntixCloud hosting guides.</h1>
          <p>This page prepares the content architecture for future educational articles. Publish only useful, original guides that answer real server hosting questions.</p>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <SectionHeader title="Recommended high-value guide topics." description="These should be written as complete articles, not thin SEO pages." />
          <div className="included-grid">
            {guides.map((guide) => (
              <div key={guide}><Globe2 size={17} /><span>{guide}</span></div>
            ))}
          </div>
        </div>
      </section>
    </SeoPage>
  );
}

export function PolicyPage({ type }: { type: 'privacy' | 'terms' }) {
  const isPrivacy = type === 'privacy';
  const path = isPrivacy ? '/privacy' : '/terms';
  return (
    <SeoPage path={path}>
      <section className="product-hero">
        <div className="container narrow">
          <Breadcrumbs items={[['Home', '/'], [isPrivacy ? 'Privacy Policy' : 'Terms of Service', path]]} />
          <p className="eyebrow">{isPrivacy ? 'PRIVACY' : 'TERMS'}</p>
          <h1>{isPrivacy ? 'Privacy Policy' : 'Terms of Service'}</h1>
          <p>This is a production placeholder for ZyntixCloud. Replace it with your final legal policy before submitting the site for indexing or accepting public orders.</p>
        </div>
      </section>
    </SeoPage>
  );
}

export function NotFoundPage() {
  return (
    <SeoPage path="/404">
      <section className="product-hero">
        <div className="container narrow">
          <p className="eyebrow">404</p>
          <h1>Page not found.</h1>
          <p>The ZyntixCloud page you requested does not exist. Explore the main hosting categories instead.</p>
          <div className="product-actions">
            <Button to="/minecraft-hosting" icon>Minecraft Hosting</Button>
            <Button to="/vps" variant="secondary">VPS Hosting</Button>
            <Button to="/vds" variant="secondary">VDS Hosting</Button>
            <Button to="/bare-metal" variant="secondary">Bare Metal</Button>
          </div>
        </div>
      </section>
    </SeoPage>
  );
}
