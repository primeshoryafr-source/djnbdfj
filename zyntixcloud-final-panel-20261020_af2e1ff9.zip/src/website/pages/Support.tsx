import { useEffect } from 'react';
import { setSeo } from '../components/hosting/ProductPage';
import { FAQ } from '../components/common/FAQ';

const discordInvite = 'https://discord.gg/zyntixcloud';

export function Support() {
  useEffect(() => setSeo('Support | ZyntixCloud', 'Join the ZyntixCloud Discord server and create a ticket for hosting support.'), []);

  return (
    <>
      <section className="product-hero">
        <div className="container">
          <p className="eyebrow">SUPPORT</p>
          <h1>Need help with your server?</h1>
          <p>Join the ZyntixCloud Discord and create a ticket for billing, server setup, plan changes or technical support.</p>
          <div className="hero-actions">
            <a className="btn btn-primary" href={discordInvite} target="_blank" rel="noreferrer">Join Discord</a>
            <a className="btn btn-secondary" href={`${discordInvite}`} target="_blank" rel="noreferrer">Create Ticket</a>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <div className="support-ticket-form">
            <div>
              <p className="eyebrow">DISCORD SUPPORT</p>
              <h2>Create a ticket in Discord.</h2>
              <p>All support is handled through the official ZyntixCloud Discord server so you can track replies in one place.</p>
            </div>
            <div className="support-fields">
              <a className="btn btn-primary full" href={discordInvite} target="_blank" rel="noreferrer">discord.gg/zyntixcloud</a>
              <p className="support-status">After joining, open the ticket channel and create a new ticket.</p>
            </div>
          </div>
        </div>
      </section>
      <FAQ />
    </>
  );
}
