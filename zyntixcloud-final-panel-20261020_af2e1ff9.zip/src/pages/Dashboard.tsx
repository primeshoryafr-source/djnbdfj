import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { ArrowRight, CreditCard, LifeBuoy, Server } from "lucide-react";
import { formatMoney, listOrders, type BillingOrder } from "../lib/billingApi";
import { useAuth } from "../context/AuthContext";

interface ServerRecord {
  id: string;
  name: string;
  status?: string;
  productName?: string;
  planName?: string;
  location?: string;
  ram?: number;
  cpu?: number;
  disk?: number;
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-border-subtle bg-muted-subtle px-4 py-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-xl font-semibold text-foreground">{value}</p>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [servers, setServers] = useState<ServerRecord[]>([]);
  const [orders, setOrders] = useState<BillingOrder[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    axios.get<ServerRecord[]>("/api/servers")
      .then((res) => setServers(Array.isArray(res.data) ? res.data : []))
      .catch(() => setError("We couldn't load your servers."));
    listOrders().then(setOrders).catch(() => null);
  }, []);

  const unpaid = useMemo(() => orders.filter((order) => order.status === "pending_payment"), [orders]);

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-5 py-8 md:px-8">
      <section className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Welcome back, {user?.username || "there"}</h1>
          <p className="mt-2 text-sm text-muted-foreground">Manage your servers, billing and account.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={() => navigate("/store")} className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-black hover:bg-zinc-200">
            Deploy Server
            <ArrowRight className="h-4 w-4" />
          </button>
          <Link to="/servers" className="inline-flex h-10 items-center justify-center rounded-lg border border-border px-4 text-sm font-semibold text-foreground hover:bg-muted">View Servers</Link>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Active Servers" value={servers.filter((server) => server.status === "online").length} />
        <Stat label="Unpaid Invoices" value={unpaid.length} />
        <Stat label="Total Orders" value={orders.length} />
        <Stat label="Account Balance" value={formatMoney(0)} />
      </section>

      {error && <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Your Servers</h2>
          <Link to="/servers" className="text-sm text-muted-foreground hover:text-foreground">View all</Link>
        </div>
        <div className="overflow-hidden rounded-lg border border-border-subtle bg-muted-subtle">
          {servers.length === 0 ? (
            <div className="p-10 text-center">
              <Server className="mx-auto mb-3 h-7 w-7 text-muted-foreground" />
              <p className="font-medium text-foreground">No servers yet.</p>
              <p className="mt-1 text-sm text-muted-foreground">Choose a plan to deploy your first server.</p>
              <Link to="/store" className="mt-5 inline-flex h-10 items-center justify-center rounded-lg bg-white px-4 text-sm font-semibold text-black">View Plans</Link>
            </div>
          ) : (
            <div className="divide-y divide-border-subtle">
              {servers.slice(0, 6).map((server) => (
                <Link key={server.id} to={`/servers/${server.id}`} className="grid gap-3 p-4 text-sm hover:bg-muted md:grid-cols-[1.2fr_1fr_120px_100px_90px_90px_100px] md:items-center">
                  <div>
                    <p className="font-medium text-foreground">{server.name}</p>
                    <p className="text-muted-foreground">{server.id.slice(0, 8).toUpperCase()}</p>
                  </div>
                  <span className="text-muted-foreground">{server.productName || server.planName || "Server"}</span>
                  <span>{server.location || "India"}</span>
                  <span className={server.status === "online" ? "text-emerald-400" : "text-muted-foreground"}>{server.status || "offline"}</span>
                  <span>{server.ram || "-"} GB</span>
                  <span>{server.cpu || "-"}%</span>
                  <span className="font-medium text-foreground">Manage</span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-lg border border-border-subtle bg-muted-subtle p-5">
          <div className="mb-4 flex items-center gap-2">
            <CreditCard className="h-4 w-4 text-muted-foreground" />
            <h2 className="font-semibold text-foreground">Recent Billing</h2>
          </div>
          {orders.length ? orders.slice(0, 4).map((order) => (
            <Link key={order.id} to={`/billing/payment/${order.id}`} className="flex items-center justify-between border-t border-border-subtle py-3 text-sm">
              <span className="text-muted-foreground">{order.snapshot.plan.name}</span>
              <span className="font-medium text-foreground">{formatMoney(order.totalPaise)}</span>
            </Link>
          )) : <p className="text-sm text-muted-foreground">No invoices yet.</p>}
        </section>

        <section className="rounded-lg border border-border-subtle bg-muted-subtle p-5">
          <div className="mb-4 flex items-center gap-2">
            <LifeBuoy className="h-4 w-4 text-muted-foreground" />
            <h2 className="font-semibold text-foreground">Support</h2>
          </div>
          <p className="text-sm text-muted-foreground">Open help links and contact options.</p>
          <Link to="/support" className="mt-4 inline-flex h-9 items-center justify-center rounded-lg border border-border px-3 text-sm font-medium text-foreground hover:bg-muted">Open Support</Link>
        </section>
      </div>
    </div>
  );
}

