import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

type ButtonProps = {
  children: React.ReactNode;
  to?: string;
  variant?: 'primary' | 'secondary' | 'ghost';
  icon?: boolean;
  className?: string;
};

export function Button({ children, to, variant = 'primary', icon, className = '' }: ButtonProps) {
  const classes = `btn btn-${variant} ${className}`;
  const content = (
    <>
      <span>{children}</span>
      {icon && <ArrowUpRight size={16} strokeWidth={2.2} />}
    </>
  );

  if (to) {
    return (
      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="inline-flex">
        <Link className={classes} to={to}>
          {content}
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className={classes} type="button">
      {content}
    </motion.button>
  );
}
