import { vpsOptions } from '../../data/products';
import { OptionsPage } from '../../components/hosting/ProductPage';

export function VPS() {
  return <OptionsPage title="Choose your VPS location and hardware." description="VPS plans are available in India, Germany and Singapore with Intel Xeon, AMD EPYC and AMD Ryzen options." options={vpsOptions} />;
}
