import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { CheckCircle2, Circle, Loader2, Server } from "lucide-react";
import { formatMoney, getOrder, type BillingOrder } from "../lib/billingApi";

export default function PaymentStatus() {
  const { orderId } = useParams();
  const [order, setOrder] = useState<BillingOrder | null>(null);
  const [job, setJob] = useState<any>(null);

  useEffect(() => {
    if (!orderId) return;
    let active = true;
    const load = async () => {
      const data = await getOrder(orderId);
      if (!active) return;
      setOrder(data.order);
      setJob(data.provisioning);
    };
    load();
    const interval = window.setInterval(load, 4000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [orderId]);

  if (!order) return <div className="rounded-lg border border-border-subtle bg-muted-subtle p-8 text-sm text-muted-foreground">Loading payment status...</div>;

  const ready = order.status === "ready" && order.serviceId;
  const steps = [
    ["Payment confirmed", ["provisioning", "ready"].includes(order.status)],
    ["Service created", Boolean(job?.serviceId || order.serviceId)],
    ["Creating server", ["allocating_server", "installing_selected_version", "ready"].includes(job?.status)],
    ["Server ready", ready],
  ] as const;

  return (
    <div className="mx-auto max-w-2xl rounded-lg border border-border-subtle bg-muted-subtle p-6">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-muted">
          {ready ? <CheckCircle2 className="h-5 w-5 text-emerald-400" /> : <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
        </div>
        <div>
          <h1 className="text-xl font-semibold text-foreground">{ready ? "Your server is ready." : "Preparing your server..."}</h1>
          <p className="text-sm text-muted-foreground">{order.snapshot.product.name} - {order.snapshot.plan.name} - {formatMoney(order.totalPaise)}</p>
        </div>
      </div>

      <div className="mt-6 space-y-3">
        {steps.map(([label, done]) => (
          <div key={label} className="flex items-center gap-3 text-sm">
            {done ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Circle className="h-4 w-4 text-muted-foreground" />}
            <span className={done ? "text-foreground" : "text-muted-foreground"}>{label}</span>
          </div>
        ))}
      </div>

      {job?.lastError && <div className="mt-5 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-200">{job.lastError}</div>}

      {ready && (
        <Link to={`/servers/${order.serviceId}`} className="mt-6 inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-black">
          <Server className="h-4 w-4" />
          Manage Server
        </Link>
      )}
    </div>
  );
}

