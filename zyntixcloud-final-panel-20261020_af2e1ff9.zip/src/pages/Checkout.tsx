import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { CheckCircle2, CreditCard } from "lucide-react";
import { createOrder, createRazorpayCheckout, formatMoney, getCatalog, type BillingOrder, type CatalogProduct } from "../lib/billingApi";

declare global {
  interface Window {
    Razorpay?: any;
  }
}

export default function Checkout() {
  const { productId } = useParams();
  const [search] = useSearchParams();
  const navigate = useNavigate();
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [serverName, setServerName] = useState("Minecraft Server");
  const [software, setSoftware] = useState("PAPER");
  const [version, setVersion] = useState("1.21.4");
  const [order, setOrder] = useState<BillingOrder | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getCatalog().then((items) => {
      setProducts(items);
      const product = items.find((candidate) => candidate.id === productId);
      if (product?.defaultSoftware) setSoftware(product.defaultSoftware);
      if (product?.defaultVersion) setVersion(product.defaultVersion);
      if (product?.kind === "bot") setServerName("Bot Service");
    });
  }, [productId]);

  const product = useMemo(() => products.find((candidate) => candidate.id === productId), [products, productId]);
  const plan = product?.plans.find((candidate) => candidate.id === search.get("plan"));

  const submit = async () => {
    if (!product || !plan) return;
    setBusy(true);
    setError("");
    try {
      const created = await createOrder(product.id, plan.id, { serverName, software, version });
      setOrder(created);
      sessionStorage.setItem("lixcloud_cart", JSON.stringify({ orderId: created.id }));
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || "Unable to create order.");
    } finally {
      setBusy(false);
    }
  };

  const pay = async () => {
    if (!order) return;
    setBusy(true);
    setError("");
    try {
      const checkout = await createRazorpayCheckout(order.id);
      if (!window.Razorpay) {
        window.location.href = `/billing/payment/${order.id}`;
        return;
      }
      const rz = new window.Razorpay({
        key: checkout.keyId,
        amount: checkout.amount,
        currency: checkout.currency,
        name: checkout.name,
        description: checkout.description,
        order_id: checkout.orderId,
        handler: async (response: any) => {
          const axios = (await import("axios")).default;
          await axios.post("/api/billing/payments/verify", { internalOrderId: order.id, ...response });
          navigate(`/billing/payment/${order.id}`);
        },
        modal: { ondismiss: () => setBusy(false) },
      });
      rz.open();
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || "Unable to start payment.");
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!document.querySelector("script[src='https://checkout.razorpay.com/v1/checkout.js']")) {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  if (!product || !plan) {
    return <div className="rounded-lg border border-border-subtle bg-muted-subtle p-8 text-sm text-muted-foreground">Select a valid product and plan from the store.</div>;
  }

  const totals = order || { subtotalPaise: plan.pricePaise, taxPaise: 0, totalPaise: plan.pricePaise };

  return (
    <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[1fr_360px]">
      <section className="rounded-lg border border-border-subtle bg-muted-subtle p-6">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Configure</p>
        <h1 className="mt-2 text-2xl font-semibold text-foreground">{product.name}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{product.location} - {product.processor}</p>

        <div className="mt-6 grid gap-4">
          <label className="grid gap-2 text-sm">
            <span className="font-medium text-foreground">Server name</span>
            <input value={serverName} onChange={(event) => setServerName(event.target.value)} maxLength={48} />
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="grid gap-2 text-sm">
              <span className="font-medium text-foreground">Software</span>
              <select value={software} onChange={(event) => setSoftware(event.target.value)}>
                {product.allowedSoftware.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            <label className="grid gap-2 text-sm">
              <span className="font-medium text-foreground">Version</span>
              <input value={version} onChange={(event) => setVersion(event.target.value)} />
            </label>
          </div>
        </div>

        {error && <div className="mt-5 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}
      </section>

      <aside className="rounded-lg border border-border-subtle bg-[#080B10] p-6">
        <h2 className="text-lg font-semibold text-foreground">Order Summary</h2>
        <div className="mt-5 space-y-4 text-sm">
          <div>
            <p className="font-medium text-foreground">{plan.name}</p>
            <p className="text-muted-foreground">{product.name}</p>
          </div>
          <div className="grid grid-cols-3 gap-3 rounded-lg border border-border-subtle bg-muted-subtle p-3">
            <span>{plan.memoryLabel}</span>
            <span>{plan.cpuLabel}</span>
            <span>{plan.diskLabel}</span>
          </div>
          <div className="space-y-2 border-t border-border-subtle pt-4">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatMoney(totals.subtotalPaise)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>{totals.taxPaise ? formatMoney(totals.taxPaise) : "Calculated separately"}</span></div>
            <div className="flex justify-between text-base font-semibold"><span>Total</span><span>{formatMoney(totals.totalPaise)}</span></div>
          </div>
        </div>
        {!order ? (
          <button disabled={busy} onClick={submit} className="mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-black disabled:opacity-60">
            <CheckCircle2 className="h-4 w-4" />
            Review Order
          </button>
        ) : (
          <button disabled={busy} onClick={pay} className="mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-black disabled:opacity-60">
            <CreditCard className="h-4 w-4" />
            Pay {formatMoney(order.totalPaise)}
          </button>
        )}
      </aside>
    </div>
  );
}

