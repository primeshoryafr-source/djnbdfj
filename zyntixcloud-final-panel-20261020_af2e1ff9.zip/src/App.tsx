import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SettingsProvider } from './context/SettingsContext';
import { UploadProvider } from './context/UploadContext';

import Layout from './components/Layout';
import { GlobalBackground } from './components/GlobalBackground';
import { TutorialOverlay } from './components/TutorialOverlay';
import { SystemUpdateListener } from './components/SystemUpdateListener';

import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import ServerList from './pages/ServerList';
import CreateServer from './pages/CreateServer';
import ServerView from './pages/ServerView';
import AccountPage from './pages/AccountPage';
import AdminServers from './pages/AdminServers';
import AdminSettingsPage from './pages/AdminSettingsPage';
import ApiKeysPage from './pages/ApiKeysPage';
import Nodes from './pages/Nodes';
import Store from './pages/Store';
import Checkout from './pages/Checkout';
import Billing from './pages/Billing';
import PaymentStatus from './pages/PaymentStatus';
import Cart from './pages/Cart';
import Notifications from './pages/Notifications';
import WebsiteApp from './website/WebsiteApp';

// ============================================
// ZyntixCloud Panel — App Router
// ============================================

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0612]">
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-10 h-10 rounded-full animate-spin"
            style={{
              border: '2px solid rgba(255,255,255,.2)',
              borderTopColor: '#ffffff',
              borderRightColor: '#e5e5e5',
            }}
          />
          <span className="text-[10px] font-mono uppercase tracking-widest text-white/55">
            Loading...
          </span>
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function ProtectedPage({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <Layout>{children}</Layout>
    </ProtectedRoute>
  );
}

function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0612]">
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-10 h-10 rounded-full animate-spin"
            style={{
              border: '2px solid rgba(255,255,255,.2)',
              borderTopColor: '#ffffff',
              borderRightColor: '#e5e5e5',
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<WebsiteApp />} />
      <Route path="/minecraft-hosting" element={<WebsiteApp />} />
      <Route path="/game-servers/*" element={<WebsiteApp />} />
      <Route path="/bot-hosting" element={<WebsiteApp />} />
      <Route path="/vps/*" element={<WebsiteApp />} />
      <Route path="/vds/*" element={<WebsiteApp />} />
      <Route path="/bare-metal" element={<WebsiteApp />} />
      <Route path="/locations" element={<WebsiteApp />} />
      <Route path="/guides" element={<WebsiteApp />} />
      <Route path="/about" element={<WebsiteApp />} />
      <Route path="/support" element={<WebsiteApp />} />
      <Route path="/privacy" element={<WebsiteApp />} />
      <Route path="/terms" element={<WebsiteApp />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Protected panel routes */}
      <Route path="/dashboard" element={<ProtectedPage><Dashboard /></ProtectedPage>} />
      <Route path="/servers" element={<ProtectedPage><ServerList /></ProtectedPage>} />
      <Route path="/servers/create" element={<ProtectedPage><CreateServer /></ProtectedPage>} />
      <Route path="/servers/:id/*" element={<ProtectedPage><ServerView /></ProtectedPage>} />
      <Route path="/store" element={<ProtectedPage><Store /></ProtectedPage>} />
      <Route path="/order/:productId" element={<ProtectedPage><Checkout /></ProtectedPage>} />
      <Route path="/checkout" element={<ProtectedPage><Cart /></ProtectedPage>} />
      <Route path="/cart" element={<ProtectedPage><Cart /></ProtectedPage>} />
      <Route path="/billing" element={<ProtectedPage><Billing /></ProtectedPage>} />
      <Route path="/billing/payment/:orderId" element={<ProtectedPage><PaymentStatus /></ProtectedPage>} />
      <Route path="/notifications" element={<ProtectedPage><Notifications /></ProtectedPage>} />
      <Route path="/account" element={<ProtectedPage><AccountPage /></ProtectedPage>} />
      <Route path="/admin/servers" element={<ProtectedPage><AdminServers /></ProtectedPage>} />
      <Route path="/admin/settings" element={<ProtectedPage><AdminSettingsPage /></ProtectedPage>} />
      <Route path="/api-keys" element={<ProtectedPage><ApiKeysPage /></ProtectedPage>} />
      <Route path="/nodes" element={<ProtectedPage><Nodes /></ProtectedPage>} />
      <Route path="*" element={<WebsiteApp />} />
    </Routes>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AuthProvider>
        <UploadProvider>
          <Router>
            {/* ═══ Global wallpaper background ═══ */}
            <GlobalBackground />

            {/* ═══ Main app ═══ */}
            <div className="relative z-10">
              <AppRoutes />
            </div>

            {/* ═══ System update listener ═══ */}
            <SystemUpdateListener />
          </Router>
        </UploadProvider>
      </AuthProvider>
    </SettingsProvider>
  );
}

