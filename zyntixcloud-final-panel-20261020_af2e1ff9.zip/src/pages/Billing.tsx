import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { formatMoney, listOrders, type BillingOrder } from "../lib/billingApi";

export default function Billing() {
  const [orders, setOrders] = useState<BillingOrder[]>([]);

  useEffect(() => {
    listOrders().then(setOrders);
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Billing</p>
        <h1 className="mt-2 text-3xl font-semibold text-foreground">Invoices and orders</h1>
      </div>
      <div className="overflow-hidden rounded-lg border border-border-subtle bg-muted-subtle">
        {orders.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No billing activity yet.</div>
        ) : (
          <div className="divide-y divide-border-subtle">
            {orders.map((order) => (
              <Link key={order.id} to={`/billing/payment/${order.id}`} className="grid gap-2 p-4 text-sm hover:bg-muted md:grid-cols-[1fr_140px_140px_120px] md:items-center">
                <div>
                  <p className="font-medium text-foreground">{order.snapshot.product.name} - {order.snapshot.plan.name}</p>
                  <p className="text-muted-foreground">{new Date(order.createdAt).toLocaleString()}</p>
                </div>
                <span className="capitalize text-muted-foreground">{order.status.replace(/_/g, " ")}</span>
                <span className="font-medium text-foreground">{formatMoney(order.totalPaise)}</span>
                <span className="text-muted-foreground">View</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

