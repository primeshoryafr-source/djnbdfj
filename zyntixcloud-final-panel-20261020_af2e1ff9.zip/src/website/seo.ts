import { products, type HostingProduct } from "./data/products";

export const BRAND_NAME = "ZyntixCloud";
export const BRAND_ALTERNATE = "ZyntixCloud Cloud";
export const DEFAULT_SITE_URL =
  (typeof process !== "undefined" &&
    (process.env.ZYNTIXCLOUD_SITE_URL || process.env.SITE_URL || process.env.VITE_SITE_URL)) ||
  "https://zyntixcloud.cloud";

export type BreadcrumbItem = {
  name: string;
  path: string;
};

export type SeoRoute = {
  path: string;
  title: string;
  description: string;
  h1?: string;
  image?: string;
  type?: "website" | "product";
  noindex?: boolean;
  breadcrumbs?: BreadcrumbItem[];
  structuredData?: Record<string, unknown>[];
};

const publicLogoPath = "/zyntixcloud-logo.png";

export function normalizeSiteUrl(siteUrl = DEFAULT_SITE_URL) {
  return siteUrl.replace(/\/+$/, "");
}

export function absoluteUrl(pathname = "/", siteUrl = DEFAULT_SITE_URL) {
  const base = normalizeSiteUrl(siteUrl);
  if (/^https?:\/\//i.test(pathname)) return pathname;
  return `${base}${pathname.startsWith("/") ? pathname : `/${pathname}`}`;
}

export function canonicalPath(pathname: string) {
  const clean = pathname.split("?")[0].split("#")[0] || "/";
  if (clean !== "/" && clean.endsWith("/")) return clean.slice(0, -1);
  return clean;
}

export function organizationSchema(siteUrl = DEFAULT_SITE_URL) {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: BRAND_NAME,
    alternateName: [BRAND_ALTERNATE],
    url: absoluteUrl("/", siteUrl),
    logo: absoluteUrl(publicLogoPath, siteUrl),
    description:
      "ZyntixCloud provides Minecraft hosting, VPS, VDS and bare metal infrastructure for game servers and cloud workloads.",
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer support",
      url: absoluteUrl("/support", siteUrl),
    },
  };
}

export function websiteSchema(siteUrl = DEFAULT_SITE_URL) {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: BRAND_NAME,
    alternateName: BRAND_ALTERNATE,
    url: absoluteUrl("/", siteUrl),
  };
}

export function breadcrumbSchema(items: BreadcrumbItem[], siteUrl = DEFAULT_SITE_URL) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: absoluteUrl(item.path, siteUrl),
    })),
  };
}

function productSchema(product: HostingProduct, siteUrl = DEFAULT_SITE_URL) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `${product.title} by ${BRAND_NAME}`,
    brand: {
      "@type": "Brand",
      name: BRAND_NAME,
    },
    description: product.description,
    category: product.eyebrow,
    url: absoluteUrl(product.slug, siteUrl),
    offers: product.plans.map((plan) => ({
      "@type": "Offer",
      name: plan.name,
      priceCurrency: "INR",
      price: plan.price.replace(/[^\d.]/g, ""),
      availability: "https://schema.org/InStock",
      url: absoluteUrl(product.slug, siteUrl),
      itemOffered: {
        "@type": "Service",
        name: `${plan.name} ${product.title}`,
        description: `${plan.ram}, ${plan.cpu}, ${plan.storage}`,
      },
    })),
  };
}

export const seoRoutes: SeoRoute[] = [
  {
    path: "/",
    title: "ZyntixCloud — Minecraft Hosting, VPS, VDS & Bare Metal Servers",
    h1: "Fast, reliable hosting at a fair price",
    description:
      "ZyntixCloud provides fast Minecraft hosting, VPS, VDS and bare metal servers with NVMe storage, server management tools and supported DDoS protection.",
    structuredData: [organizationSchema(), websiteSchema()],
  },
  {
    path: "/minecraft-hosting",
    title: "Minecraft Server Hosting by ZyntixCloud",
    description:
      "Run Minecraft Java servers on ZyntixCloud with NVMe storage, Paper and Purpur support, Pterodactyl access and India-based game hosting plans.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Minecraft Hosting", path: "/minecraft-hosting" },
    ],
  },
  {
    path: "/game-servers",
    title: "Game Server Hosting by ZyntixCloud",
    description:
      "Choose ZyntixCloud game server hosting with budget Intel Xeon plans and premium AMD EPYC plans for Minecraft and other supported games.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Game Servers", path: "/game-servers" },
    ],
  },
  {
    path: "/game-servers/budget",
    title: "Budget Game Server Hosting India | ZyntixCloud",
    description:
      "Affordable Intel Xeon game server hosting in India from ZyntixCloud with NVMe storage, Pterodactyl access and visible monthly plans.",
    type: "product",
    structuredData: [productSchema(products.budgetGame)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Game Servers", path: "/game-servers" },
      { name: "Budget Game Servers", path: "/game-servers/budget" },
    ],
  },
  {
    path: "/game-servers/premium",
    title: "Premium AMD EPYC Game Server Hosting | ZyntixCloud",
    description:
      "Premium ZyntixCloud game server hosting in India with AMD EPYC processors, ECC memory, NVMe storage and Pterodactyl access.",
    type: "product",
    structuredData: [productSchema(products.premiumGame)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Game Servers", path: "/game-servers" },
      { name: "Premium Game Servers", path: "/game-servers/premium" },
    ],
  },
  {
    path: "/vps",
    title: "VPS Hosting by ZyntixCloud",
    description:
      "ZyntixCloud VPS hosting includes root access, KVM-style virtual servers, NVMe storage and plans across India, Germany and Singapore.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
    ],
  },
  {
    path: "/vps/india-intel",
    title: "India Intel VPS Hosting | ZyntixCloud",
    description: "India Intel VPS hosting from ZyntixCloud with root access, NVMe storage, ECC memory and full VPS management tools.",
    type: "product",
    structuredData: [productSchema(products.indiaIntel)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
      { name: "India Intel VPS", path: "/vps/india-intel" },
    ],
  },
  {
    path: "/vps/india-amd",
    title: "India AMD EPYC VPS Hosting | ZyntixCloud",
    description: "India AMD EPYC VPS hosting from ZyntixCloud with root access, ECC memory, NVMe storage and a full management panel.",
    type: "product",
    structuredData: [productSchema(products.indiaAmd)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
      { name: "India AMD VPS", path: "/vps/india-amd" },
    ],
  },
  {
    path: "/vps/india-ryzen",
    title: "India Ryzen VPS Hosting | ZyntixCloud",
    description: "High-frequency India Ryzen VPS hosting from ZyntixCloud with NVMe storage, root access and management tools.",
    type: "product",
    structuredData: [productSchema(products.indiaRyzen)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
      { name: "India Ryzen VPS", path: "/vps/india-ryzen" },
    ],
  },
  {
    path: "/vps/germany-intel",
    title: "Germany Intel VPS Hosting | ZyntixCloud",
    description: "Germany Intel VPS hosting from ZyntixCloud with root access, ECC memory, NVMe storage and server management tools.",
    type: "product",
    structuredData: [productSchema(products.germanyIntel)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
      { name: "Germany Intel VPS", path: "/vps/germany-intel" },
    ],
  },
  {
    path: "/vps/singapore-amd",
    title: "Singapore AMD EPYC VPS Hosting | ZyntixCloud",
    description: "Singapore AMD EPYC VPS hosting from ZyntixCloud with ECC memory, NVMe storage, root access and management tools.",
    type: "product",
    structuredData: [productSchema(products.singaporeAmd)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VPS Hosting", path: "/vps" },
      { name: "Singapore AMD VPS", path: "/vps/singapore-amd" },
    ],
  },
  {
    path: "/vds",
    title: "VDS Hosting by ZyntixCloud",
    description:
      "ZyntixCloud VDS hosting provides virtual dedicated servers with dedicated CPU resources, ECC memory, NVMe storage and management tools.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VDS Hosting", path: "/vds" },
    ],
  },
  {
    path: "/vds/intel",
    title: "Intel Xeon VDS Hosting | ZyntixCloud",
    description: "Intel Xeon VDS hosting from ZyntixCloud with dedicated CPU resources, ECC memory, NVMe storage and VNC access.",
    type: "product",
    structuredData: [productSchema(products.intelVds)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VDS Hosting", path: "/vds" },
      { name: "Intel Xeon VDS", path: "/vds/intel" },
    ],
  },
  {
    path: "/vds/amd",
    title: "AMD EPYC VDS Hosting | ZyntixCloud",
    description: "AMD EPYC VDS hosting from ZyntixCloud with dedicated CPU resources, ECC memory, NVMe storage and management access.",
    type: "product",
    structuredData: [productSchema(products.amdVds)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "VDS Hosting", path: "/vds" },
      { name: "AMD EPYC VDS", path: "/vds/amd" },
    ],
  },
  {
    path: "/bare-metal",
    title: "Bare Metal Servers by ZyntixCloud",
    description:
      "Explore ZyntixCloud bare metal and dedicated server infrastructure for workloads that need physical server resources and direct control.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Bare Metal", path: "/bare-metal" },
    ],
  },
  {
    path: "/locations",
    title: "ZyntixCloud Server Locations",
    description:
      "See ZyntixCloud hosting locations and the services available in India, Germany and Singapore for game servers, VPS and VDS plans.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Locations", path: "/locations" },
    ],
  },
  {
    path: "/bot-hosting",
    title: "Discord Bot Hosting | ZyntixCloud",
    description:
      "ZyntixCloud bot hosting keeps Discord bots and lightweight applications online with Pterodactyl access and NVMe storage.",
    type: "product",
    structuredData: [productSchema(products.bot)],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Bot Hosting", path: "/bot-hosting" },
    ],
  },
  {
    path: "/about",
    title: "About ZyntixCloud",
    description:
      "Learn what ZyntixCloud provides: Minecraft hosting, VPS, VDS, bot hosting and bare metal infrastructure across supported locations.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "About", path: "/about" },
    ],
  },
  {
    path: "/support",
    title: "Support | ZyntixCloud",
    description:
      "Get support for ZyntixCloud hosting services, server panel access, billing questions and product guidance.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Support", path: "/support" },
    ],
  },
  {
    path: "/guides",
    title: "ZyntixCloud Hosting Guides",
    description:
      "A planned knowledge base for Minecraft hosting, VPS, VDS, bare metal servers, latency, storage and server security topics.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Guides", path: "/guides" },
    ],
  },
  {
    path: "/privacy",
    title: "Privacy Policy | ZyntixCloud",
    description:
      "Read the ZyntixCloud privacy policy placeholder and update it with your final legal policy before production launch.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Privacy Policy", path: "/privacy" },
    ],
  },
  {
    path: "/terms",
    title: "Terms of Service | ZyntixCloud",
    description:
      "Read the ZyntixCloud terms placeholder and replace it with your final Terms of Service before production launch.",
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Terms of Service", path: "/terms" },
    ],
  },
];

const noindexPrefixes = [
  "/login",
  "/register",
  "/dashboard",
  "/servers",
  "/store",
  "/order",
  "/checkout",
  "/cart",
  "/billing",
  "/notifications",
  "/account",
  "/admin",
  "/api-keys",
  "/nodes",
];

export function isNoindexPath(pathname: string) {
  const path = canonicalPath(pathname);
  return noindexPrefixes.some((prefix) => path === prefix || path.startsWith(`${prefix}/`));
}

export function getSeoRoute(pathname: string, siteUrl = DEFAULT_SITE_URL): SeoRoute {
  const path = canonicalPath(pathname);
  const route = seoRoutes.find((item) => item.path === path);
  if (route) {
    const structuredData = [...(route.structuredData || [])];
    if (route.breadcrumbs?.length) structuredData.push(breadcrumbSchema(route.breadcrumbs, siteUrl));
    return { ...route, structuredData };
  }
  if (isNoindexPath(path)) {
    return {
      path,
      title: "ZyntixCloud Panel",
      description: "Private ZyntixCloud panel area.",
      noindex: true,
    };
  }
  return {
    path,
    title: "Page Not Found | ZyntixCloud",
    description: "This ZyntixCloud page could not be found. Explore Minecraft hosting, VPS, VDS and bare metal server options.",
    noindex: true,
  };
}

export function renderMetaTags(route: SeoRoute, siteUrl = DEFAULT_SITE_URL) {
  const url = absoluteUrl(route.path, siteUrl);
  const image = absoluteUrl(route.image || publicLogoPath, siteUrl);
  const robots = route.noindex ? "noindex,follow" : "index,follow";
  const jsonLd = route.structuredData?.length
    ? `<script type="application/ld+json">${JSON.stringify(route.structuredData)}</script>`
    : "";

  return [
    `<title>${escapeHtml(route.title)}</title>`,
    `<meta name="description" content="${escapeHtml(route.description)}" />`,
    `<link rel="canonical" href="${escapeHtml(url)}" />`,
    `<meta name="robots" content="${robots}" />`,
    `<meta property="og:type" content="${route.type || "website"}" />`,
    `<meta property="og:site_name" content="${BRAND_NAME}" />`,
    `<meta property="og:title" content="${escapeHtml(route.title)}" />`,
    `<meta property="og:description" content="${escapeHtml(route.description)}" />`,
    `<meta property="og:url" content="${escapeHtml(url)}" />`,
    `<meta property="og:image" content="${escapeHtml(image)}" />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${escapeHtml(route.title)}" />`,
    `<meta name="twitter:description" content="${escapeHtml(route.description)}" />`,
    `<meta name="twitter:image" content="${escapeHtml(image)}" />`,
    jsonLd,
  ]
    .filter(Boolean)
    .join("\n    ");
}

export function renderSeoBody(route: SeoRoute) {
  if (route.noindex) {
    return `<main><h1>${escapeHtml(route.title)}</h1><p>${escapeHtml(route.description)}</p></main>`;
  }
  const links = [
    ["/minecraft-hosting", "Minecraft Hosting"],
    ["/vps", "VPS Hosting"],
    ["/vds", "VDS Hosting"],
    ["/bare-metal", "Bare Metal Servers"],
    ["/locations", "Locations"],
    ["/about", "About ZyntixCloud"],
    ["/support", "Support"],
  ]
    .filter(([href]) => href !== route.path)
    .map(([href, label]) => `<a href="${href}">${label}</a>`)
    .join(" ");
  const h1 = route.h1 || route.title.replace(/\s+\|\s+ZyntixCloud$/, "");
  return `<main class="seo-fallback"><h1>${escapeHtml(h1)}</h1><p>${escapeHtml(route.description)}</p><nav aria-label="Important ZyntixCloud pages">${links}</nav></main>`;
}

export function applySeo(route: SeoRoute, siteUrl = DEFAULT_SITE_URL) {
  if (typeof document === "undefined") return;
  const fullRoute = getSeoRoute(route.path, siteUrl);
  const merged = { ...fullRoute, ...route };
  const url = absoluteUrl(merged.path, siteUrl);
  const image = absoluteUrl(merged.image || publicLogoPath, siteUrl);
  document.title = merged.title;
  upsertMeta("name", "description", merged.description);
  upsertLink("canonical", url);
  upsertMeta("name", "robots", merged.noindex ? "noindex,follow" : "index,follow");
  upsertMeta("property", "og:type", merged.type || "website");
  upsertMeta("property", "og:site_name", BRAND_NAME);
  upsertMeta("property", "og:title", merged.title);
  upsertMeta("property", "og:description", merged.description);
  upsertMeta("property", "og:url", url);
  upsertMeta("property", "og:image", image);
  upsertMeta("name", "twitter:card", "summary_large_image");
  upsertMeta("name", "twitter:title", merged.title);
  upsertMeta("name", "twitter:description", merged.description);
  upsertMeta("name", "twitter:image", image);
  const existing = document.getElementById("zyntixcloud-jsonld");
  existing?.remove();
  if (merged.structuredData?.length) {
    const script = document.createElement("script");
    script.id = "zyntixcloud-jsonld";
    script.type = "application/ld+json";
    script.text = JSON.stringify(merged.structuredData);
    document.head.appendChild(script);
  }
}

function upsertMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function upsertLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
