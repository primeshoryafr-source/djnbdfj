import React, { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import { matchPath, useLocation } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import GlobalSearchModal from "./GlobalSearchModal";
import NotificationsDropdown from "./NotificationsDropdown";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleToggle = () => {
      if (window.innerWidth < 768) setMobileOpen((value) => !value);
      else setIsCollapsed((value) => !value);
    };
    window.addEventListener("toggle-sidebar", handleToggle);
    return () => window.removeEventListener("toggle-sidebar", handleToggle);
  }, []);

  const isServerView = matchPath("/servers/:id/*", location.pathname) && !matchPath("/servers/create", location.pathname);
  const isCreateServer = matchPath("/servers/create", location.pathname);
  const isAdminSettings = matchPath("/admin/settings", location.pathname);

  const shellStyles = (
    <style dangerouslySetInnerHTML={{ __html: `
      @keyframes lcLayoutIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .lc-layout-in { animation: lcLayoutIn .32s cubic-bezier(.16,1,.3,1) both; }
      .lc-topbar {
        background: rgba(8, 11, 16, .92);
        border-bottom: 1px solid rgba(255,255,255,.10);
        backdrop-filter: blur(18px);
        -webkit-backdrop-filter: blur(18px);
      }
      .lc-status-pill {
        background: rgba(255,255,255,.035);
        border: 1px solid rgba(255,255,255,.10);
      }
      .lc-status-dot {
        background: #34D399;
        box-shadow: 0 0 0 0 rgba(52,211,153,.45);
        animation: lcPulse 1.8s ease-in-out infinite;
      }
      @keyframes lcPulse {
        50% { box-shadow: 0 0 0 5px rgba(52,211,153,0); }
      }
      .lc-overlay {
        background: rgba(0,0,0,.65);
        backdrop-filter: blur(10px);
      }
      .lc-app-shell {
        display: flex;
        height: 100dvh;
        width: 100%;
        overflow: hidden;
      }
      .lc-sidebar-shell {
        position: fixed;
        inset: 0 auto 0 0;
        z-index: 50;
        flex-shrink: 0;
        transform: translateX(-100%);
        transition: transform .3s ease;
      }
      .lc-sidebar-shell.open { transform: translateX(0); }
      .lc-content-shell {
        position: relative;
        display: flex;
        height: 100%;
        min-width: 0;
        flex: 1;
        flex-direction: column;
        overflow: hidden;
      }
      .lc-mobile-menu-btn {
        display: flex;
        height: 40px;
        width: 40px;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        color: rgb(161 161 170);
        transition: background .2s, color .2s;
      }
      .lc-mobile-menu-btn:hover {
        background: rgba(255,255,255,.06);
        color: #fff;
      }
      .lc-desktop-status { display: none; }
      @media (min-width: 768px) {
        .lc-sidebar-shell {
          position: relative !important;
          inset: auto !important;
          transform: translateX(0) !important;
        }
        .lc-mobile-menu-btn { display: none !important; }
        .lc-desktop-status { display: flex !important; }
      }
      @media (max-width: 767px) {
        .lc-sidebar-shell.open { transform: translateX(0) !important; }
      }
    ` }} />
  );

  if (isServerView || isCreateServer || isAdminSettings) {
    return (
      <>
        {shellStyles}
        <div className="lc-app-shell bg-transparent text-foreground font-sans selection:bg-white/20">
          <main className="relative z-10 h-full w-full flex-1 overflow-auto">{children}</main>
        </div>
      </>
    );
  }

  return (
    <>
      {shellStyles}
      <div className="lc-app-shell bg-transparent text-foreground font-sans selection:bg-white/20">
        {mobileOpen && <div className="fixed inset-0 z-40 lc-overlay md:hidden" onClick={() => setMobileOpen(false)} />}

        <div className={`lc-sidebar-shell ${mobileOpen ? "open" : ""}`}>
          <Sidebar onClose={() => setMobileOpen(false)} isCollapsed={isCollapsed} toggleCollapse={() => setIsCollapsed(!isCollapsed)} />
        </div>

        <div className="lc-content-shell bg-transparent">
          <header className="sticky top-0 z-40 shrink-0 lc-topbar">
            <div className="flex h-16 items-center justify-between px-4 sm:px-6">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.dispatchEvent(new CustomEvent("toggle-sidebar"))}
                  className="lc-mobile-menu-btn"
                  title="Toggle Sidebar Menu"
                  aria-label="Toggle Sidebar Menu"
                >
                  <Menu className="h-5 w-5" />
                </button>

              </div>

              <div className="ml-auto flex items-center gap-2 sm:gap-4">
                <div className="lc-desktop-status items-center gap-2 rounded-lg px-3 py-1.5 font-mono text-[10px] tracking-widest text-white/55 lc-status-pill">
                  <span className="h-1.5 w-1.5 rounded-full lc-status-dot" />
                  ALL SYSTEMS GO
                </div>
                <GlobalSearchModal />
                <NotificationsDropdown />
              </div>
            </div>
          </header>

          <main className="relative z-0 h-full w-full flex-1 overflow-x-hidden overflow-y-auto pb-safe custom-scrollbar">
            {location.pathname === "/dashboard" ? (
              <div className="lc-layout-in">{children}</div>
            ) : (
              <div className="mx-auto w-full max-w-7xl p-4 sm:p-6 md:p-8 lc-layout-in">{children}</div>
            )}
          </main>
        </div>
      </div>
    </>
  );
}
