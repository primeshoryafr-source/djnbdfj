import React, { useEffect, useState } from "react";
import { LoadingOverlay } from "../components/LoadingOverlay";
import axios from "axios";
import {
  Save,
  AlertTriangle,
  RefreshCw,
  Settings,
  Sliders,
  Hash
} from "lucide-react";

// ============================================
// ZyntixCloud Panel — Server Properties
// Simple neutral theme
// ============================================

interface Properties {
  [key: string]: string;
}

const COMMON_PROPERTIES = [
  { key: 'online-mode', type: 'boolean', label: 'Online Mode (Premium)' },
  { key: 'pvp', type: 'boolean', label: 'Player vs Player (PvP)' },
  { key: 'hardcore', type: 'boolean', label: 'Hardcore' },
  { key: 'allow-flight', type: 'boolean', label: 'Allow Flight' },
  { key: 'enable-command-block', type: 'boolean', label: 'Enable Command Blocks' },
  { key: 'gamemode', type: 'select', options: ['survival', 'creative', 'adventure', 'spectator'], label: 'Game Mode' },
  { key: 'difficulty', type: 'select', options: ['peaceful', 'easy', 'normal', 'hard'], label: 'Difficulty' },
  { key: 'max-players', type: 'number', label: 'Max Players' },
  { key: 'motd', type: 'text', label: 'MOTD (Message of the Day)' },
  { key: 'view-distance', type: 'number', label: 'View Distance' }
];

export default function ServerProperties({ serverId }: { serverId: string }) {
  const [properties, setProperties] = useState<Properties>({});
  const [originalContent, setOriginalContent] = useState<string>("");
  const [exists, setExists] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadProperties = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`/api/servers/${serverId}/files?path=server.properties`);
      if (res.data.isFile) {
        setOriginalContent(res.data.content);
        const parsed = parseProperties(res.data.content);
        setProperties(parsed);
        setExists(true);
      } else {
        setExists(false);
      }
    } catch (e) {
      setExists(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperties();
  }, [serverId]);

  const parseProperties = (content: string): Properties => {
    const lines = content.split('\n');
    const parsed: Properties = {};
    for (const line of lines) {
      if (line.startsWith('#') || !line.trim()) continue;
      const index = line.indexOf('=');
      if (index === -1) continue;
      const key = line.substring(0, index).trim();
      const value = line.substring(index + 1).trim();
      parsed[key] = value;
    }
    return parsed;
  };

  const serializeProperties = (currentProps: Properties, originalText: string): string => {
    const lines = originalText.split('\n');
    const updatedKeys = new Set<string>();

    const updatedLines = lines.map(line => {
      if (line.startsWith('#') || !line.trim()) return line;
      const index = line.indexOf('=');
      if (index === -1) return line;
      const key = line.substring(0, index).trim();

      if (currentProps[key] !== undefined) {
        updatedKeys.add(key);
        return `${key}=${currentProps[key]}`;
      }
      return line;
    });

    for (const [key, value] of Object.entries(currentProps)) {
      if (!updatedKeys.has(key)) {
        updatedLines.push(`${key}=${value}`);
      }
    }

    return updatedLines.join('\n');
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      const newContent = serializeProperties(properties, originalContent);
      await axios.post(`/api/servers/${serverId}/files/save`, {
        filePath: 'server.properties',
        content: newContent
      });
      setOriginalContent(newContent);
      alert('Properties saved successfully! You may need to restart the server for changes to take effect.');
    } catch (e) {
      alert('Failed to save properties.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChange = (key: string, value: string) => {
    setProperties(prev => ({ ...prev, [key]: value }));
  };

  const advancedKeys = Object.keys(properties).filter(
    k => !COMMON_PROPERTIES.find(cp => cp.key === k)
  );

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="flex items-center gap-3 text-sm text-white/70">
          <RefreshCw className="h-5 w-5 animate-spin" />
          Loading properties...
        </div>
      </div>
    );
  }

  if (!exists) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
        <div
          className="w-20 h-20 rounded-2xl flex items-center justify-center mb-5"
          style={{
            background: 'rgba(245,158,11,.08)',
            border: '1px solid rgba(245,158,11,.4)',
            boxShadow: 'none',
          }}
        >
          <AlertTriangle className="w-10 h-10" style={{ color: '#fbbf24' }} />
        </div>
        <h3 className="text-lg font-bold mb-2" style={{ color: '#fcd34d' }}>
          server.properties Not Found
        </h3>
        <p className="text-sm max-w-md leading-relaxed" style={{ color: 'rgba(252,211,77,.75)' }}>
          The property file does not exist yet. Please start the server at least once to generate the server.properties file.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto aw-sp-scroll p-4 md:p-6">
      <style dangerouslySetInnerHTML={{__html: `
        .aw-sp-glass {
          background: rgba(255,255,255,.035);
          border: 1px solid rgba(255,255,255,.12);
          border-radius: 16px;
          position: relative;
          overflow: hidden;
        }

        .aw-sp-card {
          transition: border-color .2s ease, background-color .2s ease;
        }
        .aw-sp-card:hover {
          border-color: rgba(255,255,255,.22);
          background: rgba(255,255,255,.05);
        }

        .aw-sp-btn {
          transition: background-color .2s ease, border-color .2s ease, color .2s ease;
        }
        .aw-sp-btn:hover:not(:disabled) {
          transform: none;
        }
        .aw-sp-btn:active:not(:disabled) {
          transform: none;
        }

        .aw-sp-scroll::-webkit-scrollbar { width: 8px; }
        .aw-sp-scroll::-webkit-scrollbar-track { background: transparent; }
        .aw-sp-scroll::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,.22);
          border-radius: 4px;
        }
        .aw-sp-scroll::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,.34);
        }

        .aw-sp-input {
          transition: border-color .2s ease, background-color .2s ease;
        }
        .aw-sp-input:focus {
          outline: none;
          border-color: rgba(255,255,255,.32) !important;
          box-shadow: none;
        }
        .aw-sp-input::placeholder { color: rgba(161,161,170,.5); }

        /* Select option styling */
        .aw-sp-select option {
          background: #05070b;
          color: #ffffff;
        }
        .aw-sp-in { animation: none; }
      `}} />

      <div className="max-w-4xl mx-auto">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2
              className="text-2xl font-semibold tracking-tight flex items-center gap-2.5"
              style={{ color: '#fff' }}
            >
              <span
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{
          background: 'rgba(255,255,255,.12)',
                  border: '1px solid rgba(255,255,255,.18)',
                  boxShadow: 'none',
                }}
              >
                <Settings className="w-5 h-5" style={{ color: '#e5e5e5' }} />
              </span>
              Properties
            </h2>
            <p
              className="text-sm mt-1.5"
              style={{ color: 'rgba(255,255,255,.55)' }}
            >
              Configure core server rules and settings
            </p>
          </div>

          <button
            onClick={handleSave}
            disabled={isSaving}
            className="aw-sp-btn px-5 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm shrink-0"
            style={{
              background: '#ffffff',
              color: '#05070b',
              boxShadow: 'none',
            }}
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Save Changes
              </>
            )}
          </button>
        </div>

        {/* Common Properties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {COMMON_PROPERTIES.map((prop, idx) => (
            <div
              key={prop.key}
              className="aw-sp-card aw-sp-glass p-5"
            >
              <div className="flex items-center justify-between mb-3 gap-3">
                <label
                  className="text-[11px] font-bold uppercase tracking-widest flex-1 min-w-0"
                  style={{ color: '#e5e5e5' }}
                >
                  {prop.label}
                </label>
                {prop.type === 'boolean' && (
                  <button
                    onClick={() => handleChange(prop.key, properties[prop.key] === 'true' ? 'false' : 'true')}
                  className="aw-sp-btn relative inline-flex h-6 w-11 items-center rounded-full shrink-0"
                    style={{
                      background: properties[prop.key] === 'true'
                        ? '#ffffff'
                        : 'rgba(0,0,0,.5)',
                      border: properties[prop.key] === 'true'
                        ? '1px solid rgba(255,255,255,.6)'
                        : '1px solid rgba(255,255,255,.2)',
                      boxShadow: 'none',
                    }}
                  >
                    <span
                      className="inline-block h-4 w-4 transform rounded-full transition-transform"
                      style={{
                        transform: properties[prop.key] === 'true' ? 'translateX(24px)' : 'translateX(4px)',
                        background: properties[prop.key] === 'true' ? '#05070b' : '#ffffff',
                        boxShadow: '0 2px 4px rgba(0,0,0,.4)',
                      }}
                    />
                  </button>
                )}
              </div>

              {prop.type === 'select' && (
                <select
                  value={properties[prop.key] || ''}
                  onChange={(e) => handleChange(prop.key, e.target.value)}
                  className="aw-sp-input aw-sp-select w-full rounded-xl px-4 py-2.5 text-sm font-medium"
                  style={{
                    background: 'rgba(0,0,0,.5)',
                    border: '1px solid rgba(255,255,255,.25)',
                    color: '#ffffff',
                    cursor: 'pointer',
                  }}
                >
                  {prop.options?.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              )}

              {prop.type === 'number' && (
                <input
                  type="number"
                  value={properties[prop.key] || ''}
                  onChange={(e) => handleChange(prop.key, e.target.value)}
                  className="aw-sp-input w-full rounded-xl px-4 py-2.5 text-sm font-medium"
                  style={{
                    background: 'rgba(0,0,0,.5)',
                    border: '1px solid rgba(255,255,255,.25)',
                    color: '#ffffff',
                    caretColor: '#e5e5e5',
                  }}
                />
              )}

              {prop.type === 'text' && (
                <input
                  type="text"
                  value={properties[prop.key] || ''}
                  onChange={(e) => handleChange(prop.key, e.target.value)}
                  className="aw-sp-input w-full rounded-xl px-4 py-2.5 text-sm font-medium"
                  style={{
                    background: 'rgba(0,0,0,.5)',
                    border: '1px solid rgba(255,255,255,.25)',
                    color: '#ffffff',
                    caretColor: '#e5e5e5',
                  }}
                />
              )}

              <p
                className="text-[10px] mt-3 font-mono flex items-center gap-1"
                style={{ color: 'rgba(255,255,255,.55)' }}
              >
                <Hash size={9} />
                {prop.key}
              </p>
            </div>
          ))}
        </div>

        {/* Advanced Properties */}
        {advancedKeys.length > 0 && (
          <div className="mt-8 aw-sp-in" style={{ animationDelay: '.35s' }}>
            <h3
              className="text-base font-bold tracking-tight mb-4 flex items-center gap-2"
              style={{ color: '#ffffff' }}
            >
              <Sliders className="w-4 h-4" style={{ color: '#e5e5e5' }} />
              Advanced Properties
              <span
                className="px-2 py-0.5 rounded-md font-mono text-[10px]"
                style={{
                  background: 'rgba(255,255,255,.15)',
                  border: '1px solid rgba(255,255,255,.3)',
                  color: '#e5e5e5',
                }}
              >
                {advancedKeys.length}
              </span>
            </h3>

            <div className="aw-sp-glass p-4 md:p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {advancedKeys.map((key, idx) => (
                  <div
                    key={key}
                    className="flex flex-col aw-sp-in"
                    style={{ animationDelay: `${0.35 + idx * 0.02}s` }}
                  >
                    <label
                      className="text-[10px] mb-1.5 font-mono uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'rgba(255,255,255,.7)' }}
                    >
                      <Hash size={8} />
                      {key}
                    </label>
                    <input
                      type="text"
                      value={properties[key]}
                      onChange={(e) => handleChange(key, e.target.value)}
                      className="aw-sp-input w-full rounded-lg px-3 py-2 text-sm font-mono"
                      style={{
                        background: 'rgba(0,0,0,.5)',
                        border: '1px solid rgba(255,255,255,.2)',
                        color: '#ffffff',
                        caretColor: '#e5e5e5',
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer info */}
        <div
          className="mt-6 p-3.5 rounded-xl flex items-start gap-2.5 text-xs"
          style={{
            background: 'rgba(251,191,36,.08)',
            border: '1px solid rgba(251,191,36,.25)',
            color: 'rgba(251,191,36,.9)',
          }}
        >
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>
            Changes to <code className="font-mono px-1 py-0.5 rounded" style={{ background: 'rgba(251,191,36,.15)' }}>server.properties</code> require a server restart to take effect. Save changes before restarting.
          </span>
        </div>
      </div>

      {isSaving && <LoadingOverlay message="Saving server properties..." />}
    </div>
  );
}
