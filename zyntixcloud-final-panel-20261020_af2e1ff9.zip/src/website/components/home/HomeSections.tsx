import { Bot, Check, Cpu, Gamepad2, Globe2, HardDrive, MemoryStick, Network, PanelTop, Server, ShieldCheck, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '../ui/Button';
import { SectionHeader } from '../common/SectionHeader';
import { ScrollReveal } from '../common/ScrollReveal';
import vpsImage from '../../assets/dezerx/vps.png';
import dedicatedImage from '../../assets/dezerx/dedicated.webp';
import botBanner from '../../assets/dezerx/banners/node.webp';
import minecraftBanner from '../../assets/dezerx/banners/minecraft-banners.webp';
import featureImage from '../../assets/dezerx/feature-9.webp';
import worldMap from '../../assets/dezerx/World_map_with_points.svg';
import indiaFlag from '../../assets/dezerx/flags/india.png';
import germanyFlag from '../../assets/dezerx/flags/germany.png';
import singaporeFlag from '../../assets/dezerx/flags/singapore.png';
import intelCpu from '../../assets/dezerx/cpu/intel.png';
import ryzenCpu from '../../assets/dezerx/cpu/ryzen9.png';
import dpMinecraft from '../../assets/darkpixel/games/minecraft.png';
import dpPalworld from '../../assets/darkpixel/games/palworld.jpg';
import dpRust from '../../assets/darkpixel/games/rust.jpg';
import dpCounterStrike from '../../assets/darkpixel/games/counter-strike-2.jpg';
import dpValheim from '../../assets/darkpixel/games/valheim.jpg';
import dpFiveM from '../../assets/darkpixel/games/fivem.jpeg';

function FavoriteGames() {
  const games = [
    { name: 'Minecraft', price: 'Starts at ₹40/mo', image: dpMinecraft },
    { name: 'Palworld', price: 'Starts at ₹100/mo', image: dpPalworld },
    { name: 'Rust', price: 'Starts at ₹120/mo', image: dpRust },
    { name: 'Counter-Strike 2', price: 'Starts at ₹170/mo', image: dpCounterStrike },
    { name: 'Valheim', price: 'Starts at ₹70/mo', image: dpValheim },
    { name: 'FiveM', price: 'Starts at ₹250/mo', image: dpFiveM },
  ];

  const stats = [
    ['99.99%', 'Enterprise uptime', 'SLA backed'],
    ['<30s', 'Instant setup', 'Zero wait time'],
    ['2 Gbps', 'DDoS protection', 'Available on selected plans'],
    ['5.7 GHz', 'CPU core clock', 'Ryzen powered options'],
    ['NVMe', 'Fast storage', 'Low latency reads'],
    ['24/7', 'Ticket support', 'Always available'],
  ];

  const cardVariants = {
    hidden: { opacity: 0, y: 38, scale: 0.96 },
    show: { opacity: 1, y: 0, scale: 1 },
  };

  return (
    <ScrollReveal className="favorite-games" delay={0.12}>
      <div className="favorite-games-head">
        <h2>Your favorite games.</h2>
        <p>Choose a game server plan and deploy on ZyntixCloud hardware.</p>
      </div>
      <motion.div
        className="favorite-game-grid"
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: '-90px' }}
        transition={{ staggerChildren: 0.08 }}
      >
        {games.map((game) => (
          <motion.div
            variants={cardVariants}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            key={game.name}
          >
          <Link to="/game-servers" className="favorite-game-card">
            <img src={game.image} alt={game.name} />
            <div>
              <h3>{game.name}</h3>
              <span>{game.price}</span>
            </div>
          </Link>
          </motion.div>
        ))}
      </motion.div>
      <div className="favorite-stats">
        <div className="favorite-stats-track">
          {[...stats, ...stats].map(([value, label, meta], index) => (
            <div key={`${label}-${index}`}>
              <strong>{value}</strong>
              <span>{label}</span>
              <small>{meta}</small>
            </div>
          ))}
        </div>
      </div>
    </ScrollReveal>
  );
}

export function Hero() {
  return (
    <section className="hero">
      <div className="container">
        <ScrollReveal>
          <p className="hero-eyebrow">GAME SERVERS • VPS • VDS • BOT HOSTING</p>
          <h1>Fast, reliable hosting <span>at a fair price.</span></h1>
          <p className="hero-copy">Game servers, VPS, VDS and bot hosting with NVMe storage, DDoS protection and locations across India, Germany and Singapore.</p>
          <div className="hero-actions">
            <Button to="/game-servers" icon>View Plans</Button>
            <Button to="/vps" variant="secondary">Explore Servers</Button>
          </div>
          <p className="hero-note">Instant setup • DDoS protection • 24/7 support</p>
        </ScrollReveal>
        <FavoriteGames />
      </div>
    </section>
  );
}

export function Services() {
  const services = [
    { title: 'Game Server Hosting', desc: 'Run your game server on Intel Xeon or AMD EPYC hardware with NVMe storage, DDoS protection and Pterodactyl access.', price: 'From ₹40/month', ctas: [['Budget Servers', '/game-servers/budget'], ['Premium Servers', '/game-servers/premium']], image: minecraftBanner },
    { title: 'VPS Hosting', desc: 'Virtual servers with root access, NVMe storage and a full management panel.', price: 'From ₹399/month', ctas: [['View VPS Plans', '/vps']], image: vpsImage },
    { title: 'VDS Hosting', desc: 'Dedicated CPU resources for workloads that need more consistent performance.', price: 'From ₹1,200/month', ctas: [['View VDS Plans', '/vds']], image: dedicatedImage },
    { title: 'Bot Hosting', desc: 'Keep your Discord bot or lightweight application online without running it from your own computer.', price: 'From ₹80/month', ctas: [['View Bot Hosting', '/bot-hosting']], image: botBanner },
  ];
  return (
    <section className="section">
      <div className="container">
        <SectionHeader eyebrow="OUR SERVICES" title="Choose the hosting you need." description="From small game servers to powerful VPS and VDS plans, choose the option that fits your requirements and budget." />
        <div className="service-grid">
          {services.map((service, index) => (
            <ScrollReveal className="service-block" delay={index * 0.06} key={service.title}>
              <div>
                <p className="service-price">{service.price}</p>
                <h3>{service.title}</h3>
                <p>{service.desc}</p>
                <div className="service-links">
                  {service.ctas.map(([label, to]) => <Link key={to} to={to}>{label}</Link>)}
                </div>
              </div>
              <div className="service-image">
                <img src={service.image} alt={service.title} />
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Hardware() {
  const items = [
    ['Intel Xeon', 'Used across selected Game Server, VPS and VDS plans.', Cpu, intelCpu],
    ['AMD EPYC', 'Available for premium Game Servers, VPS and VDS.', Cpu],
    ['AMD Ryzen', 'High-frequency VPS options available in India.', Cpu, ryzenCpu],
    ['NVMe SSD', 'Used for storage across listed hosting plans.', HardDrive],
    ['ECC Memory', 'Available on selected VPS, VDS and premium Game Server plans.', MemoryStick],
    ['Network', 'Up to 2 Gbps on selected plans and locations.', Network],
  ];
  return (
    <section className="section hardware-section">
      <div className="container hardware-layout">
        <SectionHeader eyebrow="HARDWARE" title="Hardware behind your server." description="Different plans use different processors and memory configurations. Choose the server that matches your workload." />
        <div className="hardware-map">
          {items.map(([title, text, Icon, image], index) => (
            <div className="hardware-node" key={title as string}>
              {image ? <img src={image as string} alt="" /> : <Icon size={20} />}
              <h3>{title as string}</h3>
              <p>{text as string}</p>
              <span>{String(index + 1).padStart(2, '0')}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Locations() {
  const locations = [
    ['India', 'Game Servers, Intel VPS, AMD VPS, Ryzen VPS, Intel VDS, AMD VDS', indiaFlag],
    ['Germany', 'Intel VPS', germanyFlag],
    ['Singapore', 'AMD EPYC VPS', singaporeFlag],
  ];
  return (
    <section className="section" id="locations">
      <div className="container location-layout">
        <SectionHeader eyebrow="SERVER LOCATIONS" title="Choose a location closer to you." description="ZyntixCloud servers are available across India, Germany and Singapore depending on the service." />
        <div className="map-panel image-map">
          <img src={worldMap} alt="ZyntixCloud server locations map" />
          <div className="location-list">
          {locations.map(([name, services, flag]) => (
            <div className="location-pin" key={name as string}>
              <img src={flag as string} alt="" />
              <strong>{name}</strong>
              <span>{services}</span>
            </div>
          ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function ControlPanel() {
  return (
    <section className="section">
      <div className="container split">
        <SectionHeader title="Manage your server from one place." description="Check resource usage, manage files, access the console, reinstall your system and control important server settings from your panel." />
        <div className="asset-panel">
          <img src={featureImage} alt="Hosting management feature" />
        </div>
      </div>
    </section>
  );
}

export function SetupProcess() {
  const steps = [['01', 'Choose', 'Pick a hosting type and plan.'], ['02', 'Order', 'Choose the available configuration and place your order.'], ['03', 'Setup', 'The server is prepared with the resources included in your plan.'], ['04', 'Manage', 'Access your panel and start using your server.']];
  return (
    <section className="section">
      <div className="container">
        <SectionHeader eyebrow="GET STARTED" title="Pick a plan and get your server." />
        <div className="steps">
          {steps.map(([num, title, text]) => (
            <div className="step" key={num}>
              <span>{num}</span>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Features() {
  const features = [
    ['NVMe Storage', 'Fast storage included across listed hosting services.', HardDrive],
    ['DDoS Protection', 'Protection available on supported ZyntixCloud infrastructure.', ShieldCheck],
    ['Server Control Panel', 'Manage supported services through a simple control panel.', PanelTop],
    ['Root Access', 'Available with VPS and VDS services.', Terminal],
    ['VNC Console', 'Console access on supported VPS and VDS plans.', Terminal],
    ['Pterodactyl Panel', 'Available with Game Server and Bot Hosting services.', Gamepad2],
    ['Multiple Locations', 'Choose from available India, Germany and Singapore services.', Globe2],
    ['Backups', 'Backup management on supported products.', Server],
    ['FTP Access', 'Available for supported game hosting services.', Network],
    ['Discord Ticket Support', 'Join discord.gg/zyntixcloud and create a ticket.', Bot],
  ];
  return (
    <section className="section">
      <div className="container">
        <SectionHeader eyebrow="INCLUDED FEATURES" title="What you get with ZyntixCloud." />
        <div className="feature-grid">
          {features.map(([title, text, Icon]) => (
            <div className="feature" key={title as string}>
              <Icon size={18} />
              <h3>{title as string}</h3>
              <p>{text as string}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
