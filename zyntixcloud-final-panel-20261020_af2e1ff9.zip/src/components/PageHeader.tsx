import React from 'react';
import { Cloud } from 'lucide-react';

// ============================================
// ZyntixCloud Panel — Page Header
// ZyntixCloud panel header
// ============================================

interface PageHeaderProps {
    title: string;
    subtitle?: string;
    actions?: React.ReactNode;
}

export default function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
    return (
        <header className="max-w-7xl mx-auto px-5 md:px-8 pt-16 md:pt-20 pb-16">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
                <div className="reveal active">
                    {/* Breadcrumb line */}
                    <p 
                        className="font-mono text-[11px] md:text-xs tracking-[0.25em] flex items-center gap-2 mb-6 uppercase"
                        style={{ color: 'rgba(255,255,255,.45)' }}
                    >
                        <Cloud className="w-3.5 h-3.5" />
                        <span style={{ color: 'rgba(255,255,255,.32)' }}>//</span>
                        <span style={{ color: '#ffffff' }}>LIXCLOUD.CORE</span>
                        <span style={{ color: 'rgba(255,255,255,.32)' }}>-</span>
                        <span>{subtitle || title}</span>
                    </p>
                    
                    {/* Title with subtle glow */}
                    <h1 
                        className="font-sans font-semibold leading-[0.92] tracking-tight text-4xl md:text-6xl text-white"
                        style={{
                            textShadow: '0 0 28px rgba(255,255,255,.08)',
                        }}
                    >
                        {title}
                    </h1>
                    
                    {/* Decorative underline */}
                    <div 
                        className="mt-6 h-px w-24"
                        style={{
                            background: 'linear-gradient(90deg, rgba(255,255,255,.8), rgba(255,255,255,.16), transparent)',
                        }}
                    />
                </div>
                
                {actions && (
                    <div 
                        className="flex items-center gap-3 reveal active" 
                        style={{ transitionDelay: '100ms' }}
                    >
                        {actions}
                    </div>
                )}
            </div>
        </header>
    );
}
