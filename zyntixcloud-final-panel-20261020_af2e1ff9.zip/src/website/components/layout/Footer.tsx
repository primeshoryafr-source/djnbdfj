import { Link } from 'react-router-dom';
import logo from '../../assets/zyntixcloud-logo.png';

export function Footer() {
  const groups = [
    { title: 'Products', links: [['Game Servers', '/game-servers'], ['VPS', '/vps'], ['VDS', '/vds'], ['Bot Hosting', '/bot-hosting']] },
    { title: 'Locations', links: [['India', '/#locations'], ['Germany', '/#locations'], ['Singapore', '/#locations']] },
    { title: 'Resources', links: [['Support', '/support'], ['Server Status', '/support'], ['Documentation', '/support'], ['Knowledge Base', '/support']] },
    { title: 'Company', links: [['About', '/about'], ['Contact', '/support'], ['Privacy', '/about'], ['Terms', '/about']] },
  ];
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <img src={logo} alt="ZyntixCloud" />
          <p>Game servers, VPS, VDS and bot hosting.</p>
        </div>
        {groups.map((group) => (
          <div key={group.title}>
            <h3>{group.title}</h3>
            {group.links.map(([label, to]) => (
              <Link to={to} key={label}>
                {label}
              </Link>
            ))}
          </div>
        ))}
      </div>
      <div className="container footer-bottom">
        <span>© 2026 ZyntixCloud. All rights reserved.</span>
        <span>All prices are exclusive of applicable taxes.</span>
      </div>
    </footer>
  );
}
