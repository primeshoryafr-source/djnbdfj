/// <reference types="vite/client" />

