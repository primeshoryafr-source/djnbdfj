import axios from "axios";

export type ProductCategory = "game-servers" | "bot-hosting" | "vps" | "vds";

export interface CatalogPlan {
  id: string;
  name: string;
  pricePaise: number;
  currency: "INR";
  period: "month";
  memoryLabel: string;
  cpuLabel: string;
  diskLabel: string;
  location: string;
  processor: string;
  popular?: boolean;
}

export interface CatalogProduct {
  id: string;
  slug: string;
  category: ProductCategory;
  kind: "game" | "bot" | "vps" | "vds";
  name: string;
  subtitle: string;
  location: string;
  processor: string;
  available: boolean;
  unavailableReason?: string;
  allowedSoftware: string[];
  defaultSoftware?: string;
  defaultVersion?: string;
  plans: CatalogPlan[];
}

export interface BillingOrder {
  id: string;
  status: string;
  subtotalPaise: number;
  taxPaise: number;
  totalPaise: number;
  currency: "INR";
  config: Record<string, string>;
  serviceId?: string;
  createdAt: string;
  snapshot: {
    product: {
      id: string;
      name: string;
      kind: string;
      category: ProductCategory;
      location: string;
      processor: string;
    };
    plan: CatalogPlan;
  };
}

export const formatMoney = (paise: number) =>
  `₹${Math.round(paise / 100).toLocaleString("en-IN")}`;

export async function getCatalog() {
  const res = await axios.get<{ products: CatalogProduct[] }>("/api/billing/catalog");
  return res.data.products;
}

export async function createOrder(productId: string, planId: string, config: Record<string, string>) {
  const res = await axios.post<{ order: BillingOrder }>("/api/billing/orders", { productId, planId, config });
  return res.data.order;
}

export async function listOrders() {
  const res = await axios.get<{ orders: BillingOrder[] }>("/api/billing/orders");
  return res.data.orders;
}

export async function getOrder(orderId: string) {
  const res = await axios.get<{ order: BillingOrder; provisioning: any }>(`/api/billing/orders/${orderId}`);
  return res.data;
}

export async function createRazorpayCheckout(orderId: string) {
  const res = await axios.post(`/api/billing/orders/${orderId}/razorpay`);
  return res.data;
}

