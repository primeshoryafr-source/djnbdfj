import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Cpu, MemoryStick as MemoryIcon, HardDrive,
  Play, Square, RotateCw, Wifi, Clock, ArrowDown, ArrowUp, ChevronRight, Power,
  Hexagon, Copy, Check
} from "lucide-react";
import { io, Socket } from "socket.io-client";
import { useAuth } from "../context/AuthContext";
import axios from "axios";
import { AreaChart, Area, ResponsiveContainer, YAxis } from "recharts";

/* ═══════════════════════════════════════════════════════
   ZyntixCloud Panel — Server Console
   Simple neutral theme + Address Auto-Copy
═══════════════════════════════════════════════════════ */

interface ServerStats {
  cpu: number;
  ram: number;
  disk: number;
  limitRam: number;
  limitCpu: number;
  limitDisk: number;
  netIn?: number;
  netOut?: number;
  startedAt?: string | null;
  status?: string;
}

interface ServerLike {
  id?: string;
  name?: string;
  port?: number | string;
  ipAlias?: string;
  ram?: number;
  cpu?: number;
  disk?: number;
  status?: string;
  startedAt?: string | null;
  [key: string]: unknown;
}

interface ServerConsoleProps {
  serverId: string;
  server?: ServerLike;
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  dim?: React.ReactNode;
  onClick?: () => void;
  copied?: boolean;
}

interface ChartCardProps {
  title: string;
  data: any[];
  dataKey: string;
  dataKey2?: string;
  max?: number;
  icons?: React.ReactNode;
}

type ServerAction = "start" | "stop" | "restart" | "kill";

const STATS_POLL_MS = 3000;
const SPARK_CAP = 30;

function stripAnsi(str: string) {
  return str.replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/g, "");
}

function formatSize(mb: number) {
  if (mb < 1024) return `${mb.toFixed(2)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
}

function formatRate(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB/s`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB/s`;
}

/* ═══════════════════════════════════════════════════════
   STAT CARD — with optional copy support
═══════════════════════════════════════════════════════ */
const StatCard = ({ icon, label, value, dim, onClick, copied }: StatCardProps) => (
  <div
    onClick={onClick}
    className={`relative rounded-xl p-3 min-h-[76px] overflow-hidden flex items-center gap-3 transition-colors duration-200 group ${
      onClick ? "cursor-pointer" : ""
    }`}
    style={{
      background: copied ? "rgba(255,255,255,.075)" : "rgba(255,255,255,.045)",
      border: copied ? "1px solid rgba(255,255,255,.28)" : "1px solid rgba(255,255,255,.11)",
      boxShadow: "none",
    }}
  >
    <div
      className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.035] transition-colors duration-200 pointer-events-none"
      style={{
        color: copied ? "rgba(255,255,255,.74)" : "rgba(255,255,255,.28)",
      }}
    >
      <div className="scale-[0.72] group-hover:text-white transition-colors duration-200">
        {React.isValidElement(icon)
          ? React.cloneElement(icon as React.ReactElement<any>, { style: { width: 34, height: 34 } })
          : icon}
      </div>
    </div>

    <div className="relative z-10 min-w-0 flex-1">
      <div
        className="text-xs mb-1 flex min-w-0 items-center gap-2 font-semibold"
        style={{ color: copied ? "rgba(255,255,255,.96)" : "rgba(255,255,255,.66)" }}
      >
        <span className="truncate">{label}</span>
        {copied && (
          <span className="shrink-0 text-[10px] font-mono uppercase tracking-widest text-white flex items-center gap-1">
            <Check size={10} strokeWidth={3} /> Copied
          </span>
        )}
      </div>
      <div className="min-w-0 text-[15px] font-semibold text-white whitespace-nowrap overflow-hidden text-ellipsis">
        {value} {dim && <span className="text-zinc-500 font-normal text-xs">{dim}</span>}
      </div>
    </div>

    {/* Copy hint (only when clickable + not copied) */}
    {onClick && !copied && (
      <div className="absolute bottom-2.5 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center gap-1 text-[9px] font-mono uppercase tracking-widest text-white/60">
        <Copy size={9} /> Copy
      </div>
    )}

    {/* Hover border */}
    <div
      className="absolute inset-0 rounded-[12px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none"
      style={{
        boxShadow: "0 0 0 1px rgba(255,255,255,.22)",
      }}
    />
  </div>
);

/* ═══════════════════════════════════════════════════════
   CHART CARD
═══════════════════════════════════════════════════════ */
const ChartCard = ({ title, data, dataKey, dataKey2, max, icons }: ChartCardProps) => {
  const chartData = useMemo(() => {
    const d = [...data];
    while (d.length < 30) {
      d.unshift({ [dataKey]: 0, ...(dataKey2 ? { [dataKey2]: 0 } : {}) });
    }
    return d;
  }, [data, dataKey, dataKey2]);

  return (
    <div
      className="rounded-[12px] p-[18px_20px] relative overflow-hidden"
      style={{
        background: "rgba(255,255,255,.035)",
        border: "1px solid rgba(255,255,255,.10)",
      }}
    >
      <div className="flex justify-between items-center mb-[12px] relative z-10">
        <div className="text-[15px] font-[700] text-white">{title}</div>
        {icons && <div className="flex gap-[9px] items-center">{icons}</div>}
      </div>
      <div className="relative h-[190px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 0, left: 0, right: 0, bottom: 0 }}>
            <defs>
              <linearGradient id={`fill${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgba(255,255,255,0.45)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.02)" />
              </linearGradient>
              {dataKey2 && (
                <linearGradient id={`fill${dataKey2}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgba(255,255,255,0.45)" />
                  <stop offset="100%" stopColor="rgba(255,255,255,0.02)" />
                </linearGradient>
              )}
            </defs>
            <YAxis domain={[0, max || "auto"]} hide />
            <Area
              type="monotone"
              dataKey={dataKey}
              stroke="#ffffff"
              strokeWidth={2}
              fillOpacity={1}
              fill={`url(#fill${dataKey})`}
              isAnimationActive={false}
            />
            {dataKey2 && (
              <Area
                type="monotone"
                dataKey={dataKey2}
                stroke="#e5e5e5"
                strokeWidth={2}
                fillOpacity={1}
                fill={`url(#fill${dataKey2})`}
                isAnimationActive={false}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const ChartPlaceholder = ({ title }: { title: string }) => (
  <div
    className="rounded-[12px] p-[18px_20px] relative overflow-hidden"
    style={{
      background: "rgba(255,255,255,.035)",
      border: "1px solid rgba(255,255,255,.10)",
    }}
  >
    <div className="text-[15px] font-[700] text-white mb-[12px]">{title}</div>
    <div className="h-[190px] flex items-center justify-center text-zinc-600 text-[13px] font-mono">
      No data — server offline
    </div>
  </div>
);

/* ═══════════════════════════════════════════════════════
   MAIN COMPONENT
═══════════════════════════════════════════════════════ */
export default function ServerConsole({ serverId, server }: ServerConsoleProps) {
  const { token } = useAuth();
  const [logs, setLogs] = useState<string[]>([]);
  const [command, setCommand] = useState("");

  const [stats, setStats] = useState<ServerStats>({
    cpu: 0,
    ram: 0,
    disk: 0,
    limitRam: server?.ram || 1024,
    limitCpu: server?.cpu || 100,
    limitDisk: server?.disk || 10,
    status: server?.status || "offline",
  });
  const [netRates, setNetRates] = useState({ in: 0, out: 0 });

  const [cpuHist, setCpuHist] = useState<any[]>([]);
  const [ramHist, setRamHist] = useState<any[]>([]);
  const [netHist, setNetHist] = useState<any[]>([]);

  const [atBottom, setAtBottom] = useState(true);
  const [uptime, setUptime] = useState(0);
  const [copied, setCopied] = useState(false);

  const sockRef = useRef<Socket | null>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const prevNetRef = useRef({ netIn: 0, netOut: 0, timestamp: 0 });
  const isVisible = useRef(true);
  const isTouchingRef = useRef(false);
  const scrollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastRawLogsRef = useRef<string>("");
  const prevStartedAtRef = useRef<string | null | undefined>(server?.startedAt);
  const copyTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const statusLogRef = useRef<string | undefined>(server?.status);

  useEffect(() => {
    if (server?.status) {
      setStats((p) => (p.status === server.status ? p : { ...p, status: server.status }));
    }
  }, [server?.status]);

  useEffect(() => {
    const nextStatus = stats.status || "unknown";
    if (statusLogRef.current === nextStatus) return;
    statusLogRef.current = nextStatus;

    const readable =
      nextStatus === "online" || nextStatus === "running"
        ? "online"
        : nextStatus === "offline"
        ? "offline"
        : nextStatus;

    setLogs((prev) => {
      const line = `[System] Server status: ${readable}`;
      if (prev[prev.length - 1] === line) return prev;
      return [...prev, line].slice(-500);
    });
  }, [stats.status]);

  useEffect(() => {
    if (stats.startedAt && prevStartedAtRef.current && stats.startedAt !== prevStartedAtRef.current) {
      setLogs([]);
      lastRawLogsRef.current = "";
    }
    prevStartedAtRef.current = stats.startedAt;
  }, [stats.startedAt]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      isVisible.current = !document.hidden;
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  useEffect(() => {
    let alive = true;

    const syncLogs = async () => {
      if (!alive || !isVisible.current) return;
      try {
        const { data } = await axios.get(`/api/servers/${serverId}/logs`);
        const raw: string = data?.logs || "";
        if (!raw.trim()) return;

        if (raw === lastRawLogsRef.current) return;
        lastRawLogsRef.current = raw;

        const fetchedLines = raw.split(/\r?\n/).filter((l: string) => l.trim());
        if (fetchedLines.length === 0) return;

        setLogs((prev) => {
          if (prev.length === 0) return fetchedLines.slice(-500);

          const prevServerLines = prev.filter(
            (l) => !l.startsWith("> ") && !l.startsWith("[System")
          );
          if (prevServerLines.length === 0) return fetchedLines.slice(-500);

          let matchIdx = -1;
          const maxWindow = Math.min(prevServerLines.length, 8);

          for (let w = maxWindow; w >= 1; w--) {
            const needle = prevServerLines.slice(-w);
            const lastNeedle = needle[needle.length - 1];
            let candidateIdx = fetchedLines.lastIndexOf(lastNeedle);

            while (candidateIdx !== -1) {
              let matches = true;
              for (let i = 0; i < needle.length; i++) {
                const fIdx = candidateIdx - (needle.length - 1) + i;
                if (fIdx < 0 || fetchedLines[fIdx] !== needle[i]) {
                  matches = false;
                  break;
                }
              }
              if (matches) {
                matchIdx = candidateIdx;
                break;
              }
              candidateIdx = fetchedLines.lastIndexOf(lastNeedle, candidateIdx - 1);
            }
            if (matchIdx !== -1) break;
          }

          if (matchIdx !== -1) {
            const newLines = fetchedLines.slice(matchIdx + 1);
            if (newLines.length === 0) return prev;
            const next = [...prev, ...newLines];
            return next.length > 500 ? next.slice(-500) : next;
          } else {
            return fetchedLines.slice(-500);
          }
        });
      } catch {}
    };

    syncLogs();
    const iv = setInterval(syncLogs, 2500);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [serverId]);

  useEffect(() => {
    if (!token || !serverId) return;
    const socket: Socket = io({
      auth: { token },
      transports: ["websocket", "polling"],
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });
    sockRef.current = socket;
    socket.on("connect", () => {
      socket.emit("joinServer", serverId);
    });

    socket.on("clear_logs", () => {
      setLogs([]);
      lastRawLogsRef.current = "";
    });

    socket.on("log", (data: string) => {
      if (typeof data !== "string") return;
      const lines = data.split(/\r?\n/).filter((l) => l.trim());
      if (lines.length === 0) return;
      setLogs((prev) => {
        const next = [...prev, ...lines];
        return next.length > 500 ? next.slice(next.length - 500) : next;
      });
    });
    return () => {
      socket.emit("leaveServer", serverId);
      socket.removeAllListeners();
      socket.disconnect();
      sockRef.current = null;
    };
  }, [serverId, token]);

  useEffect(() => {
    let alive = true;
    let failCount = 0;

    const pull = async () => {
      if (!alive) return;
      if (!isVisible.current) return;

      try {
        const { data } = await axios.get<ServerStats>(`/api/servers/${serverId}/stats`);
        if (alive && data) {
          failCount = 0;
          setStats((p) => ({
            ...p,
            cpu: data.cpu ?? p.cpu,
            ram: data.ram ?? p.ram,
            disk: data.disk ?? p.disk,
            limitRam: data.limitRam ?? p.limitRam,
            limitCpu: data.limitCpu ?? p.limitCpu,
            limitDisk: data.limitDisk ?? p.limitDisk,
            startedAt: data.startedAt ?? p.startedAt,
            status: data.status ?? p.status,
          }));

          setCpuHist((h) => [...h, { cpu: data.cpu ?? 0 }].slice(-SPARK_CAP));
          setRamHist((h) => [...h, { ram: data.ram ?? 0 }].slice(-SPARK_CAP));

          const now = Date.now();
          if (
            prevNetRef.current.timestamp > 0 &&
            data.netIn !== undefined &&
            data.netOut !== undefined
          ) {
            const elapsedSeconds = (now - prevNetRef.current.timestamp) / 1000;
            if (
              data.netIn >= prevNetRef.current.netIn &&
              data.netOut >= prevNetRef.current.netOut
            ) {
              const inRate = Math.max(0, data.netIn - prevNetRef.current.netIn) / elapsedSeconds;
              const outRate = Math.max(0, data.netOut - prevNetRef.current.netOut) / elapsedSeconds;
              setNetRates({ in: inRate, out: outRate });
              setNetHist((h) =>
                [...h, { netIn: inRate / 1024, netOut: outRate / 1024 }].slice(-SPARK_CAP)
              );
            } else {
              setNetRates({ in: 0, out: 0 });
              setNetHist((h) => [...h, { netIn: 0, netOut: 0 }].slice(-SPARK_CAP));
            }
          }
          prevNetRef.current = {
            netIn: data.netIn || 0,
            netOut: data.netOut || 0,
            timestamp: now,
          };
        }
      } catch {
        failCount++;
        if (failCount > 3) {
          setStats((p) => ({ ...p, status: "offline", cpu: 0, ram: 0, disk: 0 }));
          setNetRates({ in: 0, out: 0 });
          setCpuHist((h) => [...h, { cpu: 0 }].slice(-SPARK_CAP));
          setRamHist((h) => [...h, { ram: 0 }].slice(-SPARK_CAP));
          setNetHist((h) => [...h, { netIn: 0, netOut: 0 }].slice(-SPARK_CAP));
        }
      }
    };

    pull();
    const iv = setInterval(pull, STATS_POLL_MS);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [serverId]);

  useEffect(() => {
    const iv = setInterval(() => {
      if (stats.status === "online" || stats.status === "running") {
        if (stats.startedAt) {
          const start = new Date(stats.startedAt).getTime();
          if (start > 0) {
            setUptime(Math.max(0, Math.floor((Date.now() - start) / 1000)));
            return;
          }
        }
      }
      setUptime(0);
    }, 1000);
    return () => clearInterval(iv);
  }, [stats.startedAt, stats.status]);

  let uptimeStr = "—";
  if (stats.status === "online" || stats.status === "running") {
    const d = Math.floor(uptime / 86400);
    const h = Math.floor((uptime % 86400) / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = uptime % 60;
    if (d > 0) uptimeStr = `${d}d ${h}h ${m}m`;
    else if (h > 0) uptimeStr = `${h}h ${m}m ${s}s`;
    else uptimeStr = `${m}m ${s}s`;
  }

  useEffect(() => {
    if (atBottom && !isTouchingRef.current && bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [logs, atBottom]);

  const onScroll = useCallback(() => {
    const el = bodyRef.current;
    if (!el) return;
    const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
    const near = dist < 35;
    setAtBottom((prev) => (prev === near ? prev : near));
  }, []);

  const scrollToBottom = useCallback(() => {
    setAtBottom(true);
    if (bodyRef.current) {
      bodyRef.current.scrollTo({
        top: bodyRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, []);

  const send = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      const cmd = command.trim();
      if (!cmd) return;
      setCommand("");
      setLogs((p) => [...p, `> ${cmd}`]);
      try {
        await axios.post(`/api/servers/${serverId}/command`, { command: cmd });
      } catch (err: any) {
        setLogs((p) => [...p, `[System] Failed to send: ${err?.message}`]);
      }
    },
    [command, serverId]
  );

  const executeAction = async (action: ServerAction) => {
    if (!server) return;
    if (action === "start" || action === "restart") {
      setLogs([]);
      lastRawLogsRef.current = "";
    }
    try {
      const pendingStatus =
        action === "start"
          ? "starting"
          : action === "stop" || action === "kill"
          ? "stopping"
          : "restarting";
      setStats((p) => ({ ...p, status: pendingStatus }));
      setLogs((p) => [...p, `[System] Sending ${action} signal...`]);
      await axios.post(`/api/servers/${server.id}/${action}`);
      const actionName =
        action === "start"
          ? "started"
          : action === "stop"
          ? "stopped"
          : action === "kill"
          ? "forcefully killed"
          : "restarted";
      setLogs((p) => [...p, `[System] Server ${actionName} request accepted. Waiting for status update...`]);
    } catch (error: any) {
      setLogs((p) => [
        ...p,
        `[System Error] Failed to ${action} server. Reason: ${
          error.response?.data?.error || error.message
        }`,
      ]);
      if (server?.status) {
        setStats((p) => ({ ...p, status: server.status }));
      }
    }
  };

  const renderLog = (line: string, i: number) => {
    const upperLine = line.toUpperCase();
    const isError =
      upperLine.includes("ERROR") ||
      upperLine.includes("FATAL") ||
      upperLine.includes("EXCEPTION") ||
      upperLine.includes("SEVERE");
    const isWarn =
      upperLine.includes("WARN") ||
      upperLine.includes("RESTARTING") ||
      upperLine.includes("STOPPING") ||
      upperLine.includes("PLUGIN") ||
      upperLine.includes("LOADING");

    let textColor = "text-zinc-100";
    if (isError) textColor = "text-red-300";
    else if (isWarn) textColor = "text-zinc-300";

    return (
      <div
        key={i}
        className={`mb-px break-all sm:break-words [overflow-wrap:anywhere] min-w-0 ${textColor}`}
        style={{ animation: "aw-log-in .25s ease both" }}
      >
        {stripAnsi(line)}
      </div>
    );
  };

  const isOnline = stats.status === "online" || stats.status === "running";
  const isOffline = stats.status === "offline";
  const statusDotClass = isOnline
    ? "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,.75)]"
    : isOffline
    ? "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,.55)]"
    : "bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,.55)]";
  const statusTextClass = isOnline ? "text-emerald-300" : isOffline ? "text-red-300" : "text-amber-300";
  const statusLabel =
    stats.status === "online" || stats.status === "running"
      ? "Online"
      : stats.status === "offline"
      ? "Offline"
      : stats.status
      ? stats.status.charAt(0).toUpperCase() + stats.status.slice(1)
      : "Unknown";

  /* ═══ Address computation + copy handler ═══ */
  const addressValue = useMemo(() => {
    if (!server) return "—";
    const alias = server.ipAlias?.trim();
    if (alias) {
      return alias.includes(":") ? alias : `${alias}:${server.port || "25565"}`;
    }
    return `localhost:${server.port || 25565}`;
  }, [server]);

  const handleCopyAddress = useCallback(() => {
    if (!server || addressValue === "—") return;
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(addressValue).catch(() => {});
    } else {
      const el = document.createElement("textarea");
      el.value = addressValue;
      el.style.position = "fixed";
      el.style.opacity = "0";
      document.body.appendChild(el);
      el.select();
      try {
        document.execCommand("copy");
      } catch {}
      document.body.removeChild(el);
    }
    setCopied(true);
    if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    copyTimeoutRef.current = setTimeout(() => setCopied(false), 1800);
  }, [server, addressValue]);

  useEffect(() => {
    return () => {
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    };
  }, []);

  return (
    <div
      className="flex-1 h-full overflow-y-auto overflow-x-hidden custom-scrollbar overscroll-y-contain relative"
      style={{ WebkitOverflowScrolling: "touch", touchAction: "pan-y" }}
    >
      <div className="w-full max-w-[1560px] mx-auto px-[14px] sm:px-[22px] py-[16px] sm:py-[24px] pb-[34px] sm:pb-[42px] relative z-10">
        <style
          dangerouslySetInnerHTML={{
            __html: `
              @keyframes aw-rise { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: none; } }
              @keyframes aw-log-in { from { opacity: 0; transform: translateX(-4px); } to { opacity: 1; transform: none; } }
              .aw-log-scroll::-webkit-scrollbar { width: 8px; }
              .aw-log-scroll::-webkit-scrollbar-track { background: transparent; }
              .aw-log-scroll::-webkit-scrollbar-thumb {
                background: rgba(255,255,255,.22);
                border-radius: 4px;
              }
              .aw-log-scroll::-webkit-scrollbar-thumb:hover {
                background: rgba(255,255,255,.34);
              }
              .aw-copy-pop { }
            `,
          }}
        />

        {/* TOP BAR */}
        <div
          className="flex flex-wrap sm:flex-nowrap justify-between items-center mb-4 sm:mb-5 gap-3"
          style={{ animation: "aw-rise .5s ease both" }}
        >
          <div className="flex items-center gap-[12px] min-w-0">
            <div className={`w-[11px] h-[11px] rounded-full shrink-0 ${statusDotClass}`} />
            <h1 className="text-xl sm:text-[22px] font-semibold text-white truncate tracking-tight">
              {server?.name || "Server"}
            </h1>
            <span
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[10px] font-mono uppercase tracking-widest"
              style={{
                background: "rgba(255,255,255,.1)",
                border: "1px solid rgba(255,255,255,.3)",
                color: "#e5e5e5",
              }}
            >
              <Hexagon size={10} />
              LIXCLOUD v1.80
            </span>
          </div>
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              onClick={() => executeAction("start")}
              className="flex-1 sm:flex-initial min-w-[54px] sm:min-w-[64px] h-10 sm:h-11 rounded-xl flex items-center justify-center text-white cursor-pointer transition-colors hover:border-white/25 hover:bg-white/10 touch-manipulation"
              style={{
                background: "rgba(255,255,255,.055)",
                border: "1px solid rgba(255,255,255,.12)",
                boxShadow: "none",
              }}
              title="Start"
            >
              <Play className="w-5 h-5 fill-current text-white" />
            </button>
            <button
              onClick={() => executeAction("restart")}
              className="flex-1 sm:flex-initial min-w-[54px] sm:min-w-[64px] h-10 sm:h-11 border border-white/80 rounded-xl flex items-center justify-center text-black cursor-pointer transition-colors hover:bg-zinc-100 touch-manipulation"
              style={{
                background: "#ffffff",
                boxShadow: "none",
              }}
              title="Restart"
            >
              <RotateCw className="w-5 h-5" />
            </button>
            <button
              onClick={() => executeAction("stop")}
              className="flex-1 sm:flex-initial min-w-[54px] sm:min-w-[64px] h-10 sm:h-11 rounded-xl flex items-center justify-center text-white cursor-pointer transition-colors hover:border-white/25 hover:bg-white/10 touch-manipulation"
              style={{
                background: "rgba(255,255,255,.055)",
                border: "1px solid rgba(255,255,255,.12)",
                boxShadow: "none",
              }}
              title="Graceful Stop"
            >
              <Square className="w-5 h-5 fill-current" />
            </button>
            <button
              onClick={() => executeAction("kill")}
              className="flex-1 sm:flex-initial min-w-[54px] sm:min-w-[64px] h-10 sm:h-11 rounded-xl flex items-center justify-center text-white cursor-pointer transition-colors hover:border-white/25 hover:bg-white/10 touch-manipulation"
              style={{
                background: "rgba(255,255,255,.055)",
                border: "1px solid rgba(255,255,255,.12)",
                boxShadow: "none",
              }}
              title="Force Kill (SIGKILL)"
            >
              <Power className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* CONSOLE + STATS */}
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_300px] gap-5 mb-5">
          {/* Console */}
          <div
            className="relative rounded-xl overflow-hidden flex flex-col h-[340px] sm:h-[430px] xl:h-[540px]"
            style={{
              background: "#06070a",
              border: "1px solid rgba(255,255,255,.12)",
              boxShadow: "none",
              animation: "aw-rise .5s ease .08s both",
            }}
          >
            <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-2.5 border-b border-white/10 bg-white/[0.025]">
              <div className="flex items-center gap-2 min-w-0">
                <span className={`w-2 h-2 rounded-full shrink-0 ${statusDotClass}`} />
                <span className={`text-xs font-semibold truncate ${statusTextClass}`}>
                  Server is {statusLabel}
                </span>
              </div>
              <span className="text-[11px] text-white/50 font-mono shrink-0">
                {isOnline ? uptimeStr : "No live process"}
              </span>
            </div>
            <div
              ref={bodyRef}
              onScroll={onScroll}
              onTouchStart={() => {
                isTouchingRef.current = true;
              }}
              onTouchEnd={() => {
                isTouchingRef.current = false;
                if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
                scrollTimeoutRef.current = setTimeout(onScroll, 120);
              }}
              className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-[18px_20px] aw-log-scroll font-mono text-[12px] sm:text-[12.5px] leading-[1.66] text-[#d7d7d7] overscroll-contain select-text"
              style={{
                WebkitOverflowScrolling: "touch",
                touchAction: "pan-y",
                background: "#050609",
              }}
            >
              {logs.map((log, i) => renderLog(log, i))}
            </div>

            {!atBottom && (
              <button
                type="button"
                onClick={scrollToBottom}
                className="absolute bottom-[60px] right-3 sm:right-4 z-20 px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-medium flex items-center gap-1.5 transition-colors touch-manipulation cursor-pointer select-none"
                style={{
                  background: "#18181b",
                  border: "1px solid rgba(255,255,255,.18)",
                  color: "#ffffff",
                }}
                title="Scroll to bottom"
              >
                <ArrowDown
                  className="w-3.5 h-3.5 text-white"
                />
                <span>Scroll to bottom</span>
              </button>
            )}

            <form
              onSubmit={send}
              className="flex items-center gap-3 p-3 sm:p-4 shrink-0"
              style={{
                background: "#090a0d",
                borderTop: "1px solid rgba(255,255,255,.10)",
              }}
            >
              <ChevronRight className="w-4 h-4 shrink-0" style={{ color: "#ffffff" }} />
              <input
                ref={inputRef}
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                type="text"
                placeholder="Type a command..."
                className="flex-1 bg-transparent border-0 outline-none text-white font-mono text-base sm:text-[13px] min-w-0 placeholder:text-zinc-600"
                autoComplete="off"
              />
              {isOnline && command && (
                <button
                  type="submit"
                  className="shrink-0 px-3 py-1.5 rounded-md text-[10px] font-bold tracking-wider transition-colors"
                  style={{
                  background: "#ffffff",
                  color: "#05070b",
                    boxShadow: "none",
                  }}
                >
                  SEND
                </button>
              )}
            </form>
          </div>

          {/* STATS */}
          <div
            className="grid grid-cols-1 sm:grid-cols-2 xl:flex xl:flex-col gap-3"
            style={{ animation: "aw-rise .5s ease .16s both" }}
          >
            <div className={copied ? "aw-copy-pop" : ""}>
              <StatCard
                icon={<Wifi style={{ width: 48, height: 48 }} />}
                label="Address"
                value={addressValue}
                onClick={handleCopyAddress}
                copied={copied}
              />
            </div>
            <StatCard
              icon={<Clock style={{ width: 48, height: 48 }} />}
              label="Uptime"
              value={uptimeStr}
            />
            <StatCard
              icon={<Cpu style={{ width: 48, height: 48 }} />}
              label="CPU Load"
              value={isOnline ? `${stats.cpu.toFixed(2)}%` : "—"}
              dim={isOnline ? `/ ${stats.limitCpu}%` : ""}
            />
            <StatCard
              icon={<MemoryIcon style={{ width: 48, height: 48 }} />}
              label="Memory"
              value={isOnline ? formatSize(stats.ram) : "—"}
              dim={isOnline ? `/ ${formatSize(stats.limitRam)}` : ""}
            />
            <StatCard
              icon={<HardDrive style={{ width: 48, height: 48 }} />}
              label="Disk"
              value={isOnline ? formatSize(stats.disk) : "0 MB"}
              dim={`/ ${formatSize(stats.limitDisk)}`}
            />
            <StatCard
              icon={<ArrowDown style={{ width: 48, height: 48 }} />}
              label="Network (Inbound)"
              value={isOnline ? `↓ ${formatRate(netRates.in)}` : "—"}
            />
            <StatCard
              icon={<ArrowUp style={{ width: 48, height: 48 }} />}
              label="Network (Outbound)"
              value={isOnline ? `↑ ${formatRate(netRates.out)}` : "—"}
            />
          </div>
        </div>

        {/* CHARTS */}
        <div
          className="grid grid-cols-1 lg:grid-cols-3 gap-5"
          style={{ animation: "aw-rise .5s ease .24s both" }}
        >
          {isOnline ? (
            <>
              <ChartCard title="CPU Load (%)" data={cpuHist} dataKey="cpu" max={stats.limitCpu} />
              <ChartCard title="Memory (MB)" data={ramHist} dataKey="ram" max={stats.limitRam} />
              <ChartCard
                title="Network (KB/s)"
                data={netHist}
                dataKey="netIn"
                dataKey2="netOut"
                max={100}
                icons={
                  <>
                    <ArrowDown className="w-3 h-3" style={{ color: "#ffffff" }} />
                    <ArrowUp className="w-3 h-3" style={{ color: "#e5e5e5" }} />
                  </>
                }
              />
            </>
          ) : (
            <>
              <ChartPlaceholder title="CPU Load (%)" />
              <ChartPlaceholder title="Memory (MB)" />
              <ChartPlaceholder title="Network (KB/s)" />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
