import React, { useEffect, useState } from "react";
import { Users, Shield, Gavel, UserMinus, ShieldAlert, Check, RefreshCw, UserCheck, Activity } from "lucide-react";
import { io, Socket } from "socket.io-client";
import { useAuth } from "../context/AuthContext";
import axios from "axios";

// ============================================
// ZyntixCloud Panel — Player Manager
// Simple neutral theme
// ============================================

interface Player {
  name: string;
  joinedAt?: string;
  isOp?: boolean;
}

export default function PlayerManager({ serverId, players: propPlayers }: { serverId: string; players?: Player[] }) {
  const [players, setPlayers] = useState<Player[]>(propPlayers || []);
  const [loadingAction, setLoadingAction] = useState<{ player: string; action: string } | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [customPlayerInput, setCustomPlayerInput] = useState("");
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const { token } = useAuth();

  useEffect(() => {
    if (!token || !serverId) return;

    const socket: Socket = io({
      auth: { token },
      reconnectionAttempts: 5,
    });

    socket.on("connect", () => {
      socket.emit("joinServer", serverId);
      axios.post(`/api/servers/${serverId}/command`, { command: "list" }).catch(() => {});
    });

    socket.on("log", (data: string) => {
      if (typeof data !== "string") return;
      const clean = data.replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/g, "");

      const joinMatch = clean.match(/:\s+([a-zA-Z0-9_]{3,16})\s+joined the game/i);
      if (joinMatch) {
        setPlayers((prev) => {
          if (!prev.some((p) => p.name === joinMatch[1])) {
            return [...prev, { name: joinMatch[1], joinedAt: new Date().toLocaleTimeString() }];
          }
          return prev;
        });
      }

      const leaveMatch = clean.match(/:\s+([a-zA-Z0-9_]{3,16})\s+left the game/i);
      if (leaveMatch) {
        setPlayers((prev) => prev.filter((p) => p.name !== leaveMatch[1]));
      }

      const listMatch = clean.match(/(?:players online|online players):\s*(.*)/i);
      if (listMatch) {
        const names = listMatch[1].trim();
        if (names) {
          const parsed = names
            .split(",")
            .map((n) => n.trim())
            .filter(Boolean)
            .map((name) => ({ name }));
          setPlayers(parsed);
        } else {
          setPlayers([]);
        }
      } else {
        const vanillaListMatch = clean.match(/there are\s+\d+\s+of a max of\s+\d+\s+players online:\s*(.*)/i);
        if (vanillaListMatch) {
          const names = vanillaListMatch[1].trim();
          setPlayers(
            names
              ? names
                  .split(",")
                  .map((n) => n.trim())
                  .filter(Boolean)
                  .map((name) => ({ name }))
              : []
          );
        }
      }
    });

    return () => {
      socket.emit("leaveServer", serverId);
      socket.disconnect();
    };
  }, [serverId, token]);

  const handleAction = async (player: string, action: string, command: string) => {
    try {
      setLoadingAction({ player, action });
      await axios.post(`/api/servers/${serverId}/command`, { command });
      setActionSuccess(`Executed ${action} on ${player}`);
      setTimeout(() => setActionSuccess(null), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setLoadingAction(null), 1000);
    }
  };

  const handleRefresh = async () => {
    try {
      setIsRefreshing(true);
      await axios.post(`/api/servers/${serverId}/command`, { command: "list" });
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  const handleCustomAction = async (actionType: string) => {
    const p = customPlayerInput.trim();
    if (!p) return;
    let cmd = "";
    if (actionType === "op") cmd = `op ${p}`;
    else if (actionType === "deop") cmd = `deop ${p}`;
    else if (actionType === "kick") cmd = `kick ${p} Kicked by admin.`;
    else if (actionType === "ban") cmd = `ban ${p} Banned by admin.`;
    else if (actionType === "whitelist") cmd = `whitelist add ${p}`;

    if (cmd) {
      await handleAction(p, actionType, cmd);
      setCustomPlayerInput("");
    }
  };

  return (
    <div className="p-4 md:p-6 w-full max-w-5xl mx-auto flex flex-col gap-6 font-sans relative">
      <style dangerouslySetInnerHTML={{__html: `
        .aw-glass-card {
          background: rgba(255,255,255,.035);
          border: 1px solid rgba(255,255,255,.12);
          border-radius: 14px;
          position: relative;
          overflow: hidden;
        }
        
        .aw-player-card {
          background: rgba(255,255,255,.035);
          border: 1px solid rgba(255,255,255,.12);
          transition: background-color .2s ease, border-color .2s ease;
          position: relative;
          overflow: hidden;
        }
        .aw-player-card:hover {
          border-color: rgba(255,255,255,.22);
          background: rgba(255,255,255,.055);
        }
        
        .aw-action-btn {
          transition: background-color .2s ease, border-color .2s ease, color .2s ease;
        }
        .aw-action-btn:hover:not(:disabled) {
          transform: none;
        }
        .aw-action-btn:active:not(:disabled) {
          transform: none;
        }
      `}} />

      {/* HEADER CARD */}
      <div className="aw-glass-card p-5 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div 
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.14)', color: '#e5e5e5' }}
            >
              <Users className="w-5 h-5" />
            </div>
            <h2 className="text-lg md:text-xl font-semibold text-white tracking-tight">
              Player Management
            </h2>
          </div>
          <p className="text-xs text-zinc-500">
            Monitor connected players and execute administrative actions like OP, Kick, Ban, and Whitelist.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span 
            className="px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5"
            style={{
              background: 'rgba(255,255,255,.12)',
              color: '#e5e5e5',
              border: '1px solid rgba(255,255,255,.35)',
            }}
          >
            <Activity size={11} />
            {players.length} Online
          </span>
          <button
            onClick={handleRefresh}
            className="px-3 py-1.5 rounded-xl text-zinc-300 text-xs font-medium flex items-center gap-1.5 aw-action-btn"
            style={{
              background: 'rgba(24,24,27,.5)',
              border: '1px solid rgba(255,255,255,.25)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,.15)';
              e.currentTarget.style.borderColor = 'rgba(255,255,255,.5)';
              e.currentTarget.style.color = '#e5e5e5';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(24,24,27,.5)';
              e.currentTarget.style.borderColor = 'rgba(255,255,255,.25)';
              e.currentTarget.style.color = '';
            }}
            title="Refresh Player List"
          >
            <RefreshCw size={13} className={isRefreshing ? "animate-spin" : ""} style={{ color: isRefreshing ? '#e5e5e5' : 'inherit' }} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div 
          className="px-4 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2"
          style={{
            background: 'rgba(255,255,255,.06)',
            border: '1px solid rgba(255,255,255,.14)',
            color: '#ffffff',
          }}
        >
          <Check className="w-4 h-4" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* QUICK PLAYER ACTION DOCK */}
      <div className="aw-glass-card p-4">
        <h3 className="text-xs font-semibold text-white/70 uppercase tracking-wide mb-3">
          Direct Player Command
        </h3>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={customPlayerInput}
            onChange={(e) => setCustomPlayerInput(e.target.value)}
            placeholder="Enter player username..."
            className="flex-1 rounded-xl px-3.5 py-2 text-sm text-white placeholder:text-zinc-600 focus:outline-none transition-colors"
            style={{
              background: 'rgba(0,0,0,.4)',
              border: '1px solid rgba(255,255,255,.2)',
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = 'rgba(255,255,255,.6)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = 'rgba(255,255,255,.2)';
            }}
          />
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => handleCustomAction("op")}
              disabled={!customPlayerInput.trim()}
              className="px-3 py-2 rounded-xl text-xs font-semibold aw-action-btn flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: 'rgba(255,255,255,.15)',
                border: '1px solid rgba(255,255,255,.35)',
                color: '#e5e5e5',
              }}
            >
              <Shield size={12} /> OP
            </button>
            <button
              onClick={() => handleCustomAction("deop")}
              disabled={!customPlayerInput.trim()}
              className="px-3 py-2 rounded-xl text-xs font-semibold aw-action-btn flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: 'rgba(113,113,122,.15)',
                border: '1px solid rgba(113,113,122,.3)',
                color: '#d4d4d8',
              }}
            >
              De-OP
            </button>
            <button
              onClick={() => handleCustomAction("kick")}
              disabled={!customPlayerInput.trim()}
              className="px-3 py-2 rounded-xl text-xs font-semibold aw-action-btn flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: 'rgba(255,255,255,.08)',
                border: '1px solid rgba(255,255,255,.24)',
                color: '#e5e5e5',
              }}
            >
              <UserMinus size={12} /> Kick
            </button>
            <button
              onClick={() => handleCustomAction("ban")}
              disabled={!customPlayerInput.trim()}
              className="px-3 py-2 rounded-xl text-xs font-semibold aw-action-btn flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: 'rgba(255,255,255,.08)',
                border: '1px solid rgba(255,255,255,.24)',
                color: '#e5e5e5',
              }}
            >
              <Gavel size={12} /> Ban
            </button>
            <button
              onClick={() => handleCustomAction("whitelist")}
              disabled={!customPlayerInput.trim()}
              className="px-3 py-2 rounded-xl text-xs font-semibold aw-action-btn flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: 'rgba(255,255,255,.08)',
                border: '1px solid rgba(255,255,255,.24)',
                color: '#e5e5e5',
              }}
            >
              <UserCheck size={12} /> Whitelist
            </button>
          </div>
        </div>
      </div>

      {/* CONNECTED PLAYERS LIST */}
      <div className="aw-glass-card p-5">
        <h3 className="text-xs font-semibold text-white/70 uppercase tracking-wide mb-4">
          Online Players
        </h3>

        {players.length === 0 ? (
          <div 
            className="p-12 text-center flex flex-col items-center justify-center rounded-xl"
            style={{
              background: 'rgba(0,0,0,.25)',
              border: '1px solid rgba(255,255,255,.10)',
            }}
          >
            <div 
              className="w-14 h-14 mb-3 rounded-2xl flex items-center justify-center"
              style={{
                background: 'rgba(255,255,255,.06)',
                border: '1px solid rgba(255,255,255,.12)',
              }}
            >
              <Users className="w-6 h-6 text-white/55" />
            </div>
            <p className="text-sm font-semibold text-zinc-400">No players currently connected</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {players.map((player, idx) => (
              <div
                key={player.name}
                className="aw-player-card rounded-xl p-3.5 flex flex-col gap-3"
              >
                <div className="flex items-center gap-3">
                  <div className="relative shrink-0">
                    <img
                      src={`https://minotar.net/avatar/${player.name}/40.png`}
                      alt={player.name}
                      className="w-10 h-10 rounded-lg border border-white/15 shadow-sm"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAAAAABW71eEAAAARElEQVR42mP8/58BDBjhGqgEho+B4aNg+BgYPgYqMECnEQ9s2IDiH2w4j6QY9EEDX8n20AdVDPqggS/4+tEHDXzB1w8AYU7y34W8vU0AAAAASUVORK5CYII=";
                      }}
                    />
                    <div 
                      className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2"
                      style={{
                        background: '#ffffff',
                        borderColor: '#0a0612',
                      }}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-sm font-semibold text-white truncate">{player.name}</h4>
                    <span className="text-[10px] text-zinc-500 flex items-center gap-1">
                      <Activity size={9} className="text-white/70" />
                      {player.joinedAt ? `Connected at ${player.joinedAt}` : "Active Session"}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-1.5 pt-2" style={{ borderTop: '1px solid rgba(255,255,255,.12)' }}>
                  <button
                    onClick={() => handleAction(player.name, "op", `op ${player.name}`)}
                    className="px-2 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wide flex justify-center items-center gap-1 aw-action-btn disabled:opacity-40"
                    style={{
                      background: 'rgba(255,255,255,.12)',
                      border: '1px solid rgba(255,255,255,.3)',
                      color: '#e5e5e5',
                    }}
                    title="Make OP"
                  >
                    {loadingAction?.player === player.name && loadingAction?.action === "op" ? (
                      <Check size={12} />
                    ) : (
                      <Shield size={12} />
                    )}
                    OP
                  </button>

                  <button
                    onClick={() => handleAction(player.name, "kick", `kick ${player.name} Kicked by admin.`)}
                    className="px-2 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wide flex justify-center items-center gap-1 aw-action-btn disabled:opacity-40"
                    style={{
                      background: 'rgba(255,255,255,.08)',
                      border: '1px solid rgba(255,255,255,.24)',
                      color: '#e5e5e5',
                    }}
                    title="Kick Player"
                  >
                    {loadingAction?.player === player.name && loadingAction?.action === "kick" ? (
                      <Check size={12} />
                    ) : (
                      <UserMinus size={12} />
                    )}
                    Kick
                  </button>

                  <button
                    onClick={() => handleAction(player.name, "ban", `ban ${player.name} Banned by admin.`)}
                    className="px-2 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wide flex justify-center items-center gap-1 aw-action-btn disabled:opacity-40"
                    style={{
                      background: 'rgba(255,255,255,.08)',
                      border: '1px solid rgba(255,255,255,.24)',
                      color: '#e5e5e5',
                    }}
                    title="Ban Player"
                  >
                    {loadingAction?.player === player.name && loadingAction?.action === "ban" ? (
                      <Check size={12} />
                    ) : (
                      <Gavel size={12} />
                    )}
                    Ban
                  </button>

                  <button
                    onClick={() => handleAction(player.name, "ban-ip", `ban-ip ${player.name}`)}
                    className="px-2 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wide flex justify-center items-center gap-1 aw-action-btn disabled:opacity-40"
                    style={{
                      background: 'rgba(255,255,255,.08)',
                      border: '1px solid rgba(255,255,255,.24)',
                      color: '#e5e5e5',
                    }}
                    title="Ban IP"
                  >
                    {loadingAction?.player === player.name && loadingAction?.action === "ban-ip" ? (
                      <Check size={12} />
                    ) : (
                      <ShieldAlert size={12} />
                    )}
                    IP
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
